/**
 * GetParameterValuesRequestEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class GetParameterValuesRequestEntry  extends com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry  implements java.io.Serializable {
    private java.lang.String[] paramNameVec;

    public GetParameterValuesRequestEntry() {
    }

    public GetParameterValuesRequestEntry(
           java.lang.String bindAccount,
           java.lang.String userID,
           java.lang.String[] paramNameVec) {
        super(
            bindAccount,
            userID);
        this.paramNameVec = paramNameVec;
    }


    /**
     * Gets the paramNameVec value for this GetParameterValuesRequestEntry.
     * 
     * @return paramNameVec
     */
    public java.lang.String[] getParamNameVec() {
        return paramNameVec;
    }


    /**
     * Sets the paramNameVec value for this GetParameterValuesRequestEntry.
     * 
     * @param paramNameVec
     */
    public void setParamNameVec(java.lang.String[] paramNameVec) {
        this.paramNameVec = paramNameVec;
    }

    public java.lang.String getParamNameVec(int i) {
        return this.paramNameVec[i];
    }

    public void setParamNameVec(int i, java.lang.String _value) {
        this.paramNameVec[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetParameterValuesRequestEntry)) return false;
        GetParameterValuesRequestEntry other = (GetParameterValuesRequestEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.paramNameVec==null && other.getParamNameVec()==null) || 
             (this.paramNameVec!=null &&
              java.util.Arrays.equals(this.paramNameVec, other.getParamNameVec())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getParamNameVec() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParamNameVec());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParamNameVec(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetParameterValuesRequestEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "GetParameterValuesRequestEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paramNameVec");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "paramNameVec"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
