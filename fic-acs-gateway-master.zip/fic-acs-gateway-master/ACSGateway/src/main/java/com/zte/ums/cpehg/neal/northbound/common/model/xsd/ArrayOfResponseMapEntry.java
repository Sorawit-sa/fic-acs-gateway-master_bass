/**
 * ArrayOfResponseMapEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class ArrayOfResponseMapEntry  implements java.io.Serializable {
    private com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] array;

    public ArrayOfResponseMapEntry() {
    }

    public ArrayOfResponseMapEntry(
           com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] array) {
           this.array = array;
    }


    /**
     * Gets the array value for this ArrayOfResponseMapEntry.
     * 
     * @return array
     */
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getArray() {
        return array;
    }


    /**
     * Sets the array value for this ArrayOfResponseMapEntry.
     * 
     * @param array
     */
    public void setArray(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] array) {
        this.array = array;
    }
    
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry getArray(int i) {
        return this.array[i];
    }

    public void setArray(int i, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry _value) {
        this.array[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ArrayOfResponseMapEntry)) return false;
        ArrayOfResponseMapEntry other = (ArrayOfResponseMapEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.array==null && other.getArray()==null) || 
             (this.array!=null &&
              this.array.equals(other.getArray())));
        __equalsCalc = null;
        return _equals;
    }

    
    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getArray() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArray());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArray(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ArrayOfResponseMapEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ArrayOfResponseMapEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("array");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "array"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
