/**
 * ServiceChangeRequestEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class ServiceChangeRequestEntry  implements java.io.Serializable {
    private java.lang.String bindaccount;

    private java.lang.String ordertype;

    private java.lang.String parameters;

    private java.lang.String serialuserid;

    private java.lang.String servicecode;

    private java.lang.String userid;

    public ServiceChangeRequestEntry() {
    }

    public ServiceChangeRequestEntry(
           java.lang.String bindaccount,
           java.lang.String ordertype,
           java.lang.String parameters,
           java.lang.String serialuserid,
           java.lang.String servicecode,
           java.lang.String userid) {
           this.bindaccount = bindaccount;
           this.ordertype = ordertype;
           this.parameters = parameters;
           this.serialuserid = serialuserid;
           this.servicecode = servicecode;
           this.userid = userid;
    }


    /**
     * Gets the bindaccount value for this ServiceChangeRequestEntry.
     * 
     * @return bindaccount
     */
    public java.lang.String getBindaccount() {
        return bindaccount;
    }


    /**
     * Sets the bindaccount value for this ServiceChangeRequestEntry.
     * 
     * @param bindaccount
     */
    public void setBindaccount(java.lang.String bindaccount) {
        this.bindaccount = bindaccount;
    }


    /**
     * Gets the ordertype value for this ServiceChangeRequestEntry.
     * 
     * @return ordertype
     */
    public java.lang.String getOrdertype() {
        return ordertype;
    }


    /**
     * Sets the ordertype value for this ServiceChangeRequestEntry.
     * 
     * @param ordertype
     */
    public void setOrdertype(java.lang.String ordertype) {
        this.ordertype = ordertype;
    }


    /**
     * Gets the parameters value for this ServiceChangeRequestEntry.
     * 
     * @return parameters
     */
    public java.lang.String getParameters() {
        return parameters;
    }


    /**
     * Sets the parameters value for this ServiceChangeRequestEntry.
     * 
     * @param parameters
     */
    public void setParameters(java.lang.String parameters) {
        this.parameters = parameters;
    }


    /**
     * Gets the serialuserid value for this ServiceChangeRequestEntry.
     * 
     * @return serialuserid
     */
    public java.lang.String getSerialuserid() {
        return serialuserid;
    }


    /**
     * Sets the serialuserid value for this ServiceChangeRequestEntry.
     * 
     * @param serialuserid
     */
    public void setSerialuserid(java.lang.String serialuserid) {
        this.serialuserid = serialuserid;
    }


    /**
     * Gets the servicecode value for this ServiceChangeRequestEntry.
     * 
     * @return servicecode
     */
    public java.lang.String getServicecode() {
        return servicecode;
    }


    /**
     * Sets the servicecode value for this ServiceChangeRequestEntry.
     * 
     * @param servicecode
     */
    public void setServicecode(java.lang.String servicecode) {
        this.servicecode = servicecode;
    }


    /**
     * Gets the userid value for this ServiceChangeRequestEntry.
     * 
     * @return userid
     */
    public java.lang.String getUserid() {
        return userid;
    }


    /**
     * Sets the userid value for this ServiceChangeRequestEntry.
     * 
     * @param userid
     */
    public void setUserid(java.lang.String userid) {
        this.userid = userid;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ServiceChangeRequestEntry)) return false;
        ServiceChangeRequestEntry other = (ServiceChangeRequestEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.bindaccount==null && other.getBindaccount()==null) || 
             (this.bindaccount!=null &&
              this.bindaccount.equals(other.getBindaccount()))) &&
            ((this.ordertype==null && other.getOrdertype()==null) || 
             (this.ordertype!=null &&
              this.ordertype.equals(other.getOrdertype()))) &&
            ((this.parameters==null && other.getParameters()==null) || 
             (this.parameters!=null &&
              this.parameters.equals(other.getParameters()))) &&
            ((this.serialuserid==null && other.getSerialuserid()==null) || 
             (this.serialuserid!=null &&
              this.serialuserid.equals(other.getSerialuserid()))) &&
            ((this.servicecode==null && other.getServicecode()==null) || 
             (this.servicecode!=null &&
              this.servicecode.equals(other.getServicecode()))) &&
            ((this.userid==null && other.getUserid()==null) || 
             (this.userid!=null &&
              this.userid.equals(other.getUserid())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBindaccount() != null) {
            _hashCode += getBindaccount().hashCode();
        }
        if (getOrdertype() != null) {
            _hashCode += getOrdertype().hashCode();
        }
        if (getParameters() != null) {
            _hashCode += getParameters().hashCode();
        }
        if (getSerialuserid() != null) {
            _hashCode += getSerialuserid().hashCode();
        }
        if (getServicecode() != null) {
            _hashCode += getServicecode().hashCode();
        }
        if (getUserid() != null) {
            _hashCode += getUserid().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ServiceChangeRequestEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeRequestEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bindaccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "bindaccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ordertype");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ordertype"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "parameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serialuserid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "serialuserid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("servicecode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "servicecode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "userid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
