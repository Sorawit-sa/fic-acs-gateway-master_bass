/**
 * CpeHgServiceCustom.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.nefl.worklist.model.xsd;

public class CpeHgServiceCustom  extends com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgService  implements java.io.Serializable {
    private java.lang.String bindLanPort;

    public CpeHgServiceCustom() {
    }

    public CpeHgServiceCustom(
           java.lang.String deviceID,
           java.lang.String serviceCode,
           java.lang.String exeTime,
           java.lang.String parameters,
           java.lang.String primaryParameter,
           java.lang.String series,
           java.lang.Integer serviceStatus,
           java.lang.String userID,
           java.lang.String bindLanPort) {
        super(
            deviceID,
            serviceCode,
            exeTime,
            parameters,
            primaryParameter,
            series,
            serviceStatus,
            userID);
        this.bindLanPort = bindLanPort;
    }


    /**
     * Gets the bindLanPort value for this CpeHgServiceCustom.
     * 
     * @return bindLanPort
     */
    public java.lang.String getBindLanPort() {
        return bindLanPort;
    }


    /**
     * Sets the bindLanPort value for this CpeHgServiceCustom.
     * 
     * @param bindLanPort
     */
    public void setBindLanPort(java.lang.String bindLanPort) {
        this.bindLanPort = bindLanPort;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CpeHgServiceCustom)) return false;
        CpeHgServiceCustom other = (CpeHgServiceCustom) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.bindLanPort==null && other.getBindLanPort()==null) || 
             (this.bindLanPort!=null &&
              this.bindLanPort.equals(other.getBindLanPort())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBindLanPort() != null) {
            _hashCode += getBindLanPort().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CpeHgServiceCustom.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "CpeHgServiceCustom"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bindLanPort");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "bindLanPort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
