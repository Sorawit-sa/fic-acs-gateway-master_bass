/**
 * DiagnosisATMRequestEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class DiagnosisATMRequestEntry  extends com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry  implements java.io.Serializable {
    private java.lang.String numberOfRepetitions;

    private java.lang.String timeout;

    private java.lang.String wanInterface;

    public DiagnosisATMRequestEntry() {
    }

    public DiagnosisATMRequestEntry(
           java.lang.String bindAccount,
           java.lang.String userID,
           java.lang.String numberOfRepetitions,
           java.lang.String timeout,
           java.lang.String wanInterface) {
        super(
            bindAccount,
            userID);
        this.numberOfRepetitions = numberOfRepetitions;
        this.timeout = timeout;
        this.wanInterface = wanInterface;
    }


    /**
     * Gets the numberOfRepetitions value for this DiagnosisATMRequestEntry.
     * 
     * @return numberOfRepetitions
     */
    public java.lang.String getNumberOfRepetitions() {
        return numberOfRepetitions;
    }


    /**
     * Sets the numberOfRepetitions value for this DiagnosisATMRequestEntry.
     * 
     * @param numberOfRepetitions
     */
    public void setNumberOfRepetitions(java.lang.String numberOfRepetitions) {
        this.numberOfRepetitions = numberOfRepetitions;
    }


    /**
     * Gets the timeout value for this DiagnosisATMRequestEntry.
     * 
     * @return timeout
     */
    public java.lang.String getTimeout() {
        return timeout;
    }


    /**
     * Sets the timeout value for this DiagnosisATMRequestEntry.
     * 
     * @param timeout
     */
    public void setTimeout(java.lang.String timeout) {
        this.timeout = timeout;
    }


    /**
     * Gets the wanInterface value for this DiagnosisATMRequestEntry.
     * 
     * @return wanInterface
     */
    public java.lang.String getWanInterface() {
        return wanInterface;
    }


    /**
     * Sets the wanInterface value for this DiagnosisATMRequestEntry.
     * 
     * @param wanInterface
     */
    public void setWanInterface(java.lang.String wanInterface) {
        this.wanInterface = wanInterface;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DiagnosisATMRequestEntry)) return false;
        DiagnosisATMRequestEntry other = (DiagnosisATMRequestEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.numberOfRepetitions==null && other.getNumberOfRepetitions()==null) || 
             (this.numberOfRepetitions!=null &&
              this.numberOfRepetitions.equals(other.getNumberOfRepetitions()))) &&
            ((this.timeout==null && other.getTimeout()==null) || 
             (this.timeout!=null &&
              this.timeout.equals(other.getTimeout()))) &&
            ((this.wanInterface==null && other.getWanInterface()==null) || 
             (this.wanInterface!=null &&
              this.wanInterface.equals(other.getWanInterface())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getNumberOfRepetitions() != null) {
            _hashCode += getNumberOfRepetitions().hashCode();
        }
        if (getTimeout() != null) {
            _hashCode += getTimeout().hashCode();
        }
        if (getWanInterface() != null) {
            _hashCode += getWanInterface().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DiagnosisATMRequestEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisATMRequestEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfRepetitions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "numberOfRepetitions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "timeout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wanInterface");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "wanInterface"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
