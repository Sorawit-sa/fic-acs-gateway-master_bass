/**
 * DiagnosisIpPingServiceRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class DiagnosisIpPingServiceRequest  extends com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry  implements java.io.Serializable {
    private java.lang.String dataBlockSize;

    private java.lang.String host;

    private java.lang.String numberOfRepetitions;

    private java.lang.String service;

    private java.lang.String timeout;

    public DiagnosisIpPingServiceRequest() {
    }

    public DiagnosisIpPingServiceRequest(
           java.lang.String bindAccount,
           java.lang.String userID,
           java.lang.String dataBlockSize,
           java.lang.String host,
           java.lang.String numberOfRepetitions,
           java.lang.String service,
           java.lang.String timeout) {
        super(
            bindAccount,
            userID);
        this.dataBlockSize = dataBlockSize;
        this.host = host;
        this.numberOfRepetitions = numberOfRepetitions;
        this.service = service;
        this.timeout = timeout;
    }


    /**
     * Gets the dataBlockSize value for this DiagnosisIpPingServiceRequest.
     * 
     * @return dataBlockSize
     */
    public java.lang.String getDataBlockSize() {
        return dataBlockSize;
    }


    /**
     * Sets the dataBlockSize value for this DiagnosisIpPingServiceRequest.
     * 
     * @param dataBlockSize
     */
    public void setDataBlockSize(java.lang.String dataBlockSize) {
        this.dataBlockSize = dataBlockSize;
    }


    /**
     * Gets the host value for this DiagnosisIpPingServiceRequest.
     * 
     * @return host
     */
    public java.lang.String getHost() {
        return host;
    }


    /**
     * Sets the host value for this DiagnosisIpPingServiceRequest.
     * 
     * @param host
     */
    public void setHost(java.lang.String host) {
        this.host = host;
    }


    /**
     * Gets the numberOfRepetitions value for this DiagnosisIpPingServiceRequest.
     * 
     * @return numberOfRepetitions
     */
    public java.lang.String getNumberOfRepetitions() {
        return numberOfRepetitions;
    }


    /**
     * Sets the numberOfRepetitions value for this DiagnosisIpPingServiceRequest.
     * 
     * @param numberOfRepetitions
     */
    public void setNumberOfRepetitions(java.lang.String numberOfRepetitions) {
        this.numberOfRepetitions = numberOfRepetitions;
    }


    /**
     * Gets the service value for this DiagnosisIpPingServiceRequest.
     * 
     * @return service
     */
    public java.lang.String getService() {
        return service;
    }


    /**
     * Sets the service value for this DiagnosisIpPingServiceRequest.
     * 
     * @param service
     */
    public void setService(java.lang.String service) {
        this.service = service;
    }


    /**
     * Gets the timeout value for this DiagnosisIpPingServiceRequest.
     * 
     * @return timeout
     */
    public java.lang.String getTimeout() {
        return timeout;
    }


    /**
     * Sets the timeout value for this DiagnosisIpPingServiceRequest.
     * 
     * @param timeout
     */
    public void setTimeout(java.lang.String timeout) {
        this.timeout = timeout;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DiagnosisIpPingServiceRequest)) return false;
        DiagnosisIpPingServiceRequest other = (DiagnosisIpPingServiceRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.dataBlockSize==null && other.getDataBlockSize()==null) || 
             (this.dataBlockSize!=null &&
              this.dataBlockSize.equals(other.getDataBlockSize()))) &&
            ((this.host==null && other.getHost()==null) || 
             (this.host!=null &&
              this.host.equals(other.getHost()))) &&
            ((this.numberOfRepetitions==null && other.getNumberOfRepetitions()==null) || 
             (this.numberOfRepetitions!=null &&
              this.numberOfRepetitions.equals(other.getNumberOfRepetitions()))) &&
            ((this.service==null && other.getService()==null) || 
             (this.service!=null &&
              this.service.equals(other.getService()))) &&
            ((this.timeout==null && other.getTimeout()==null) || 
             (this.timeout!=null &&
              this.timeout.equals(other.getTimeout())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDataBlockSize() != null) {
            _hashCode += getDataBlockSize().hashCode();
        }
        if (getHost() != null) {
            _hashCode += getHost().hashCode();
        }
        if (getNumberOfRepetitions() != null) {
            _hashCode += getNumberOfRepetitions().hashCode();
        }
        if (getService() != null) {
            _hashCode += getService().hashCode();
        }
        if (getTimeout() != null) {
            _hashCode += getTimeout().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DiagnosisIpPingServiceRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisIpPingServiceRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataBlockSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "dataBlockSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("host");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "host"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfRepetitions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "numberOfRepetitions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("service");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "service"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "timeout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
