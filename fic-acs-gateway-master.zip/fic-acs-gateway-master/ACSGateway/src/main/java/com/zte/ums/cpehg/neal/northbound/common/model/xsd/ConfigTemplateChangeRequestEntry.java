/**
 * ConfigTemplateChangeRequestEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class ConfigTemplateChangeRequestEntry  implements java.io.Serializable {
    private java.lang.String bindaccount;

    private java.lang.String parameters;

    private java.lang.String serialuserid;

    private java.lang.String servicecode;

    private java.lang.String userid;

    public ConfigTemplateChangeRequestEntry() {
    }

    public ConfigTemplateChangeRequestEntry(
           java.lang.String bindaccount,
           java.lang.String parameters,
           java.lang.String serialuserid,
           java.lang.String servicecode,
           java.lang.String userid) {
           this.bindaccount = bindaccount;
           this.parameters = parameters;
           this.serialuserid = serialuserid;
           this.servicecode = servicecode;
           this.userid = userid;
    }


    /**
     * Gets the bindaccount value for this ConfigTemplateChangeRequestEntry.
     * 
     * @return bindaccount
     */
    public java.lang.String getBindaccount() {
        return bindaccount;
    }


    /**
     * Sets the bindaccount value for this ConfigTemplateChangeRequestEntry.
     * 
     * @param bindaccount
     */
    public void setBindaccount(java.lang.String bindaccount) {
        this.bindaccount = bindaccount;
    }


    /**
     * Gets the parameters value for this ConfigTemplateChangeRequestEntry.
     * 
     * @return parameters
     */
    public java.lang.String getParameters() {
        return parameters;
    }


    /**
     * Sets the parameters value for this ConfigTemplateChangeRequestEntry.
     * 
     * @param parameters
     */
    public void setParameters(java.lang.String parameters) {
        this.parameters = parameters;
    }


    /**
     * Gets the serialuserid value for this ConfigTemplateChangeRequestEntry.
     * 
     * @return serialuserid
     */
    public java.lang.String getSerialuserid() {
        return serialuserid;
    }


    /**
     * Sets the serialuserid value for this ConfigTemplateChangeRequestEntry.
     * 
     * @param serialuserid
     */
    public void setSerialuserid(java.lang.String serialuserid) {
        this.serialuserid = serialuserid;
    }


    /**
     * Gets the servicecode value for this ConfigTemplateChangeRequestEntry.
     * 
     * @return servicecode
     */
    public java.lang.String getServicecode() {
        return servicecode;
    }


    /**
     * Sets the servicecode value for this ConfigTemplateChangeRequestEntry.
     * 
     * @param servicecode
     */
    public void setServicecode(java.lang.String servicecode) {
        this.servicecode = servicecode;
    }


    /**
     * Gets the userid value for this ConfigTemplateChangeRequestEntry.
     * 
     * @return userid
     */
    public java.lang.String getUserid() {
        return userid;
    }


    /**
     * Sets the userid value for this ConfigTemplateChangeRequestEntry.
     * 
     * @param userid
     */
    public void setUserid(java.lang.String userid) {
        this.userid = userid;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConfigTemplateChangeRequestEntry)) return false;
        ConfigTemplateChangeRequestEntry other = (ConfigTemplateChangeRequestEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.bindaccount==null && other.getBindaccount()==null) || 
             (this.bindaccount!=null &&
              this.bindaccount.equals(other.getBindaccount()))) &&
            ((this.parameters==null && other.getParameters()==null) || 
             (this.parameters!=null &&
              this.parameters.equals(other.getParameters()))) &&
            ((this.serialuserid==null && other.getSerialuserid()==null) || 
             (this.serialuserid!=null &&
              this.serialuserid.equals(other.getSerialuserid()))) &&
            ((this.servicecode==null && other.getServicecode()==null) || 
             (this.servicecode!=null &&
              this.servicecode.equals(other.getServicecode()))) &&
            ((this.userid==null && other.getUserid()==null) || 
             (this.userid!=null &&
              this.userid.equals(other.getUserid())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBindaccount() != null) {
            _hashCode += getBindaccount().hashCode();
        }
        if (getParameters() != null) {
            _hashCode += getParameters().hashCode();
        }
        if (getSerialuserid() != null) {
            _hashCode += getSerialuserid().hashCode();
        }
        if (getServicecode() != null) {
            _hashCode += getServicecode().hashCode();
        }
        if (getUserid() != null) {
            _hashCode += getUserid().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConfigTemplateChangeRequestEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ConfigTemplateChangeRequestEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bindaccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "bindaccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "parameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serialuserid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "serialuserid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("servicecode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "servicecode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "userid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
