/**
 * ConfigFilesListResponseEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class ConfigFilesListResponseEntry  implements java.io.Serializable {
    private com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] array;

    private com.zte.ums.cpehg.neal.northbound.common.model.xsd.ArrayOfResponseMapEntry[] configs;

    public ConfigFilesListResponseEntry() {
    }

    public ConfigFilesListResponseEntry(
           com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] array,
           com.zte.ums.cpehg.neal.northbound.common.model.xsd.ArrayOfResponseMapEntry[] configs) {
           this.array = array;
           this.configs = configs;
    }


    /**
     * Gets the array value for this ConfigFilesListResponseEntry.
     * 
     * @return array
     */
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getArray() {
        return array;
    }


    /**
     * Sets the array value for this ConfigFilesListResponseEntry.
     * 
     * @param array
     */
    public void setArray(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] array) {
        this.array = array;
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry getArray(int i) {
        return this.array[i];
    }

    public void setArray(int i, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry _value) {
        this.array[i] = _value;
    }


    /**
     * Gets the configs value for this ConfigFilesListResponseEntry.
     * 
     * @return configs
     */
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ArrayOfResponseMapEntry[] getConfigs() {
        return configs;
    }


    /**
     * Sets the configs value for this ConfigFilesListResponseEntry.
     * 
     * @param configs
     */
    public void setConfigs(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ArrayOfResponseMapEntry[] configs) {
        this.configs = configs;
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ArrayOfResponseMapEntry getConfigs(int i) {
        return this.configs[i];
    }

    public void setConfigs(int i, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ArrayOfResponseMapEntry _value) {
        this.configs[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConfigFilesListResponseEntry)) return false;
        ConfigFilesListResponseEntry other = (ConfigFilesListResponseEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.array==null && other.getArray()==null) || 
             (this.array!=null &&
              java.util.Arrays.equals(this.array, other.getArray()))) &&
            ((this.configs==null && other.getConfigs()==null) || 
             (this.configs!=null &&
              java.util.Arrays.equals(this.configs, other.getConfigs())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getArray() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArray());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArray(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getConfigs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getConfigs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getConfigs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConfigFilesListResponseEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ConfigFilesListResponseEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("array");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "array"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("configs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "configs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ArrayOfResponseMapEntry"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
