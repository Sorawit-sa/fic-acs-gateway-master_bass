/**
 * CpeHgService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.nefl.worklist.model.xsd;

public class CpeHgService  extends com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceKey  implements java.io.Serializable {
    private java.lang.String exeTime;

    private java.lang.String parameters;

    private java.lang.String primaryParameter;

    private java.lang.String series;

    private java.lang.Integer serviceStatus;

    private java.lang.String userID;

    public CpeHgService() {
    }

    public CpeHgService(
           java.lang.String deviceID,
           java.lang.String serviceCode,
           java.lang.String exeTime,
           java.lang.String parameters,
           java.lang.String primaryParameter,
           java.lang.String series,
           java.lang.Integer serviceStatus,
           java.lang.String userID) {
        super(
            deviceID,
            serviceCode);
        this.exeTime = exeTime;
        this.parameters = parameters;
        this.primaryParameter = primaryParameter;
        this.series = series;
        this.serviceStatus = serviceStatus;
        this.userID = userID;
    }


    /**
     * Gets the exeTime value for this CpeHgService.
     * 
     * @return exeTime
     */
    public java.lang.String getExeTime() {
        return exeTime;
    }


    /**
     * Sets the exeTime value for this CpeHgService.
     * 
     * @param exeTime
     */
    public void setExeTime(java.lang.String exeTime) {
        this.exeTime = exeTime;
    }


    /**
     * Gets the parameters value for this CpeHgService.
     * 
     * @return parameters
     */
    public java.lang.String getParameters() {
        return parameters;
    }


    /**
     * Sets the parameters value for this CpeHgService.
     * 
     * @param parameters
     */
    public void setParameters(java.lang.String parameters) {
        this.parameters = parameters;
    }


    /**
     * Gets the primaryParameter value for this CpeHgService.
     * 
     * @return primaryParameter
     */
    public java.lang.String getPrimaryParameter() {
        return primaryParameter;
    }


    /**
     * Sets the primaryParameter value for this CpeHgService.
     * 
     * @param primaryParameter
     */
    public void setPrimaryParameter(java.lang.String primaryParameter) {
        this.primaryParameter = primaryParameter;
    }


    /**
     * Gets the series value for this CpeHgService.
     * 
     * @return series
     */
    public java.lang.String getSeries() {
        return series;
    }


    /**
     * Sets the series value for this CpeHgService.
     * 
     * @param series
     */
    public void setSeries(java.lang.String series) {
        this.series = series;
    }


    /**
     * Gets the serviceStatus value for this CpeHgService.
     * 
     * @return serviceStatus
     */
    public java.lang.Integer getServiceStatus() {
        return serviceStatus;
    }


    /**
     * Sets the serviceStatus value for this CpeHgService.
     * 
     * @param serviceStatus
     */
    public void setServiceStatus(java.lang.Integer serviceStatus) {
        this.serviceStatus = serviceStatus;
    }


    /**
     * Gets the userID value for this CpeHgService.
     * 
     * @return userID
     */
    public java.lang.String getUserID() {
        return userID;
    }


    /**
     * Sets the userID value for this CpeHgService.
     * 
     * @param userID
     */
    public void setUserID(java.lang.String userID) {
        this.userID = userID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CpeHgService)) return false;
        CpeHgService other = (CpeHgService) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.exeTime==null && other.getExeTime()==null) || 
             (this.exeTime!=null &&
              this.exeTime.equals(other.getExeTime()))) &&
            ((this.parameters==null && other.getParameters()==null) || 
             (this.parameters!=null &&
              this.parameters.equals(other.getParameters()))) &&
            ((this.primaryParameter==null && other.getPrimaryParameter()==null) || 
             (this.primaryParameter!=null &&
              this.primaryParameter.equals(other.getPrimaryParameter()))) &&
            ((this.series==null && other.getSeries()==null) || 
             (this.series!=null &&
              this.series.equals(other.getSeries()))) &&
            ((this.serviceStatus==null && other.getServiceStatus()==null) || 
             (this.serviceStatus!=null &&
              this.serviceStatus.equals(other.getServiceStatus()))) &&
            ((this.userID==null && other.getUserID()==null) || 
             (this.userID!=null &&
              this.userID.equals(other.getUserID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getExeTime() != null) {
            _hashCode += getExeTime().hashCode();
        }
        if (getParameters() != null) {
            _hashCode += getParameters().hashCode();
        }
        if (getPrimaryParameter() != null) {
            _hashCode += getPrimaryParameter().hashCode();
        }
        if (getSeries() != null) {
            _hashCode += getSeries().hashCode();
        }
        if (getServiceStatus() != null) {
            _hashCode += getServiceStatus().hashCode();
        }
        if (getUserID() != null) {
            _hashCode += getUserID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CpeHgService.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "CpeHgService"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exeTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "exeTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anySimpleType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "parameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryParameter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "primaryParameter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("series");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "series"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "serviceStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "userID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
