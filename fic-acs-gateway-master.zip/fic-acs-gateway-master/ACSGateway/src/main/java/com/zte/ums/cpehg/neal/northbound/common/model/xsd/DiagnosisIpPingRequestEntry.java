/**
 * DiagnosisIpPingRequestEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class DiagnosisIpPingRequestEntry  extends com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry  implements java.io.Serializable {
    private java.lang.String DSCP;

    private java.lang.String dataBlockSize;

    private java.lang.String diagnosticsState;

    private java.lang.String host;

    private java.lang.String _interface;

    private java.lang.String ipAddress;

    private java.lang.String numberOfRepetitions;

    private java.lang.String timeout;

    public DiagnosisIpPingRequestEntry() {
    }

    public DiagnosisIpPingRequestEntry(
           java.lang.String bindAccount,
           java.lang.String userID,
           java.lang.String DSCP,
           java.lang.String dataBlockSize,
           java.lang.String diagnosticsState,
           java.lang.String host,
           java.lang.String _interface,
           java.lang.String ipAddress,
           java.lang.String numberOfRepetitions,
           java.lang.String timeout) {
        super(
            bindAccount,
            userID);
        this.DSCP = DSCP;
        this.dataBlockSize = dataBlockSize;
        this.diagnosticsState = diagnosticsState;
        this.host = host;
        this._interface = _interface;
        this.ipAddress = ipAddress;
        this.numberOfRepetitions = numberOfRepetitions;
        this.timeout = timeout;
    }


    /**
     * Gets the DSCP value for this DiagnosisIpPingRequestEntry.
     * 
     * @return DSCP
     */
    public java.lang.String getDSCP() {
        return DSCP;
    }


    /**
     * Sets the DSCP value for this DiagnosisIpPingRequestEntry.
     * 
     * @param DSCP
     */
    public void setDSCP(java.lang.String DSCP) {
        this.DSCP = DSCP;
    }


    /**
     * Gets the dataBlockSize value for this DiagnosisIpPingRequestEntry.
     * 
     * @return dataBlockSize
     */
    public java.lang.String getDataBlockSize() {
        return dataBlockSize;
    }


    /**
     * Sets the dataBlockSize value for this DiagnosisIpPingRequestEntry.
     * 
     * @param dataBlockSize
     */
    public void setDataBlockSize(java.lang.String dataBlockSize) {
        this.dataBlockSize = dataBlockSize;
    }


    /**
     * Gets the diagnosticsState value for this DiagnosisIpPingRequestEntry.
     * 
     * @return diagnosticsState
     */
    public java.lang.String getDiagnosticsState() {
        return diagnosticsState;
    }


    /**
     * Sets the diagnosticsState value for this DiagnosisIpPingRequestEntry.
     * 
     * @param diagnosticsState
     */
    public void setDiagnosticsState(java.lang.String diagnosticsState) {
        this.diagnosticsState = diagnosticsState;
    }


    /**
     * Gets the host value for this DiagnosisIpPingRequestEntry.
     * 
     * @return host
     */
    public java.lang.String getHost() {
        return host;
    }


    /**
     * Sets the host value for this DiagnosisIpPingRequestEntry.
     * 
     * @param host
     */
    public void setHost(java.lang.String host) {
        this.host = host;
    }


    /**
     * Gets the _interface value for this DiagnosisIpPingRequestEntry.
     * 
     * @return _interface
     */
    public java.lang.String get_interface() {
        return _interface;
    }


    /**
     * Sets the _interface value for this DiagnosisIpPingRequestEntry.
     * 
     * @param _interface
     */
    public void set_interface(java.lang.String _interface) {
        this._interface = _interface;
    }


    /**
     * Gets the ipAddress value for this DiagnosisIpPingRequestEntry.
     * 
     * @return ipAddress
     */
    public java.lang.String getIpAddress() {
        return ipAddress;
    }


    /**
     * Sets the ipAddress value for this DiagnosisIpPingRequestEntry.
     * 
     * @param ipAddress
     */
    public void setIpAddress(java.lang.String ipAddress) {
        this.ipAddress = ipAddress;
    }


    /**
     * Gets the numberOfRepetitions value for this DiagnosisIpPingRequestEntry.
     * 
     * @return numberOfRepetitions
     */
    public java.lang.String getNumberOfRepetitions() {
        return numberOfRepetitions;
    }


    /**
     * Sets the numberOfRepetitions value for this DiagnosisIpPingRequestEntry.
     * 
     * @param numberOfRepetitions
     */
    public void setNumberOfRepetitions(java.lang.String numberOfRepetitions) {
        this.numberOfRepetitions = numberOfRepetitions;
    }


    /**
     * Gets the timeout value for this DiagnosisIpPingRequestEntry.
     * 
     * @return timeout
     */
    public java.lang.String getTimeout() {
        return timeout;
    }


    /**
     * Sets the timeout value for this DiagnosisIpPingRequestEntry.
     * 
     * @param timeout
     */
    public void setTimeout(java.lang.String timeout) {
        this.timeout = timeout;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DiagnosisIpPingRequestEntry)) return false;
        DiagnosisIpPingRequestEntry other = (DiagnosisIpPingRequestEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.DSCP==null && other.getDSCP()==null) || 
             (this.DSCP!=null &&
              this.DSCP.equals(other.getDSCP()))) &&
            ((this.dataBlockSize==null && other.getDataBlockSize()==null) || 
             (this.dataBlockSize!=null &&
              this.dataBlockSize.equals(other.getDataBlockSize()))) &&
            ((this.diagnosticsState==null && other.getDiagnosticsState()==null) || 
             (this.diagnosticsState!=null &&
              this.diagnosticsState.equals(other.getDiagnosticsState()))) &&
            ((this.host==null && other.getHost()==null) || 
             (this.host!=null &&
              this.host.equals(other.getHost()))) &&
            ((this._interface==null && other.get_interface()==null) || 
             (this._interface!=null &&
              this._interface.equals(other.get_interface()))) &&
            ((this.ipAddress==null && other.getIpAddress()==null) || 
             (this.ipAddress!=null &&
              this.ipAddress.equals(other.getIpAddress()))) &&
            ((this.numberOfRepetitions==null && other.getNumberOfRepetitions()==null) || 
             (this.numberOfRepetitions!=null &&
              this.numberOfRepetitions.equals(other.getNumberOfRepetitions()))) &&
            ((this.timeout==null && other.getTimeout()==null) || 
             (this.timeout!=null &&
              this.timeout.equals(other.getTimeout())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDSCP() != null) {
            _hashCode += getDSCP().hashCode();
        }
        if (getDataBlockSize() != null) {
            _hashCode += getDataBlockSize().hashCode();
        }
        if (getDiagnosticsState() != null) {
            _hashCode += getDiagnosticsState().hashCode();
        }
        if (getHost() != null) {
            _hashCode += getHost().hashCode();
        }
        if (get_interface() != null) {
            _hashCode += get_interface().hashCode();
        }
        if (getIpAddress() != null) {
            _hashCode += getIpAddress().hashCode();
        }
        if (getNumberOfRepetitions() != null) {
            _hashCode += getNumberOfRepetitions().hashCode();
        }
        if (getTimeout() != null) {
            _hashCode += getTimeout().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DiagnosisIpPingRequestEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisIpPingRequestEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DSCP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DSCP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataBlockSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "dataBlockSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("diagnosticsState");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "diagnosticsState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("host");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "host"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_interface");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "interface"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ipAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ipAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfRepetitions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "numberOfRepetitions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "timeout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
