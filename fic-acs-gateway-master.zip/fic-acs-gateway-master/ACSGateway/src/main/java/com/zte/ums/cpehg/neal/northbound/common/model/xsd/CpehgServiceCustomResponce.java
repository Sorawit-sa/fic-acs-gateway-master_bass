/**
 * CpehgServiceCustomResponce.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class CpehgServiceCustomResponce  extends com.zte.ums.cpehg.neal.northbound.common.model.xsd.OperateResponce  implements java.io.Serializable {
    private com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceCustom[] cpeHgServices;

    public CpehgServiceCustomResponce() {
    }

    public CpehgServiceCustomResponce(
           java.lang.String faultcode,
           java.lang.String faultstring,
           com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceCustom[] cpeHgServices) {
        super(
            faultcode,
            faultstring);
        this.cpeHgServices = cpeHgServices;
    }


    /**
     * Gets the cpeHgServices value for this CpehgServiceCustomResponce.
     * 
     * @return cpeHgServices
     */
    public com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceCustom[] getCpeHgServices() {
        return cpeHgServices;
    }


    /**
     * Sets the cpeHgServices value for this CpehgServiceCustomResponce.
     * 
     * @param cpeHgServices
     */
    public void setCpeHgServices(com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceCustom[] cpeHgServices) {
        this.cpeHgServices = cpeHgServices;
    }

    public com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceCustom getCpeHgServices(int i) {
        return this.cpeHgServices[i];
    }

    public void setCpeHgServices(int i, com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceCustom _value) {
        this.cpeHgServices[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CpehgServiceCustomResponce)) return false;
        CpehgServiceCustomResponce other = (CpehgServiceCustomResponce) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.cpeHgServices==null && other.getCpeHgServices()==null) || 
             (this.cpeHgServices!=null &&
              java.util.Arrays.equals(this.cpeHgServices, other.getCpeHgServices())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCpeHgServices() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCpeHgServices());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCpeHgServices(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CpehgServiceCustomResponce.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "CpehgServiceCustomResponce"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpeHgServices");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "cpeHgServices"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "CpeHgServiceCustom"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
