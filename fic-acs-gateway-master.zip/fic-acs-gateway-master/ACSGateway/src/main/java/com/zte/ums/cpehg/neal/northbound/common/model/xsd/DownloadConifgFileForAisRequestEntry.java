/**
 * DownloadConifgFileForAisRequestEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class DownloadConifgFileForAisRequestEntry  extends com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry  implements java.io.Serializable {
    private java.lang.String configFileName;

    public DownloadConifgFileForAisRequestEntry() {
    }

    public DownloadConifgFileForAisRequestEntry(
           java.lang.String bindAccount,
           java.lang.String userID,
           java.lang.String configFileName) {
        super(
            bindAccount,
            userID);
        this.configFileName = configFileName;
    }


    /**
     * Gets the configFileName value for this DownloadConifgFileForAisRequestEntry.
     * 
     * @return configFileName
     */
    public java.lang.String getConfigFileName() {
        return configFileName;
    }


    /**
     * Sets the configFileName value for this DownloadConifgFileForAisRequestEntry.
     * 
     * @param configFileName
     */
    public void setConfigFileName(java.lang.String configFileName) {
        this.configFileName = configFileName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DownloadConifgFileForAisRequestEntry)) return false;
        DownloadConifgFileForAisRequestEntry other = (DownloadConifgFileForAisRequestEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.configFileName==null && other.getConfigFileName()==null) || 
             (this.configFileName!=null &&
              this.configFileName.equals(other.getConfigFileName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getConfigFileName() != null) {
            _hashCode += getConfigFileName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DownloadConifgFileForAisRequestEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DownloadConifgFileForAisRequestEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("configFileName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "configFileName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
