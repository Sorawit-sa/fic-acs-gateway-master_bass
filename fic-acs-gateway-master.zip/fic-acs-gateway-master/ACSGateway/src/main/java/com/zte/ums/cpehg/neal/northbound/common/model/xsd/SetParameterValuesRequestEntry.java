/**
 * SetParameterValuesRequestEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zte.ums.cpehg.neal.northbound.common.model.xsd;

public class SetParameterValuesRequestEntry  extends com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry  implements java.io.Serializable {
    private java.lang.String[] paramNames;

    private java.lang.String[] paramValues;

    public SetParameterValuesRequestEntry() {
    }

    public SetParameterValuesRequestEntry(
           java.lang.String bindAccount,
           java.lang.String userID,
           java.lang.String[] paramNames,
           java.lang.String[] paramValues) {
        super(
            bindAccount,
            userID);
        this.paramNames = paramNames;
        this.paramValues = paramValues;
    }


    /**
     * Gets the paramNames value for this SetParameterValuesRequestEntry.
     * 
     * @return paramNames
     */
    public java.lang.String[] getParamNames() {
        return paramNames;
    }


    /**
     * Sets the paramNames value for this SetParameterValuesRequestEntry.
     * 
     * @param paramNames
     */
    public void setParamNames(java.lang.String[] paramNames) {
        this.paramNames = paramNames;
    }

    public java.lang.String getParamNames(int i) {
        return this.paramNames[i];
    }

    public void setParamNames(int i, java.lang.String _value) {
        this.paramNames[i] = _value;
    }


    /**
     * Gets the paramValues value for this SetParameterValuesRequestEntry.
     * 
     * @return paramValues
     */
    public java.lang.String[] getParamValues() {
        return paramValues;
    }


    /**
     * Sets the paramValues value for this SetParameterValuesRequestEntry.
     * 
     * @param paramValues
     */
    public void setParamValues(java.lang.String[] paramValues) {
        this.paramValues = paramValues;
    }

    public java.lang.String getParamValues(int i) {
        return this.paramValues[i];
    }

    public void setParamValues(int i, java.lang.String _value) {
        this.paramValues[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SetParameterValuesRequestEntry)) return false;
        SetParameterValuesRequestEntry other = (SetParameterValuesRequestEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.paramNames==null && other.getParamNames()==null) || 
             (this.paramNames!=null &&
              java.util.Arrays.equals(this.paramNames, other.getParamNames()))) &&
            ((this.paramValues==null && other.getParamValues()==null) || 
             (this.paramValues!=null &&
              java.util.Arrays.equals(this.paramValues, other.getParamValues())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getParamNames() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParamNames());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParamNames(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getParamValues() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParamValues());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParamValues(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SetParameterValuesRequestEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paramNames");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "paramNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paramValues");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "paramValues"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
