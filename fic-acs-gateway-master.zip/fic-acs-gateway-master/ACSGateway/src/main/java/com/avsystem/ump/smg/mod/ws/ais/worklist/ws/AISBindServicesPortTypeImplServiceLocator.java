/**
 * AISBindServicesPortTypeImplServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.avsystem.ump.smg.mod.ws.ais.worklist.ws;

public class AISBindServicesPortTypeImplServiceLocator extends org.apache.axis.client.Service implements com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplService {

    public AISBindServicesPortTypeImplServiceLocator() {
    }


    public AISBindServicesPortTypeImplServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public AISBindServicesPortTypeImplServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for AISBindServicesPortTypeImplPort
    private java.lang.String AISBindServicesPortTypeImplPort_address = "http://10.104.147.35/ACSService/ais/binding/";

    public java.lang.String getAISBindServicesPortTypeImplPortAddress() {
        return AISBindServicesPortTypeImplPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String AISBindServicesPortTypeImplPortWSDDServiceName = "AISBindServicesPortTypeImplPort";

    public java.lang.String getAISBindServicesPortTypeImplPortWSDDServiceName() {
        return AISBindServicesPortTypeImplPortWSDDServiceName;
    }

    public void setAISBindServicesPortTypeImplPortWSDDServiceName(java.lang.String name) {
        AISBindServicesPortTypeImplPortWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesPortTypeImplPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(AISBindServicesPortTypeImplPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getAISBindServicesPortTypeImplPort(endpoint);
    }

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesPortTypeImplPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplServiceSoapBindingStub _stub = new com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getAISBindServicesPortTypeImplPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setAISBindServicesPortTypeImplPortEndpointAddress(java.lang.String address) {
        AISBindServicesPortTypeImplPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplServiceSoapBindingStub _stub = new com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(AISBindServicesPortTypeImplPort_address), this);
                _stub.setPortName(getAISBindServicesPortTypeImplPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("AISBindServicesPortTypeImplPort".equals(inputPortName)) {
            return getAISBindServicesPortTypeImplPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.worklist.ais.ws.mod.smg.ump.avsystem.com/", "AISBindServicesPortTypeImplService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.worklist.ais.ws.mod.smg.ump.avsystem.com/", "AISBindServicesPortTypeImplPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("AISBindServicesPortTypeImplPort".equals(portName)) {
            setAISBindServicesPortTypeImplPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
