package com.avsystem.ump.smg.mod.ws.ais.worklist.ws;

public interface AISBindServicesPortTypeImplService extends javax.xml.rpc.Service {
    public java.lang.String getAISBindServicesPortTypeImplPortAddress();

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesPortTypeImplPort() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesPortTypeImplPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
