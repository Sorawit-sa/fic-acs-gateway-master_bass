/**
 * Cpe112DiagnosisWebServicesSoap11BindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public class Cpe112DiagnosisWebServicesSoap11BindingStub extends org.apache.axis.client.Stub implements northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[30];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("checkCpeServiceInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "vlanID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "serviceName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseCheckEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setParameterValuesByItemNameAsyn");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeOnlineStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "userID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "bindAccount"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setParameterValues");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("qryIMSSub");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "userID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "bindAccount"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "subID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "IMPI"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("login");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "userName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "password"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpesInfoByAccessNumber");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getParameterValuesByItemNameAndWanAccessType");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "wanAccessTypes"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("batchDelaySetParameterValuesByItemName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("testCpeHasPots");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getParameterValuesByItemName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("simpleTestIpPing");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "host"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("checkCpeServiceInfoVCU");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "vlanID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "serviceName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseCheckEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setParameterValuesByItemName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("testWanSetup");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "username"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "password"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "primaryDNS"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "secondDNS"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getI18nParameterValuesByItemNameAndService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "serviceName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("simpleDownload");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeCommonInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("simpleUpload");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getParameterValues");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "GetParameterValuesRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMultiParameterValuesByItemName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setSpecifiedParameterValuesByItemName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpesInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "CpesInfo"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[][].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "cpe"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[22] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getPonLinkInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "userID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "bindAccount"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[23] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeBasicInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "userID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "bindAccount"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "CpeHgBaseInfo"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[24] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getPortMapping");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[25] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMaxBroadbandSpeed");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[26] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getParameterValuesFromDbAndCpeByItemName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[27] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("checkDeviceValid");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "sn"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "stateDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[28] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getParameterValuesByItemNameAndService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "vlanID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "serviceName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[29] = oper;

    }

    public Cpe112DiagnosisWebServicesSoap11BindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public Cpe112DiagnosisWebServicesSoap11BindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public Cpe112DiagnosisWebServicesSoap11BindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ArrayOfResponseMapEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry");
            qName2 = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "array");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "CpeHgBaseInfo");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "CpesInfo");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[][].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ArrayOfResponseMapEntry");
            qName2 = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "cpe");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "GetParameterValuesRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseCheckEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[] checkCpeServiceInfo(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String vlanID, java.lang.String serviceName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:checkCpeServiceInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "checkCpeServiceInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, vlanID, serviceName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer setParameterValuesByItemNameAsyn(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:setParameterValuesByItemNameAsyn");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "setParameterValuesByItemNameAsyn"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer getCpeOnlineStatus(java.lang.String userID, java.lang.String bindAccount) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getCpeOnlineStatus");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getCpeOnlineStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userID, bindAccount});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer setParameterValues(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:setParameterValues");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "setParameterValues"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] qryIMSSub(java.lang.String userID, java.lang.String bindAccount, java.lang.String subID, java.lang.String IMPI) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:qryIMSSub");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "qryIMSSub"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userID, bindAccount, subID, IMPI});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer login(java.lang.String userName, java.lang.String password) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:login");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "login"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userName, password});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getCpesInfoByAccessNumber(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getCpesInfoByAccessNumber");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getCpesInfoByAccessNumber"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValuesByItemNameAndWanAccessType(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName, java.lang.String wanAccessTypes) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getParameterValuesByItemNameAndWanAccessType");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getParameterValuesByItemNameAndWanAccessType"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName, wanAccessTypes});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer batchDelaySetParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:batchDelaySetParameterValuesByItemName");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "batchDelaySetParameterValuesByItemName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testCpeHasPots(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:testCpeHasPots");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "testCpeHasPots"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getParameterValuesByItemName");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getParameterValuesByItemName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] simpleTestIpPing(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String host) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:simpleTestIpPing");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "simpleTestIpPing"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, host});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[] checkCpeServiceInfoVCU(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String vlanID, java.lang.String serviceName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:checkCpeServiceInfoVCU");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "checkCpeServiceInfoVCU"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, vlanID, serviceName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer setParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:setParameterValuesByItemName");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "setParameterValuesByItemName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testWanSetup(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String username, java.lang.String password, java.lang.String primaryDNS, java.lang.String secondDNS) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:testWanSetup");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "testWanSetup"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, username, password, primaryDNS, secondDNS});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getI18NParameterValuesByItemNameAndService(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName, java.lang.String serviceName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getI18nParameterValuesByItemNameAndService");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getI18nParameterValuesByItemNameAndService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName, serviceName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] simpleDownload(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:simpleDownload");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "simpleDownload"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getCpeCommonInfo(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getCpeCommonInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getCpeCommonInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] simpleUpload(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:simpleUpload");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "simpleUpload"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValues(com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getParameterValues");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getParameterValues"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getMultiParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getMultiParameterValuesByItemName");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getMultiParameterValuesByItemName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer setSpecifiedParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:setSpecifiedParameterValuesByItemName");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "setSpecifiedParameterValuesByItemName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[][] getCpesInfo(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getCpesInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getCpesInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[][]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[][]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[][].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getPonLinkInfo(java.lang.String userID, java.lang.String bindAccount) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[23]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getPonLinkInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getPonLinkInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userID, bindAccount});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo getCpeBasicInfo(java.lang.String userID, java.lang.String bindAccount) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[24]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getCpeBasicInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getCpeBasicInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userID, bindAccount});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getPortMapping(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[25]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getPortMapping");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getPortMapping"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getMaxBroadbandSpeed(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[26]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getMaxBroadbandSpeed");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getMaxBroadbandSpeed"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValuesFromDbAndCpeByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[27]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getParameterValuesFromDbAndCpeByItemName");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getParameterValuesFromDbAndCpeByItemName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] checkDeviceValid(java.lang.String sn, java.lang.String stateDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[28]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:checkDeviceValid");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "checkDeviceValid"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sn, stateDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValuesByItemNameAndService(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName, java.lang.String vlanID, java.lang.String serviceName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[29]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getParameterValuesByItemNameAndService");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getParameterValuesByItemNameAndService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName, vlanID, serviceName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
