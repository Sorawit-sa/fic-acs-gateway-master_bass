/**
 * CpeDiagnosisWebServicesLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public class CpeDiagnosisWebServicesLocator extends org.apache.axis.client.Service implements northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServices {

    public CpeDiagnosisWebServicesLocator() {
    }


    public CpeDiagnosisWebServicesLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CpeDiagnosisWebServicesLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CpeDiagnosisWebServicesHttpSoap11Endpoint
    private java.lang.String CpeDiagnosisWebServicesHttpSoap11Endpoint_address = "http://10.252.64.35:9094/axis2/services/CpeDiagnosisWebServices.CpeDiagnosisWebServicesHttpSoap11Endpoint/";

    public java.lang.String getCpeDiagnosisWebServicesHttpSoap11EndpointAddress() {
        return CpeDiagnosisWebServicesHttpSoap11Endpoint_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CpeDiagnosisWebServicesHttpSoap11EndpointWSDDServiceName = "CpeDiagnosisWebServicesHttpSoap11Endpoint";

    public java.lang.String getCpeDiagnosisWebServicesHttpSoap11EndpointWSDDServiceName() {
        return CpeDiagnosisWebServicesHttpSoap11EndpointWSDDServiceName;
    }

    public void setCpeDiagnosisWebServicesHttpSoap11EndpointWSDDServiceName(java.lang.String name) {
        CpeDiagnosisWebServicesHttpSoap11EndpointWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CpeDiagnosisWebServicesHttpSoap11Endpoint_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCpeDiagnosisWebServicesHttpSoap11Endpoint(endpoint);
    }

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap11BindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap11BindingStub(portAddress, this);
            _stub.setPortName(getCpeDiagnosisWebServicesHttpSoap11EndpointWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCpeDiagnosisWebServicesHttpSoap11EndpointEndpointAddress(java.lang.String address) {
        CpeDiagnosisWebServicesHttpSoap11Endpoint_address = address;
    }


    // Use to get a proxy class for CpeDiagnosisWebServicesHttpSoap12Endpoint
    private java.lang.String CpeDiagnosisWebServicesHttpSoap12Endpoint_address = "http://10.252.64.35:9094/axis2/services/CpeDiagnosisWebServices.CpeDiagnosisWebServicesHttpSoap12Endpoint/";

    public java.lang.String getCpeDiagnosisWebServicesHttpSoap12EndpointAddress() {
        return CpeDiagnosisWebServicesHttpSoap12Endpoint_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CpeDiagnosisWebServicesHttpSoap12EndpointWSDDServiceName = "CpeDiagnosisWebServicesHttpSoap12Endpoint";

    public java.lang.String getCpeDiagnosisWebServicesHttpSoap12EndpointWSDDServiceName() {
        return CpeDiagnosisWebServicesHttpSoap12EndpointWSDDServiceName;
    }

    public void setCpeDiagnosisWebServicesHttpSoap12EndpointWSDDServiceName(java.lang.String name) {
        CpeDiagnosisWebServicesHttpSoap12EndpointWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesHttpSoap12Endpoint() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CpeDiagnosisWebServicesHttpSoap12Endpoint_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCpeDiagnosisWebServicesHttpSoap12Endpoint(endpoint);
    }

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesHttpSoap12Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap12BindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap12BindingStub(portAddress, this);
            _stub.setPortName(getCpeDiagnosisWebServicesHttpSoap12EndpointWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCpeDiagnosisWebServicesHttpSoap12EndpointEndpointAddress(java.lang.String address) {
        CpeDiagnosisWebServicesHttpSoap12Endpoint_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap11BindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap11BindingStub(new java.net.URL(CpeDiagnosisWebServicesHttpSoap11Endpoint_address), this);
                _stub.setPortName(getCpeDiagnosisWebServicesHttpSoap11EndpointWSDDServiceName());
                return _stub;
            }
            if (northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap12BindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap12BindingStub(new java.net.URL(CpeDiagnosisWebServicesHttpSoap12Endpoint_address), this);
                _stub.setPortName(getCpeDiagnosisWebServicesHttpSoap12EndpointWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CpeDiagnosisWebServicesHttpSoap11Endpoint".equals(inputPortName)) {
            return getCpeDiagnosisWebServicesHttpSoap11Endpoint();
        }
        else if ("CpeDiagnosisWebServicesHttpSoap12Endpoint".equals(inputPortName)) {
            return getCpeDiagnosisWebServicesHttpSoap12Endpoint();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.diagnosis.interfaces.axis2.northbound", "CpeDiagnosisWebServices");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.diagnosis.interfaces.axis2.northbound", "CpeDiagnosisWebServicesHttpSoap11Endpoint"));
            ports.add(new javax.xml.namespace.QName("http://ws.diagnosis.interfaces.axis2.northbound", "CpeDiagnosisWebServicesHttpSoap12Endpoint"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CpeDiagnosisWebServicesHttpSoap11Endpoint".equals(portName)) {
            setCpeDiagnosisWebServicesHttpSoap11EndpointEndpointAddress(address);
        }
        else 
if ("CpeDiagnosisWebServicesHttpSoap12Endpoint".equals(portName)) {
            setCpeDiagnosisWebServicesHttpSoap12EndpointEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
