/**
 * Cpe112DiagnosisWebServicesLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public class Cpe112DiagnosisWebServicesLocator extends org.apache.axis.client.Service implements northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServices {

    public Cpe112DiagnosisWebServicesLocator() {
    }


    public Cpe112DiagnosisWebServicesLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Cpe112DiagnosisWebServicesLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for Cpe112DiagnosisWebServicesHttpSoap12Endpoint
    private java.lang.String Cpe112DiagnosisWebServicesHttpSoap12Endpoint_address = "http://10.252.64.35:9094/axis2/services/Cpe112DiagnosisWebServices.Cpe112DiagnosisWebServicesHttpSoap12Endpoint/";

    public java.lang.String getCpe112DiagnosisWebServicesHttpSoap12EndpointAddress() {
        return Cpe112DiagnosisWebServicesHttpSoap12Endpoint_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String Cpe112DiagnosisWebServicesHttpSoap12EndpointWSDDServiceName = "Cpe112DiagnosisWebServicesHttpSoap12Endpoint";

    public java.lang.String getCpe112DiagnosisWebServicesHttpSoap12EndpointWSDDServiceName() {
        return Cpe112DiagnosisWebServicesHttpSoap12EndpointWSDDServiceName;
    }

    public void setCpe112DiagnosisWebServicesHttpSoap12EndpointWSDDServiceName(java.lang.String name) {
        Cpe112DiagnosisWebServicesHttpSoap12EndpointWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesHttpSoap12Endpoint() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(Cpe112DiagnosisWebServicesHttpSoap12Endpoint_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCpe112DiagnosisWebServicesHttpSoap12Endpoint(endpoint);
    }

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesHttpSoap12Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesSoap12BindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesSoap12BindingStub(portAddress, this);
            _stub.setPortName(getCpe112DiagnosisWebServicesHttpSoap12EndpointWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCpe112DiagnosisWebServicesHttpSoap12EndpointEndpointAddress(java.lang.String address) {
        Cpe112DiagnosisWebServicesHttpSoap12Endpoint_address = address;
    }


    // Use to get a proxy class for Cpe112DiagnosisWebServicesHttpSoap11Endpoint
    private java.lang.String Cpe112DiagnosisWebServicesHttpSoap11Endpoint_address = "http://10.252.64.35:9094/axis2/services/Cpe112DiagnosisWebServices.Cpe112DiagnosisWebServicesHttpSoap11Endpoint/";

    public java.lang.String getCpe112DiagnosisWebServicesHttpSoap11EndpointAddress() {
        return Cpe112DiagnosisWebServicesHttpSoap11Endpoint_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String Cpe112DiagnosisWebServicesHttpSoap11EndpointWSDDServiceName = "Cpe112DiagnosisWebServicesHttpSoap11Endpoint";

    public java.lang.String getCpe112DiagnosisWebServicesHttpSoap11EndpointWSDDServiceName() {
        return Cpe112DiagnosisWebServicesHttpSoap11EndpointWSDDServiceName;
    }

    public void setCpe112DiagnosisWebServicesHttpSoap11EndpointWSDDServiceName(java.lang.String name) {
        Cpe112DiagnosisWebServicesHttpSoap11EndpointWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(Cpe112DiagnosisWebServicesHttpSoap11Endpoint_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCpe112DiagnosisWebServicesHttpSoap11Endpoint(endpoint);
    }

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesSoap11BindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesSoap11BindingStub(portAddress, this);
            _stub.setPortName(getCpe112DiagnosisWebServicesHttpSoap11EndpointWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCpe112DiagnosisWebServicesHttpSoap11EndpointEndpointAddress(java.lang.String address) {
        Cpe112DiagnosisWebServicesHttpSoap11Endpoint_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesSoap12BindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesSoap12BindingStub(new java.net.URL(Cpe112DiagnosisWebServicesHttpSoap12Endpoint_address), this);
                _stub.setPortName(getCpe112DiagnosisWebServicesHttpSoap12EndpointWSDDServiceName());
                return _stub;
            }
            if (northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesSoap11BindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesSoap11BindingStub(new java.net.URL(Cpe112DiagnosisWebServicesHttpSoap11Endpoint_address), this);
                _stub.setPortName(getCpe112DiagnosisWebServicesHttpSoap11EndpointWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("Cpe112DiagnosisWebServicesHttpSoap12Endpoint".equals(inputPortName)) {
            return getCpe112DiagnosisWebServicesHttpSoap12Endpoint();
        }
        else if ("Cpe112DiagnosisWebServicesHttpSoap11Endpoint".equals(inputPortName)) {
            return getCpe112DiagnosisWebServicesHttpSoap11Endpoint();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.diagnosis.interfaces.axis2.northbound", "Cpe112DiagnosisWebServices");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.diagnosis.interfaces.axis2.northbound", "Cpe112DiagnosisWebServicesHttpSoap12Endpoint"));
            ports.add(new javax.xml.namespace.QName("http://ws.diagnosis.interfaces.axis2.northbound", "Cpe112DiagnosisWebServicesHttpSoap11Endpoint"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("Cpe112DiagnosisWebServicesHttpSoap12Endpoint".equals(portName)) {
            setCpe112DiagnosisWebServicesHttpSoap12EndpointEndpointAddress(address);
        }
        else 
if ("Cpe112DiagnosisWebServicesHttpSoap11Endpoint".equals(portName)) {
            setCpe112DiagnosisWebServicesHttpSoap11EndpointEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
