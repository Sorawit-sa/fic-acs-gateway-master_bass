/**
 * CpeWorkListWebServicesPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.worklist.ws;

public interface CpeWorkListWebServicesPortType extends java.rmi.Remote {
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry promptlyServiceChange(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeRequestEntry servicechangerequestentry) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry customerServiceChange(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigTemplateChangeRequestEntry configTemplateChangeRequestEntry) throws java.rmi.RemoteException;
    public java.lang.Integer login(java.lang.String userName, java.lang.String password) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpehgServiceCustomResponce queryServiceStatus(java.lang.String userid, java.lang.String bindaccount, java.lang.String type, java.lang.String parameters) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry serviceChangeForThirdParty(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ThirdPartyServiceChangeRequestEntry servicechangerequestentry) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry serviceChange(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeRequestEntry servicechangerequestentry) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry configTemplateServiceChange(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigTemplateChangeRequestEntry configTemplateChangeRequestEntry) throws java.rmi.RemoteException;
}
