/**
 * CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public class CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub extends org.apache.axis.client.Stub implements northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[16];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("login");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "userName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "password"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("factoryReset");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisFactoryResetRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisFactoryResetRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("testIpPing");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisIpPingRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisIpPingRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("downloadCFGToDevice");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DownloadConifgFileForAisRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadConifgFileForAisRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("reboot");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisRebootRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisRebootRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("testAtmLoop");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisATMRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisATMRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("testIpPingByService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisIpPingServiceRequest"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisIpPingServiceRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("testDsl");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCFGList");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ConfigFilesListResponseEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("uploadCFG");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("querySuitableVersions");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("download");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("set8EventGetByItemName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "itemName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("queryDownloadResult");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeLogInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("downloadVersion");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DownloadRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

    }

    public CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ArrayOfResponseMapEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry");
            qName2 = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "array");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "BaseRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ConfigFilesListResponseEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisATMRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisATMRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisFactoryResetRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisFactoryResetRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisIpPingRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisIpPingRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisIpPingServiceRequest");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisIpPingServiceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DiagnosisRebootRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisRebootRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DownloadConifgFileForAisRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadConifgFileForAisRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "DownloadRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "GetParameterValuesRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ResponseMapEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "SetParameterValuesRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public java.lang.Integer login(java.lang.String userName, java.lang.String password) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:login");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "login"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userName, password});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer factoryReset(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisFactoryResetRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:factoryReset");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "factoryReset"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testIpPing(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisIpPingRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:testIpPing");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "testIpPing"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] downloadCFGToDevice(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadConifgFileForAisRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:downloadCFGToDevice");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "downloadCFGToDevice"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer reboot(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisRebootRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:reboot");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "reboot"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testAtmLoop(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisATMRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:testAtmLoop");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "testAtmLoop"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testIpPingByService(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisIpPingServiceRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:testIpPingByService");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "testIpPingByService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testDsl(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:testDsl");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "testDsl"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry getCFGList(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getCFGList");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getCFGList"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] uploadCFG(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:uploadCFG");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "uploadCFG"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] querySuitableVersions(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:querySuitableVersions");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "querySuitableVersions"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer download(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:download");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "download"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] set8EventGetByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:set8EventGetByItemName");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "set8EventGetByItemName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request, itemName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] queryDownloadResult(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:queryDownloadResult");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "queryDownloadResult"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getCpeLogInfo(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getCpeLogInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "getCpeLogInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer downloadVersion(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadRequestEntry request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:downloadVersion");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://diagnosis.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "downloadVersion"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
