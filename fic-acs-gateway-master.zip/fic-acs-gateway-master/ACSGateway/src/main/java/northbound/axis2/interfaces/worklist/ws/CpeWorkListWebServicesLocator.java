/**
 * CpeWorkListWebServicesLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.worklist.ws;

public class CpeWorkListWebServicesLocator extends org.apache.axis.client.Service implements northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServices {

    public CpeWorkListWebServicesLocator() {
    }


    public CpeWorkListWebServicesLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CpeWorkListWebServicesLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CpeWorkListWebServicesHttpSoap11Endpoint
    private java.lang.String CpeWorkListWebServicesHttpSoap11Endpoint_address = "http://10.252.64.35:9094/axis2/services/CpeWorkListWebServices.CpeWorkListWebServicesHttpSoap11Endpoint/";

    public java.lang.String getCpeWorkListWebServicesHttpSoap11EndpointAddress() {
        return CpeWorkListWebServicesHttpSoap11Endpoint_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CpeWorkListWebServicesHttpSoap11EndpointWSDDServiceName = "CpeWorkListWebServicesHttpSoap11Endpoint";

    public java.lang.String getCpeWorkListWebServicesHttpSoap11EndpointWSDDServiceName() {
        return CpeWorkListWebServicesHttpSoap11EndpointWSDDServiceName;
    }

    public void setCpeWorkListWebServicesHttpSoap11EndpointWSDDServiceName(java.lang.String name) {
        CpeWorkListWebServicesHttpSoap11EndpointWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType getCpeWorkListWebServicesHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CpeWorkListWebServicesHttpSoap11Endpoint_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCpeWorkListWebServicesHttpSoap11Endpoint(endpoint);
    }

    public northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType getCpeWorkListWebServicesHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap11BindingStub _stub = new northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap11BindingStub(portAddress, this);
            _stub.setPortName(getCpeWorkListWebServicesHttpSoap11EndpointWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCpeWorkListWebServicesHttpSoap11EndpointEndpointAddress(java.lang.String address) {
        CpeWorkListWebServicesHttpSoap11Endpoint_address = address;
    }


    // Use to get a proxy class for CpeWorkListWebServicesHttpSoap12Endpoint
    private java.lang.String CpeWorkListWebServicesHttpSoap12Endpoint_address = "http://10.252.64.35:9094/axis2/services/CpeWorkListWebServices.CpeWorkListWebServicesHttpSoap12Endpoint/";

    public java.lang.String getCpeWorkListWebServicesHttpSoap12EndpointAddress() {
        return CpeWorkListWebServicesHttpSoap12Endpoint_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CpeWorkListWebServicesHttpSoap12EndpointWSDDServiceName = "CpeWorkListWebServicesHttpSoap12Endpoint";

    public java.lang.String getCpeWorkListWebServicesHttpSoap12EndpointWSDDServiceName() {
        return CpeWorkListWebServicesHttpSoap12EndpointWSDDServiceName;
    }

    public void setCpeWorkListWebServicesHttpSoap12EndpointWSDDServiceName(java.lang.String name) {
        CpeWorkListWebServicesHttpSoap12EndpointWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType getCpeWorkListWebServicesHttpSoap12Endpoint() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CpeWorkListWebServicesHttpSoap12Endpoint_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCpeWorkListWebServicesHttpSoap12Endpoint(endpoint);
    }

    public northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType getCpeWorkListWebServicesHttpSoap12Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap12BindingStub _stub = new northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap12BindingStub(portAddress, this);
            _stub.setPortName(getCpeWorkListWebServicesHttpSoap12EndpointWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCpeWorkListWebServicesHttpSoap12EndpointEndpointAddress(java.lang.String address) {
        CpeWorkListWebServicesHttpSoap12Endpoint_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap11BindingStub _stub = new northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap11BindingStub(new java.net.URL(CpeWorkListWebServicesHttpSoap11Endpoint_address), this);
                _stub.setPortName(getCpeWorkListWebServicesHttpSoap11EndpointWSDDServiceName());
                return _stub;
            }
            if (northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap12BindingStub _stub = new northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap12BindingStub(new java.net.URL(CpeWorkListWebServicesHttpSoap12Endpoint_address), this);
                _stub.setPortName(getCpeWorkListWebServicesHttpSoap12EndpointWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CpeWorkListWebServicesHttpSoap11Endpoint".equals(inputPortName)) {
            return getCpeWorkListWebServicesHttpSoap11Endpoint();
        }
        else if ("CpeWorkListWebServicesHttpSoap12Endpoint".equals(inputPortName)) {
            return getCpeWorkListWebServicesHttpSoap12Endpoint();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.worklist.interfaces.axis2.northbound", "CpeWorkListWebServices");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.worklist.interfaces.axis2.northbound", "CpeWorkListWebServicesHttpSoap11Endpoint"));
            ports.add(new javax.xml.namespace.QName("http://ws.worklist.interfaces.axis2.northbound", "CpeWorkListWebServicesHttpSoap12Endpoint"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CpeWorkListWebServicesHttpSoap11Endpoint".equals(portName)) {
            setCpeWorkListWebServicesHttpSoap11EndpointEndpointAddress(address);
        }
        else 
if ("CpeWorkListWebServicesHttpSoap12Endpoint".equals(portName)) {
            setCpeWorkListWebServicesHttpSoap12EndpointEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
