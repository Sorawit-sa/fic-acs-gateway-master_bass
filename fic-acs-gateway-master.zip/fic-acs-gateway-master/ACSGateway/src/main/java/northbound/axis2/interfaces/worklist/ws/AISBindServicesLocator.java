/**
 * AISBindServicesLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.worklist.ws;

public class AISBindServicesLocator extends org.apache.axis.client.Service implements northbound.axis2.interfaces.worklist.ws.AISBindServices {

    public AISBindServicesLocator() {
    }


    public AISBindServicesLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public AISBindServicesLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for AISBindServicesHttpSoap12Endpoint
    private java.lang.String AISBindServicesHttpSoap12Endpoint_address = "http://10.252.64.35:9094/axis2/services/AISBindServices.AISBindServicesHttpSoap12Endpoint/";

    public java.lang.String getAISBindServicesHttpSoap12EndpointAddress() {
        return AISBindServicesHttpSoap12Endpoint_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String AISBindServicesHttpSoap12EndpointWSDDServiceName = "AISBindServicesHttpSoap12Endpoint";

    public java.lang.String getAISBindServicesHttpSoap12EndpointWSDDServiceName() {
        return AISBindServicesHttpSoap12EndpointWSDDServiceName;
    }

    public void setAISBindServicesHttpSoap12EndpointWSDDServiceName(java.lang.String name) {
        AISBindServicesHttpSoap12EndpointWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesHttpSoap12Endpoint() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(AISBindServicesHttpSoap12Endpoint_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getAISBindServicesHttpSoap12Endpoint(endpoint);
    }

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesHttpSoap12Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap12BindingStub _stub = new northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap12BindingStub(portAddress, this);
            _stub.setPortName(getAISBindServicesHttpSoap12EndpointWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setAISBindServicesHttpSoap12EndpointEndpointAddress(java.lang.String address) {
        AISBindServicesHttpSoap12Endpoint_address = address;
    }


    // Use to get a proxy class for AISBindServicesHttpSoap11Endpoint
    private java.lang.String AISBindServicesHttpSoap11Endpoint_address = "http://10.252.64.35:9094/axis2/services/AISBindServices.AISBindServicesHttpSoap11Endpoint/";

    public java.lang.String getAISBindServicesHttpSoap11EndpointAddress() {
        return AISBindServicesHttpSoap11Endpoint_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String AISBindServicesHttpSoap11EndpointWSDDServiceName = "AISBindServicesHttpSoap11Endpoint";

    public java.lang.String getAISBindServicesHttpSoap11EndpointWSDDServiceName() {
        return AISBindServicesHttpSoap11EndpointWSDDServiceName;
    }

    public void setAISBindServicesHttpSoap11EndpointWSDDServiceName(java.lang.String name) {
        AISBindServicesHttpSoap11EndpointWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(AISBindServicesHttpSoap11Endpoint_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getAISBindServicesHttpSoap11Endpoint(endpoint);
    }

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap11BindingStub _stub = new northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap11BindingStub(portAddress, this);
            _stub.setPortName(getAISBindServicesHttpSoap11EndpointWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setAISBindServicesHttpSoap11EndpointEndpointAddress(java.lang.String address) {
        AISBindServicesHttpSoap11Endpoint_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap12BindingStub _stub = new northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap12BindingStub(new java.net.URL(AISBindServicesHttpSoap12Endpoint_address), this);
                _stub.setPortName(getAISBindServicesHttpSoap12EndpointWSDDServiceName());
                return _stub;
            }
            if (northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap11BindingStub _stub = new northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap11BindingStub(new java.net.URL(AISBindServicesHttpSoap11Endpoint_address), this);
                _stub.setPortName(getAISBindServicesHttpSoap11EndpointWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("AISBindServicesHttpSoap12Endpoint".equals(inputPortName)) {
            return getAISBindServicesHttpSoap12Endpoint();
        }
        else if ("AISBindServicesHttpSoap11Endpoint".equals(inputPortName)) {
            return getAISBindServicesHttpSoap11Endpoint();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.worklist.interfaces.axis2.northbound", "AISBindServices");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.worklist.interfaces.axis2.northbound", "AISBindServicesHttpSoap12Endpoint"));
            ports.add(new javax.xml.namespace.QName("http://ws.worklist.interfaces.axis2.northbound", "AISBindServicesHttpSoap11Endpoint"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("AISBindServicesHttpSoap12Endpoint".equals(portName)) {
            setAISBindServicesHttpSoap12EndpointEndpointAddress(address);
        }
        else 
if ("AISBindServicesHttpSoap11Endpoint".equals(portName)) {
            setAISBindServicesHttpSoap11EndpointEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
