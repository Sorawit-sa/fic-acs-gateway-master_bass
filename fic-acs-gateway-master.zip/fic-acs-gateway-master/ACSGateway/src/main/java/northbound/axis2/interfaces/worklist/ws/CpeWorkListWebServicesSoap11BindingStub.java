/**
 * CpeWorkListWebServicesSoap11BindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.worklist.ws;

public class CpeWorkListWebServicesSoap11BindingStub extends org.apache.axis.client.Stub implements northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[7];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("PromptlyServiceChange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "servicechangerequestentry"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeResponceEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CustomerServiceChange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "configTemplateChangeRequestEntry"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ConfigTemplateChangeRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigTemplateChangeRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeResponceEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("login");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "userName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "password"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(java.lang.Integer.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("QueryServiceStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "userid"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "bindaccount"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "type"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "parameters"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "CpehgServiceCustomResponce"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpehgServiceCustomResponce.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ServiceChangeForThirdParty");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "servicechangerequestentry"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ThirdPartyServiceChangeRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.ThirdPartyServiceChangeRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeResponceEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ServiceChange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "servicechangerequestentry"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeResponceEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ConfigTemplateServiceChange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "configTemplateChangeRequestEntry"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ConfigTemplateChangeRequestEntry"), com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigTemplateChangeRequestEntry.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeResponceEntry"));
        oper.setReturnClass(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

    }

    public CpeWorkListWebServicesSoap11BindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public CpeWorkListWebServicesSoap11BindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public CpeWorkListWebServicesSoap11BindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ConfigTemplateChangeRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigTemplateChangeRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "CpehgServiceCustomResponce");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpehgServiceCustomResponce.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "OperateResponce");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.OperateResponce.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ServiceChangeResponceEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.common.northbound.neal.cpehg.ums.zte.com/xsd", "ThirdPartyServiceChangeRequestEntry");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.neal.northbound.common.model.xsd.ThirdPartyServiceChangeRequestEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "CpeHgService");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgService.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "CpeHgServiceCustom");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceCustom.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://model.worklist.nefl.cpehg.ums.zte.com/xsd", "CpeHgServiceKey");
            cachedSerQNames.add(qName);
            cls = com.zte.ums.cpehg.nefl.worklist.model.xsd.CpeHgServiceKey.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry promptlyServiceChange(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeRequestEntry servicechangerequestentry) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:PromptlyServiceChange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "PromptlyServiceChange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {servicechangerequestentry});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry customerServiceChange(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigTemplateChangeRequestEntry configTemplateChangeRequestEntry) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:CustomerServiceChange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "CustomerServiceChange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {configTemplateChangeRequestEntry});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.Integer login(java.lang.String userName, java.lang.String password) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:login");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "login"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userName, password});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.Integer) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpehgServiceCustomResponce queryServiceStatus(java.lang.String userid, java.lang.String bindaccount, java.lang.String type, java.lang.String parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:QueryServiceStatus");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "QueryServiceStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userid, bindaccount, type, parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpehgServiceCustomResponce) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpehgServiceCustomResponce) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpehgServiceCustomResponce.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry serviceChangeForThirdParty(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ThirdPartyServiceChangeRequestEntry servicechangerequestentry) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:ServiceChangeForThirdParty");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "ServiceChangeForThirdParty"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {servicechangerequestentry});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry serviceChange(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeRequestEntry servicechangerequestentry) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:ServiceChange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "ServiceChange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {servicechangerequestentry});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry configTemplateServiceChange(com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigTemplateChangeRequestEntry configTemplateChangeRequestEntry) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:ConfigTemplateServiceChange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://excute.worklist.interfaces.axis2.osf.northbound.neal.cpehg.ums.zte.com", "ConfigTemplateServiceChange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {configTemplateChangeRequestEntry});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry) org.apache.axis.utils.JavaUtils.convert(_resp, com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
