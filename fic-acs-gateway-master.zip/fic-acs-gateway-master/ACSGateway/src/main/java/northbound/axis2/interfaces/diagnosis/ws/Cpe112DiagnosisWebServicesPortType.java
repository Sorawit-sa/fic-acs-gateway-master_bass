/**
 * Cpe112DiagnosisWebServicesPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public interface Cpe112DiagnosisWebServicesPortType extends java.rmi.Remote {
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo getCpeBasicInfo(java.lang.String userID, java.lang.String bindAccount) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[][] getCpesInfo(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getPonLinkInfo(java.lang.String userID, java.lang.String bindAccount) throws java.rmi.RemoteException;
    public java.lang.Integer setSpecifiedParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValues(com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getMultiParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValuesByItemNameAndService(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName, java.lang.String vlanID, java.lang.String serviceName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] checkDeviceValid(java.lang.String sn, java.lang.String stateDate) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValuesFromDbAndCpeByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException;
    public java.lang.String getMaxBroadbandSpeed(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getPortMapping(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getCpesInfoByAccessNumber(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public java.lang.Integer login(java.lang.String userName, java.lang.String password) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] qryIMSSub(java.lang.String userID, java.lang.String bindAccount, java.lang.String subID, java.lang.String IMPI) throws java.rmi.RemoteException;
    public java.lang.Integer getCpeOnlineStatus(java.lang.String userID, java.lang.String bindAccount) throws java.rmi.RemoteException;
    public java.lang.Integer setParameterValues(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request) throws java.rmi.RemoteException;
    public java.lang.Integer setParameterValuesByItemNameAsyn(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[] checkCpeServiceInfo(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String vlanID, java.lang.String serviceName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getCpeCommonInfo(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] simpleUpload(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getI18NParameterValuesByItemNameAndService(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName, java.lang.String serviceName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] simpleDownload(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public java.lang.Integer setParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testWanSetup(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String username, java.lang.String password, java.lang.String primaryDNS, java.lang.String secondDNS) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseCheckEntry[] checkCpeServiceInfoVCU(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String vlanID, java.lang.String serviceName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] simpleTestIpPing(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String host) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testCpeHasPots(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException;
    public java.lang.Integer batchDelaySetParameterValuesByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] getParameterValuesByItemNameAndWanAccessType(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request, java.lang.String itemName, java.lang.String wanAccessTypes) throws java.rmi.RemoteException;
}
