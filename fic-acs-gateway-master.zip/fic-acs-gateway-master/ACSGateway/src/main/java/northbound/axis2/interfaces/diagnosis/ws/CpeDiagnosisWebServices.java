/**
 * CpeDiagnosisWebServices.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public interface CpeDiagnosisWebServices extends javax.xml.rpc.Service {
    public java.lang.String getCpeDiagnosisWebServicesHttpSoap11EndpointAddress();

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getCpeDiagnosisWebServicesHttpSoap12EndpointAddress();

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesHttpSoap12Endpoint() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesHttpSoap12Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
