/**
 * Cpe112DiagnosisWebServicesPortTypeImplServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public class Cpe112DiagnosisWebServicesPortTypeImplServiceLocator extends org.apache.axis.client.Service implements northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplService {

    public Cpe112DiagnosisWebServicesPortTypeImplServiceLocator() {
    }


    public Cpe112DiagnosisWebServicesPortTypeImplServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Cpe112DiagnosisWebServicesPortTypeImplServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for Cpe112DiagnosisWebServicesPortTypePort
    private java.lang.String Cpe112DiagnosisWebServicesPortTypePort_address = "http://10.104.147.35/ACSService/ais/cpeDiagnosis112/";

    public java.lang.String getCpe112DiagnosisWebServicesPortTypePortAddress() {
        return Cpe112DiagnosisWebServicesPortTypePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String Cpe112DiagnosisWebServicesPortTypePortWSDDServiceName = "Cpe112DiagnosisWebServicesPortTypePort";

    public java.lang.String getCpe112DiagnosisWebServicesPortTypePortWSDDServiceName() {
        return Cpe112DiagnosisWebServicesPortTypePortWSDDServiceName;
    }

    public void setCpe112DiagnosisWebServicesPortTypePortWSDDServiceName(java.lang.String name) {
        Cpe112DiagnosisWebServicesPortTypePortWSDDServiceName = name;
    }

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesPortTypePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(Cpe112DiagnosisWebServicesPortTypePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCpe112DiagnosisWebServicesPortTypePort(endpoint);
    }

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesPortTypePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getCpe112DiagnosisWebServicesPortTypePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCpe112DiagnosisWebServicesPortTypePortEndpointAddress(java.lang.String address) {
        Cpe112DiagnosisWebServicesPortTypePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub _stub = new northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(Cpe112DiagnosisWebServicesPortTypePort_address), this);
                _stub.setPortName(getCpe112DiagnosisWebServicesPortTypePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("Cpe112DiagnosisWebServicesPortTypePort".equals(inputPortName)) {
            return getCpe112DiagnosisWebServicesPortTypePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.diagnosis.interfaces.axis2.northbound", "Cpe112DiagnosisWebServicesPortTypeImplService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.diagnosis.interfaces.axis2.northbound", "Cpe112DiagnosisWebServicesPortTypePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("Cpe112DiagnosisWebServicesPortTypePort".equals(portName)) {
            setCpe112DiagnosisWebServicesPortTypePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
