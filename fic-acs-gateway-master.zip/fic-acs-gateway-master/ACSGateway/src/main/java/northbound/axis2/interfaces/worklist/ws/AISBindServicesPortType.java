/**
 * AISBindServicesPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.worklist.ws;

public interface AISBindServicesPortType extends java.rmi.Remote {
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.OperateResponce binding(java.lang.String actionID, java.lang.String sn, java.lang.String fibrenetID) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] queryworkliststatus(java.lang.String actionID) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] querymacs(java.lang.String mac) throws java.rmi.RemoteException;
}
