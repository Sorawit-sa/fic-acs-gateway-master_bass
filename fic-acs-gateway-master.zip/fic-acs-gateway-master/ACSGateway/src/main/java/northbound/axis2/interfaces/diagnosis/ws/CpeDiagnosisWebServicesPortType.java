/**
 * CpeDiagnosisWebServicesPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public interface CpeDiagnosisWebServicesPortType extends java.rmi.Remote {
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testAtmLoop(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisATMRequestEntry request) throws java.rmi.RemoteException;
    public java.lang.Integer reboot(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisRebootRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testIpPingByService(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisIpPingServiceRequest request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] downloadCFGToDevice(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadConifgFileForAisRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testIpPing(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisIpPingRequestEntry request) throws java.rmi.RemoteException;
    public java.lang.Integer factoryReset(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisFactoryResetRequestEntry request) throws java.rmi.RemoteException;
    public java.lang.Integer login(java.lang.String userName, java.lang.String password) throws java.rmi.RemoteException;
    public java.lang.String getCpeLogInfo(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] queryDownloadResult(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public java.lang.Integer downloadVersion(com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadRequestEntry request) throws java.rmi.RemoteException;
    public java.lang.Integer download(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] set8EventGetByItemName(com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry request, java.lang.String itemName) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] querySuitableVersions(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] uploadCFG(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry getCFGList(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
    public com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry[] testDsl(com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry request) throws java.rmi.RemoteException;
}
