/**
 * Cpe112DiagnosisWebServicesPortTypeImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public interface Cpe112DiagnosisWebServicesPortTypeImplService extends javax.xml.rpc.Service {
    public java.lang.String getCpe112DiagnosisWebServicesPortTypePortAddress();

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesPortTypePort() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesPortTypePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
