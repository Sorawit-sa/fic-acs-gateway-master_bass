/**
 * CpeWorkListWebServices.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.worklist.ws;

public interface CpeWorkListWebServices extends javax.xml.rpc.Service {
    public java.lang.String getCpeWorkListWebServicesHttpSoap11EndpointAddress();

    public northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType getCpeWorkListWebServicesHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType getCpeWorkListWebServicesHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getCpeWorkListWebServicesHttpSoap12EndpointAddress();

    public northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType getCpeWorkListWebServicesHttpSoap12Endpoint() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType getCpeWorkListWebServicesHttpSoap12Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
