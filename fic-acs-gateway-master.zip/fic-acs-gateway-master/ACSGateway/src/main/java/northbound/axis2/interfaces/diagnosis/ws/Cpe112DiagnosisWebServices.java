/**
 * Cpe112DiagnosisWebServices.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public interface Cpe112DiagnosisWebServices extends javax.xml.rpc.Service {
    public java.lang.String getCpe112DiagnosisWebServicesHttpSoap12EndpointAddress();

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesHttpSoap12Endpoint() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesHttpSoap12Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getCpe112DiagnosisWebServicesHttpSoap11EndpointAddress();

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType getCpe112DiagnosisWebServicesHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
