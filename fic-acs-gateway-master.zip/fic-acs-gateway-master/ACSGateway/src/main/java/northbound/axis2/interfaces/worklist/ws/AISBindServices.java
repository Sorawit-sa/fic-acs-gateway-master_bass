/**
 * AISBindServices.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.worklist.ws;

public interface AISBindServices extends javax.xml.rpc.Service {
    public java.lang.String getAISBindServicesHttpSoap12EndpointAddress();

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesHttpSoap12Endpoint() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesHttpSoap12Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getAISBindServicesHttpSoap11EndpointAddress();

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.worklist.ws.AISBindServicesPortType getAISBindServicesHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
