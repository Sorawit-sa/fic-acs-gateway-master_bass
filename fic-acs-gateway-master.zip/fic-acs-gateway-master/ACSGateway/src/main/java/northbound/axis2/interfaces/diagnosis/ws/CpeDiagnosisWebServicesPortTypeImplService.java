/**
 * CpeDiagnosisWebServicesPortTypeImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package northbound.axis2.interfaces.diagnosis.ws;

public interface CpeDiagnosisWebServicesPortTypeImplService extends javax.xml.rpc.Service {
    public java.lang.String getCpeDiagnosisWebServicesPortTypePortAddress();

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesPortTypePort() throws javax.xml.rpc.ServiceException;

    public northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType getCpeDiagnosisWebServicesPortTypePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
