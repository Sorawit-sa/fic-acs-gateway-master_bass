/**
 * VoipPwdInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class VoipPwdInfo  implements java.io.Serializable {
    private int errorCode;

    private java.lang.String strEncryptVoipPwd;

    public VoipPwdInfo() {
    }

    public VoipPwdInfo(
           int errorCode,
           java.lang.String strEncryptVoipPwd) {
           this.errorCode = errorCode;
           this.strEncryptVoipPwd = strEncryptVoipPwd;
    }


    /**
     * Gets the errorCode value for this VoipPwdInfo.
     * 
     * @return errorCode
     */
    public int getErrorCode() {
        return errorCode;
    }


    /**
     * Sets the errorCode value for this VoipPwdInfo.
     * 
     * @param errorCode
     */
    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }


    /**
     * Gets the strEncryptVoipPwd value for this VoipPwdInfo.
     * 
     * @return strEncryptVoipPwd
     */
    public java.lang.String getStrEncryptVoipPwd() {
        return strEncryptVoipPwd;
    }


    /**
     * Sets the strEncryptVoipPwd value for this VoipPwdInfo.
     * 
     * @param strEncryptVoipPwd
     */
    public void setStrEncryptVoipPwd(java.lang.String strEncryptVoipPwd) {
        this.strEncryptVoipPwd = strEncryptVoipPwd;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VoipPwdInfo)) return false;
        VoipPwdInfo other = (VoipPwdInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.errorCode == other.getErrorCode() &&
            ((this.strEncryptVoipPwd==null && other.getStrEncryptVoipPwd()==null) || 
             (this.strEncryptVoipPwd!=null &&
              this.strEncryptVoipPwd.equals(other.getStrEncryptVoipPwd())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getErrorCode();
        if (getStrEncryptVoipPwd() != null) {
            _hashCode += getStrEncryptVoipPwd().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VoipPwdInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "VoipPwdInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "errorCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("strEncryptVoipPwd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "strEncryptVoipPwd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
