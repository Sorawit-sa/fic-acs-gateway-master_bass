package th.co.ais.acs.rest.restapi;

import org.glassfish.jersey.server.ResourceConfig;

import th.co.ais.acs.rest.filter.AuthenticationFilter;


/**
 *  set the filter applications manually and not via web.xml
 */
public class RestApplicationConfig extends ResourceConfig {
	
	public RestApplicationConfig() {
        packages( "th.co.ais.acs.rest.filter" );
		register( AuthenticationFilter.class );
	}
}
