/**
 * CpeOnlineInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class CpeOnlineInfo  implements java.io.Serializable {
    private th.co.tbb.acshw.model.DiagnoseService.CpeBasicInfo basicInfo;

    private int errorCode;

    private th.co.tbb.acshw.model.DiagnoseService.ServiceInfo[] serviceInfoList;

    private th.co.tbb.acshw.model.DiagnoseService.UserInfo userInfo;

    public CpeOnlineInfo() {
    }

    public CpeOnlineInfo(
           th.co.tbb.acshw.model.DiagnoseService.CpeBasicInfo basicInfo,
           int errorCode,
           th.co.tbb.acshw.model.DiagnoseService.ServiceInfo[] serviceInfoList,
           th.co.tbb.acshw.model.DiagnoseService.UserInfo userInfo) {
           this.basicInfo = basicInfo;
           this.errorCode = errorCode;
           this.serviceInfoList = serviceInfoList;
           this.userInfo = userInfo;
    }


    /**
     * Gets the basicInfo value for this CpeOnlineInfo.
     * 
     * @return basicInfo
     */
    public th.co.tbb.acshw.model.DiagnoseService.CpeBasicInfo getBasicInfo() {
        return basicInfo;
    }


    /**
     * Sets the basicInfo value for this CpeOnlineInfo.
     * 
     * @param basicInfo
     */
    public void setBasicInfo(th.co.tbb.acshw.model.DiagnoseService.CpeBasicInfo basicInfo) {
        this.basicInfo = basicInfo;
    }


    /**
     * Gets the errorCode value for this CpeOnlineInfo.
     * 
     * @return errorCode
     */
    public int getErrorCode() {
        return errorCode;
    }


    /**
     * Sets the errorCode value for this CpeOnlineInfo.
     * 
     * @param errorCode
     */
    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }


    /**
     * Gets the serviceInfoList value for this CpeOnlineInfo.
     * 
     * @return serviceInfoList
     */
    public th.co.tbb.acshw.model.DiagnoseService.ServiceInfo[] getServiceInfoList() {
        return serviceInfoList;
    }


    /**
     * Sets the serviceInfoList value for this CpeOnlineInfo.
     * 
     * @param serviceInfoList
     */
    public void setServiceInfoList(th.co.tbb.acshw.model.DiagnoseService.ServiceInfo[] serviceInfoList) {
        this.serviceInfoList = serviceInfoList;
    }


    /**
     * Gets the userInfo value for this CpeOnlineInfo.
     * 
     * @return userInfo
     */
    public th.co.tbb.acshw.model.DiagnoseService.UserInfo getUserInfo() {
        return userInfo;
    }


    /**
     * Sets the userInfo value for this CpeOnlineInfo.
     * 
     * @param userInfo
     */
    public void setUserInfo(th.co.tbb.acshw.model.DiagnoseService.UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CpeOnlineInfo)) return false;
        CpeOnlineInfo other = (CpeOnlineInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.basicInfo==null && other.getBasicInfo()==null) || 
             (this.basicInfo!=null &&
              this.basicInfo.equals(other.getBasicInfo()))) &&
            this.errorCode == other.getErrorCode() &&
            ((this.serviceInfoList==null && other.getServiceInfoList()==null) || 
             (this.serviceInfoList!=null &&
              java.util.Arrays.equals(this.serviceInfoList, other.getServiceInfoList()))) &&
            ((this.userInfo==null && other.getUserInfo()==null) || 
             (this.userInfo!=null &&
              this.userInfo.equals(other.getUserInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBasicInfo() != null) {
            _hashCode += getBasicInfo().hashCode();
        }
        _hashCode += getErrorCode();
        if (getServiceInfoList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getServiceInfoList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getServiceInfoList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getUserInfo() != null) {
            _hashCode += getUserInfo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CpeOnlineInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "CpeOnlineInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("basicInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "basicInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "CpeBasicInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "errorCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceInfoList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "serviceInfoList"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "ServiceInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "UserInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
