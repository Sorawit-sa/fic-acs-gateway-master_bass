package th.co.ais.acs.rest.model;

public class Credentials {
	private String userId = null;
	private String password = null;

	
	public Credentials() {}
	
	public Credentials(String userId, String password) {
		this.userId = userId;
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
