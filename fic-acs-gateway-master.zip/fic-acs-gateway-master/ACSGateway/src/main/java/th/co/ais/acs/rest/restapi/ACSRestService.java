package th.co.ais.acs.rest.restapi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.dao.AcsService;
import th.co.ais.acs.rest.db.DBFibreOperation;
import th.co.ais.acs.rest.db.DBStreamOperation;

import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.Credentials;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseMessage;



@DeclareRoles({"admin", "user", "guest"})
@Path("/acs/v1")
public class ACSRestService {
	
	DBFibreOperation dbFibreOperation = InitialParameter.getDbFibreOperation();
	AcsService avsServiceDao = InitialParameter.getAvsServiceDao();
	AcsService egServiceDao = InitialParameter.getEgServiceDao();
	
	private static final String OPTION_1 = "1";
	private static final String OPTION_0 = "0";
	
	private static final String EG = "EG";
	private static final String AVS = "AVS";
	private static final String KIDDO = "KIDDO";
			
	@GET
	@Path("/testwithouttoken")
	@PermitAll
//	@RolesAllowed({"admin","user"})
	@Produces({ MediaType.TEXT_HTML, MediaType.TEXT_PLAIN })
	public String allow() {
		
		return "Hello World - @PermitAll";
	}
	
	@GET
	@Path("/testwithtoken")
	//@PermitAll
	@RolesAllowed({"admin","user"})
	@Produces({ MediaType.TEXT_HTML, MediaType.TEXT_PLAIN })
	public String deny() {
		
		return "Hello World - @RolesAllowed {\"admin\",\"user\"}";
	}

	@POST
	@Path("/queryacsendpoint")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response queryacsendpoint( String requestMassage ) {
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_1);
		
		return ResponseBuilder.createResponseGson( Response.Status.OK, new Gson().toJson(responseMessage) );
	}

}