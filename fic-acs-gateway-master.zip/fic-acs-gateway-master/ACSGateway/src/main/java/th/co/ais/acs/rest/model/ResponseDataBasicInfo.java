package th.co.ais.acs.rest.model;

public class ResponseDataBasicInfo {
	
	String  deviceId          = null;
	String  deviceType        = null;
	String  hardwareVersion   = null;
	String  macAddress        = null;
	String  manufacturer      = null;
	String  oui               = null;
	String  productClass      = null;
	String  ipAddress         = null;
	String  registerStatus    = null;
	String  softwareVersion   = null;
	String  onlineStatus      = null;
	String  lastSessionTime   = null;
	
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getHardwareVersion() {
		return hardwareVersion;
	}
	public void setHardwareVersion(String hardwareVersion) {
		this.hardwareVersion = hardwareVersion;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getOui() {
		return oui;
	}
	public void setOui(String oui) {
		this.oui = oui;
	}
	public String getProductClass() {
		return productClass;
	}
	public void setProductClass(String productClass) {
		this.productClass = productClass;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getRegisterStatus() {
		return registerStatus;
	}
	public void setRegisterStatus(String registerStatus) {
		this.registerStatus = registerStatus;
	}
	public String getSoftwareVersion() {
		return softwareVersion;
	}
	public void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}
	public String getOnlineStatus() {
		return onlineStatus;
	}
	public void setOnlineStatus(String onlineStatus) {
		this.onlineStatus = onlineStatus;
	}
	
	@Override
	public String toString() {
		return "ResponseDataBasicInfo [deviceId=" + deviceId + ", deviceType=" + deviceType + ", hardwareVersion="
				+ hardwareVersion + ", macAddress=" + macAddress + ", manufacturer=" + manufacturer + ", oui=" + oui
				+ ", productClass=" + productClass + ", ipAddress=" + ipAddress + ", registerStatus=" + registerStatus
				+ ", softwareVersion=" + softwareVersion + ", onlineStatus=" + onlineStatus + ", lastSessionTime=" + lastSessionTime + "]";
	}
	public String getLastSessionTime() {
		return lastSessionTime;
	}
	public void setLastSessionTime(String lastSessionTime) {
		this.lastSessionTime = lastSessionTime;
	}

	
	
	

	
}
