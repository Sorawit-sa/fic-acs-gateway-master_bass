package th.co.ais.acs.rest.model;

import java.util.ArrayList;

public class UMPConfig {
	private String taskName = null;
	ArrayList<UMPNameValue> parameters = null;
	private boolean isActive = true;
	
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public ArrayList<UMPNameValue> getParameters() {
		return parameters;
	}
	public void setParameters(ArrayList<UMPNameValue> parameters) {
		this.parameters = parameters;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "UMPConfig [taskName=" + taskName + ", parameters=" + parameters + ", isActive=" + isActive + "]";
	}

	
}
