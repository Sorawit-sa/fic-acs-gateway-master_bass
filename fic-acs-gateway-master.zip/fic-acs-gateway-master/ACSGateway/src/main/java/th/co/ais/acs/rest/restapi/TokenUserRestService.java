package th.co.ais.acs.rest.restapi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.db.DBStreamOperation;
import th.co.ais.acs.rest.filter.AuthenticationFilter;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.Credentials;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.ReponseDetail;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UserSecurity;
import th.co.ais.acs.rest.security.TokenSecurity;



@DeclareRoles({"admin", "user", "guest"})
@Path("/acs/v1")
public class TokenUserRestService {
	
	DBStreamOperation dbStreamOperation = InitialParameter.getDbStreamOperation();
	
	@POST
	@Path("/gettoken")
	@PermitAll
	@Produces("application/json")
	@Consumes("application/json")
	public Response authenticate( Credentials credentials ) {
		ResponseMessage responseMessage = new ResponseMessage(null);
		ResponseData responseData = new ResponseData();
		
		try {
			UserSecurity userSecurity = dbStreamOperation.queryUserSecurityByUserName( credentials.getUserId() );
			
			//if( PasswordSecurity.validatePassword( PasswordSecurity.generateHash(credentials.getPassword()), userSecurity.getPassword() ) == false ) {
			if( credentials.getPassword().equals(userSecurity.getPassword()) == false ) {
				responseMessage.setResponseCode(Code.USER_OR_PASSWORD_INVALID);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.USER_OR_PASSWORD_INVALID));
				responseMessage.setDetail(ReponseDetail.fromId(Code.USER_OR_PASSWORD_INVALID));				
				
				return ResponseBuilder.createResponseGson( Response.Status.UNAUTHORIZED, new Gson().toJson(responseMessage));
			}

			// generate a token for the user
			String token = TokenSecurity.generateJwtToken( userSecurity.getUserId() );
			
			// write the token to the database
			userSecurity.setToken(token);
			dbStreamOperation.updateTokenJWT(userSecurity);
			
			Map<String,Object> map = new HashMap<String,Object>();
			map.put( AuthenticationFilter.AUTHORIZATION_PROPERTY, token );
			
			// Create reponse message
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			responseMessage.setDetail(ReponseDetail.fromId(Code.SUCCESS));
			// add reponse data
			responseData.setAccess_token(token);
			responseData.setRole(userSecurity.getRole());
			responseData.setExpires_in(userSecurity.getExpires_in());
			responseMessage.setResponseData(responseData);
			
			// Return the token on the response
			return ResponseBuilder.createResponseGson( Response.Status.OK, new Gson().toJson(responseMessage) );
		} catch( Exception e ) {
			return ResponseBuilder.createResponse( Response.Status.UNAUTHORIZED );
		} finally {
			responseMessage = null;
			responseData = null;
		}
		
	}
	
	

}