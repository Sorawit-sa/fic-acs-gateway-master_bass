
package th.co.ais.acs.rest.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.rpc.Stub;

import org.apache.axis.AxisFault;
import org.codehaus.jettison.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplServiceLocator;
import com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplServiceSoapBindingStub;
import com.google.gson.Gson;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisFactoryResetRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisRebootRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadConifgFileForAisRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.OperateResponce;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry;


import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceLocator;
import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub;

import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortTypeImplServiceLocator;
import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub;
import northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesLocator;
import northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap12BindingStub;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogAVS;

import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.log.LogHW;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.ReponseDetail;
import th.co.ais.acs.rest.model.RequestDataKeyValue;
import th.co.ais.acs.rest.model.RequestItem;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.RequestWiFiInfo;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseDataAdvanceInfo;
import th.co.ais.acs.rest.model.ResponseDataBasicInfo;
import th.co.ais.acs.rest.model.ResponseDataCFGList;
import th.co.ais.acs.rest.model.ResponseDataConfigs;
import th.co.ais.acs.rest.model.ResponseDataHostInfo;
import th.co.ais.acs.rest.model.ResponseDataKeyValue;
import th.co.ais.acs.rest.model.ResponseDataWiFiInfo;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UMPConfig;
import th.co.ais.acs.rest.model.UMPNameValue;
import th.co.ais.acs.rest.model.UMPProvisioning;
import th.co.ais.acs.rest.model.UMPProvisioningProperties;
import th.co.ais.acs.rest.model.UMPResponse;
import th.co.ais.acs.rest.model.UMPResponseConfigs;
import th.co.ais.acs.rest.model.UMPResponseSettingValue;
import th.co.ais.acs.rest.model.UMPTaskTemplate;
import th.co.ais.acs.rest.model.UMPUnbinding;
import th.co.tbb.acshw.model.DiagnoseService.GetParameterResult;
import th.co.tbb.acshw.model.DiagnoseService.Para;
import th.co.tbb.acshw.model.DiagnoseService.ParaWithType;
import th.co.tbb.acshw.model.DiagnoseService.SetParameterResult;
import th.co.tbb.acshw.model.DiagnoseService.UserIndex;
import th.co.tbb.acshw.model.OperationDistributeService.UserDetail;
import th.co.tbb.acshw.service.DiagnoseService.DiagnoseServiceServiceLocator;
import th.co.tbb.acshw.service.DiagnoseService.DiagnoseServiceSoapBindingStub;
import th.co.tbb.acshw.service.OperationDistributeService.OperationDistributeServiceServiceLocator;
import th.co.tbb.acshw.service.OperationDistributeService.OperationDistributeServiceSoapBindingStub;

public class HwOperation {
	private static final Logger logger = LoggerFactory.getLogger(HwOperation.class);
	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	private static final LogHW LOGGER_INFO = new LogHW();
	
	static final String basicInfoOption = "basicinfo";
	static final String advanceInfoOption = "advanceinfo";
	static final String hostInfoOption = "hostinfo";
	static final String onlineStatusOption = "onlinestatus";
	
	private static final String PPPoEUser = "PPPoEUser=";
	private static final String Online = "online";
	private static final String Offline = "offline";
	
	private static final String GetHostInformation = "GetHostInformation";
	private static final String GetWifiInformation = "GetWifiInformation";
	
	private static final String methodGET = "GET";
	private static final String methodPUT = "PUT";
	private static final String methodPATCH = "PATCH";
	private static final String methodDELETE = "DELETE";
	private static final String methodPOST = "POST";
	
	static final String enable = "enable";
	static final String disable = "disable";
	
	static final String newOption = "new";
	static final String updateOption = "update";
	static final String removeOption = "remove";
	static final String removeAllCustomerOption = "removeAll";
	
	static final String singleConfigurationBackup = "singleConfigurationBackup";
	static final String chosenConfigurationRestore = "chosenConfigurationRestore";
	static final String VOIPSIP1C = "VOIPSIP1C";
	static final String VOIPSIP2C = "VOIPSIP2C";
	static final String BridgeWanConnectionC = "BridgeWanConnectionC";
	static final String factoryResetTemplate = "factoryResetTemplate";
	
	

	public ResponseMessage getBasicInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
			ResponseDataBasicInfo responseDataBasicInfo = new ResponseDataBasicInfo();
			long start = System.currentTimeMillis();
			String serialNumber = null;
			
			try {
    			
    			OperationDistributeServiceSoapBindingStub operationDistributeServicePortType
    			= new OperationDistributeServiceSoapBindingStub(new URL("http://10.10.19.134:8688/NorthInterface/services/OperationDistributeService?wsdl"), new OperationDistributeServiceServiceLocator());
    			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) operationDistributeServicePortType;
    			s.setTimeout(2500);
    			
    			UserDetail[] userDetail = operationDistributeServicePortType.queryUserDetail(3, requestMessage.getInternetUsername());
    			
    			if(requestMessage.getFibreId().equals("8889000061")) {
    				serialNumber = "48575443A4109DA3";
    				responseDataBasicInfo.setDeviceId("00259E-48575443A4109DA3");
    			} else {				
					if(userDetail[0].getCpe_id() != null) {
						responseDataBasicInfo.setDeviceId(userDetail[0].getCpe_id());
						serialNumber = userDetail[0].getCpe_id().split("-")[1];
					}
    			}
				
				DiagnoseServiceSoapBindingStub diagnoseServicePortType
    			= new DiagnoseServiceSoapBindingStub(new URL("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService?wsdl"), new DiagnoseServiceServiceLocator());
    			org.apache.axis.client.Stub s2 = (org.apache.axis.client.Stub) diagnoseServicePortType;
    			s2.setTimeout(2500);
    			
    			UserIndex user = new UserIndex(serialNumber, 5);
    			String[] parameterNames = 	{
	    			                           "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.MACAddress",
	    			                           "InternetGatewayDevice.DeviceInfo.HardwareVersion",
	    			                           "InternetGatewayDevice.DeviceInfo.Manufacturer",
	    			                           "InternetGatewayDevice.DeviceInfo.ManufacturerOUI",
	    			                           "InternetGatewayDevice.DeviceInfo.ProductClass",
	    			                           "InternetGatewayDevice.DeviceInfo.SoftwareVersion",
	    			                           "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.ExternalIPAddress"
											};
    			
    			GetParameterResult getParameterResult = diagnoseServicePortType.getCpeParameterByNodeName(user, parameterNames);
    			
    			for (Para i: getParameterResult.getParas()) {
    				if(i.getName().equals("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.MACAddress")) {
    					responseDataBasicInfo.setMacAddress(i.getValue());
    				}
    				if(i.getName().equals("InternetGatewayDevice.DeviceInfo.HardwareVersion")) {
    					responseDataBasicInfo.setHardwareVersion(i.getValue());
    				}
    				if(i.getName().equals("InternetGatewayDevice.DeviceInfo.Manufacturer")) {
    					responseDataBasicInfo.setManufacturer(i.getValue());
    				}
    				if(i.getName().equals("InternetGatewayDevice.DeviceInfo.ManufacturerOUI")) {
    					responseDataBasicInfo.setOui(i.getValue());
    				}
    				if(i.getName().equals("InternetGatewayDevice.DeviceInfo.ProductClass")) {
    					responseDataBasicInfo.setProductClass(i.getValue());
    				}
    				if(i.getName().equals("InternetGatewayDevice.DeviceInfo.SoftwareVersion")) {
    					responseDataBasicInfo.setSoftwareVersion(i.getValue());
    				}
    				if(i.getName().equals("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.ExternalIPAddress")) {
    					responseDataBasicInfo.setIpAddress(i.getValue());
    				}
    			}
    			
				/*
				if(cpeHgBaseInfo.getDeviceType() != null) {
					responseDataBasicInfo.setDeviceType(cpeHgBaseInfo.getDeviceType());
				}
				if(cpeHgBaseInfo.getRegistStatus() != null) {
					responseDataBasicInfo.setRegisterStatus(String.valueOf(cpeHgBaseInfo.getRegistStatus()));
				}
				if(cpeHgBaseInfo.getStatus() != null) {
					responseDataBasicInfo.setOnlineStatus((String.valueOf(cpeHgBaseInfo.getStatus()).toLowerCase().equals("0")?Online:Offline));
				}
				*/
				
				if(!(responseMessage.getResponseData() != null)) {
					ResponseData responseData = new ResponseData();
					responseMessage.setResponseData(responseData);
				}
				responseMessage.getResponseData().setBasicInfo(responseDataBasicInfo);
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
				
			} catch( AxisFault axisFault) {
				responseMessage = axisFault(requestMessage, responseMessage, axisFault);
				responseMessage.setDetail(EgServiceImpl.basicInfoOption + " response=" + axisFault.getFaultString() + ", ");	
				
			} catch(Exception e) {
				// TODO Auto-generated catch block
				StringWriter stack = new StringWriter();
				e.printStackTrace(new PrintWriter(stack));
				LOGGER_DEBUG.log("getBasicInfo("+requestMessage.getFibreId()+"): exc_fail", stack.toString());
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(HwServiceImpl.basicInfoOption + " response=" + e.getMessage() + ", ");	
			} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
	
		LOGGER_INFO.log("method=getBasicInfo| " + requestMessage.toString() + "| " + responseDataBasicInfo.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 			
	}
	
	public ResponseMessage getAdvanceInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ResponseDataAdvanceInfo responseDataAdvanceInfo = new ResponseDataAdvanceInfo();
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, requestMessage.getRefId());	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getCpeCommonInfo(baseRequestEntry);
			
			for (ResponseMapEntry i: responseMapEntry) {
				if(i.getKey().toLowerCase().equals("OUI".toLowerCase())) {
					responseDataAdvanceInfo.setOui(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuProductclass".toLowerCase())) {
					responseDataAdvanceInfo.setProductClass(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("DeviceID".toLowerCase())) {
					responseDataAdvanceInfo.setDeviceId(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SsidStatus".toLowerCase())) {
					responseDataAdvanceInfo.setSsidStatus(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SsidName".toLowerCase())) {
					responseDataAdvanceInfo.setSsidName(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuManufacturer".toLowerCase())) {
					responseDataAdvanceInfo.setManufacturer(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("HardVersion".toLowerCase())) {
					responseDataAdvanceInfo.setHardwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuInternetAddr".toLowerCase())) {
					responseDataAdvanceInfo.setIpAddress(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SoftwareVersion".toLowerCase())) {
					responseDataAdvanceInfo.setSoftwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuConnectionType".toLowerCase())) {
					responseDataAdvanceInfo.setOnuConnectionType(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuSoftwareVersion".toLowerCase())) {
					responseDataAdvanceInfo.setOnuSoftwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass".toLowerCase())) {
					responseDataAdvanceInfo.setOnuVoipIp(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthName".toLowerCase())) {
					responseDataAdvanceInfo.setSipUsername1(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass".toLowerCase())) {
					responseDataAdvanceInfo.setSipPassword1(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthName2".toLowerCase())) {
					responseDataAdvanceInfo.setSipUsername2(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass2".toLowerCase())) {
					responseDataAdvanceInfo.setSipPassword2(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuVoipIp".toLowerCase())) {
					responseDataAdvanceInfo.setOnuVoipIp(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("Online".toLowerCase())) {
					responseDataAdvanceInfo.setOnlineStatus(i.getValue().toLowerCase().equals("true")?Online:Offline);
				}
				if(i.getKey().toLowerCase().equals("LANStatus".toLowerCase())) {
					responseDataAdvanceInfo.setLanStatus(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("CpeStatus".toLowerCase())) {
					responseDataAdvanceInfo.setOui(i.getValue());
				}
				
			}

			responseMessage.getResponseData().setAdvanceInfo(responseDataAdvanceInfo);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + EgServiceImpl.advanceInfoOption + " response=" + axisFault.getFaultString() + ", ");	
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getAdvanceInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + AvsServiceImpl.advanceInfoOption + " response=" + e.getMessage() + ", ");	
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getAdvanceInfo| " + requestMessage.toString() + "| " + responseDataAdvanceInfo.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}
	
	public ResponseMessage getHostInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ArrayList<ResponseDataHostInfo> responseDataHostInfoList = new ArrayList<ResponseDataHostInfo>();
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, requestMessage.getRefId());	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getMultiParameterValuesByItemName(baseRequestEntry, GetHostInformation);
			
			for (ResponseMapEntry i: responseMapEntry) {
				ResponseDataHostInfo responseDataHostInfo = new ResponseDataHostInfo();
				if(i.getKey().toLowerCase().endsWith("_active")) {
					responseDataHostInfo.setPortNumber(i.getKey().split("_")[0]);
					responseDataHostInfoList.add(responseDataHostInfo);
				}				
			}
			
			for (ResponseDataHostInfo i: responseDataHostInfoList) {
				String index = i.getPortNumber();
				for (ResponseMapEntry res: responseMapEntry) {
					if(res.getKey().toLowerCase().equals((index+"_Active").toLowerCase())) {
						i.setActive(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_HostName").toLowerCase())) {
						i.setHostName(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_InterfaceType").toLowerCase())) {
						i.setInterfaceType(res.getValue());
					}
					if(res.getKey().toLowerCase().equals((index+"_Layer2Interface").toLowerCase())) {
						i.setLayer2Interface(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_IPAddress").toLowerCase())) {
						i.setIpAddress(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_MACAddress").toLowerCase())) {
						i.setMacAddress(res.getValue());
					}	
				}				
			}
			

			responseMessage.getResponseData().setHostInfo(responseDataHostInfoList);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + AvsServiceImpl.hostInfoOption + " response=" + axisFault.getFaultString() + ", ");	
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getHostInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + EgServiceImpl.hostInfoOption + " response=" + e.getMessage() + ", ");	
		} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getHostInfo| " + requestMessage.toString() + "| " + Arrays.toString(responseDataHostInfoList.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}
	
	public ResponseMessage getOnlineStatus( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		String onlineStatus = Offline;
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			int response = cpe112DiagnosisWebServicesPortType.getCpeOnlineStatus(requestMessage.getRefId(), bindAccount);
			
			if (response == 0) {
				onlineStatus = Online;			
			} else {
				onlineStatus = Offline;	
			}
			responseMessage.getResponseData().setOnlineStatus(onlineStatus);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + EgServiceImpl.onlineStatusOption + " response=" + axisFault.getFaultString() + ", ");
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getonlineStatus("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + AvsServiceImpl.onlineStatusOption + " response=" + e.getMessage() + ", ");
		} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getonlineStatus| " + requestMessage.toString() + "| " + onlineStatus + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;	
	}
	
	public ResponseMessage getLastSessionTime( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ResponseDataBasicInfo responseDataBasicInfo = new ResponseDataBasicInfo();
		long start = System.currentTimeMillis();
		UMPResponse umpResponse = new UMPResponse();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		boolean check = false;
		String uri = "";
		String newMac = "";
		try {

			if(requestMessage.getMacAddress() != null) {
				String macLower = requestMessage.getMacAddress().toLowerCase().trim();
				newMac = macLower;
				newMac = newMac.replace(":", "");
				newMac = newMac.replace("-", "");
				newMac = newMac.replace(".", "");
		
		
		
				if(newMac.length() == 12) {
				String mac1 = newMac.substring(0, 2);
				String mac2 = newMac.substring(2, 4);
				String mac3 = newMac.substring(4, 6);
				String mac4 = newMac.substring(6, 8);
				String mac5 = newMac.substring(8, 10);
				String mac6 = newMac.substring(10, 12);
				newMac = mac1 + ":" + mac2 + ":" + mac3 + ":" + mac4 + ":" + mac5 + ":" + mac6;
				} else {
				newMac = macLower;
				}
		
				uri = "devices?searchCriteria=properties.sn%20eq%20%27" + newMac.toUpperCase().replace(":", "") + "%27";
			}

			if(requestMessage.getIpAddress() != null) {
				uri = "devices?searchCriteria=ipAddress%20eq%20%27" + requestMessage.getIpAddress() + "%27";
			}

			responseMessage = send("getLastSessionTime (deviceId)", methodGET, uri, true, new Gson().toJson(""), responseMessage);
			
			if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				uri = "devices/" + responseMessage.getDeviceId() + "?exactId=false";
				responseMessage = send("getLastSessionTime (info)", methodGET, uri, true, new Gson().toJson(""), responseMessage);
				if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
					if(responseMessage.getUmpResponse() != null) {
						umpResponse = responseMessage.getUmpResponse();
						
						
						responseDataBasicInfo.setDeviceId(responseMessage.getDeviceId());
						if(umpResponse.getHardwareVersion() != null) {
							responseDataBasicInfo.setHardwareVersion(umpResponse.getHardwareVersion());
						}
						if(umpResponse.getProperties() != null && umpResponse.getProperties().getMac() != null) {
							responseDataBasicInfo.setMacAddress(umpResponse.getProperties().getMac());
						}
						if(umpResponse.getManufacturer() != null) {
							responseDataBasicInfo.setManufacturer(umpResponse.getManufacturer());
						}
						if(umpResponse.getOui() != null) {
							responseDataBasicInfo.setOui(umpResponse.getOui());
						}
						if(umpResponse.getProductClass() != null) {
							responseDataBasicInfo.setProductClass(umpResponse.getProductClass());
						}
						if(umpResponse.getIpAddress() != null) {
							responseDataBasicInfo.setIpAddress(umpResponse.getIpAddress());
						}
						if(umpResponse.getProperties() != null && umpResponse.getProperties().getRegistrationStatus() != null) {
							responseDataBasicInfo.setRegisterStatus(umpResponse.getProperties().getRegistrationStatus());
						}
						if(umpResponse.getSoftwareVersion() != null) {
							responseDataBasicInfo.setSoftwareVersion(umpResponse.getSoftwareVersion());
						}
						if(umpResponse.getProperties() != null && umpResponse.getProperties().getCustomOnline() != null) {
							responseDataBasicInfo.setOnlineStatus(umpResponse.getProperties().getCustomOnline().equals("true")?Online:Offline);
						}
						if(umpResponse.getLastSessionTime() != null ) {
							try {	
								String tempDate = umpResponse.getLastSessionTime().split("\\.")[0].replace("T", " ");
								SimpleDateFormat newDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
								Date newDate = null;
								try {	
								    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								    Date parsedDate = dateFormat.parse(tempDate);
								    
								    long HOUR = 3600*1000;     
								    newDate = new Date(parsedDate.getTime() + 7 * HOUR);
								} catch(Exception e) { //this generic but you can control another types of exception
								    // look the origin of excption
									e.printStackTrace();
									responseDataBasicInfo.setLastSessionTime(null);
								}
								responseDataBasicInfo.setLastSessionTime(newDateFormat.format(newDate));
								Date today = new Date();
								Date beforedate = new Date(today.getTime() - (1000 * 60 * 60 * 24));
								if(newDate.after(beforedate)) {
									check = true;
								}
							} catch(Exception e) {e.printStackTrace();}
						}
						if(check) {
							responseMessage.getResponseData().setBasicInfo(responseDataBasicInfo);
							responseMessage.setResponseCode(Code.SUCCESS);
							responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
						} else {
							responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
							responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
						}
					}
				} else {
					responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
				}
				
			} else {
				responseMessage.setDetail(detail + AvsServiceImpl.lastSessiontimeOption + " ="+ responseMessage.getResponseMessage());
				
			}
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getLastSessionTime("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + AvsServiceImpl.lastSessiontimeOption + " response=" + e.getMessage() + ", ");	
		} finally {
			responseMessage.setUmpResponse(null);
			responseMessage.setDeviceId(null);
		}

	long elapsedTimeMillis = System.currentTimeMillis()-start;
	LOGGER_INFO.log("method=getLastSessionTime| " + requestMessage.toString() + "| " + responseDataBasicInfo.toString() + ", elapsed=" + elapsedTimeMillis);
	
	return responseMessage; 			
	}
	
	public ResponseMessage getWifiInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ArrayList<ResponseDataWiFiInfo> responseDataWiFiInfoList = new ArrayList<ResponseDataWiFiInfo>();
		long start = System.currentTimeMillis();
		String serialNumber = null;
		
		try {
			
			OperationDistributeServiceSoapBindingStub operationDistributeServicePortType
			= new OperationDistributeServiceSoapBindingStub(new URL("http://10.10.19.134:8688/NorthInterface/services/OperationDistributeService?wsdl"), new OperationDistributeServiceServiceLocator());
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) operationDistributeServicePortType;
			s.setTimeout(2500);
			
			UserDetail[] userDetail = operationDistributeServicePortType.queryUserDetail(3, requestMessage.getInternetUsername());
			
			if(requestMessage.getFibreId().equals("8889000061")) {
				serialNumber = "48575443A4109DA3";
			} else {				
				if(userDetail[0].getCpe_id() != null) {
					serialNumber = userDetail[0].getCpe_id().split("-")[1];
				}
			}
			
			DiagnoseServiceSoapBindingStub diagnoseServicePortType
			= new DiagnoseServiceSoapBindingStub(new URL("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService?wsdl"), new DiagnoseServiceServiceLocator());
			org.apache.axis.client.Stub s2 = (org.apache.axis.client.Stub) diagnoseServicePortType;
			s2.setTimeout(10000);
			
			UserIndex user = new UserIndex(serialNumber, 5);
			String[] parameterNames = 	{
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.SSID",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.Channel",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.Enable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.AutoChannelEnable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.2.SSID",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.2.Channel",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.2.Enable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.2.AutoChannelEnable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.3.SSID",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.3.Channel",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.3.Enable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.3.AutoChannelEnable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.4.SSID",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.4.Channel",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.4.Enable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.4.AutoChannelEnable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.5.SSID",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.5.Channel",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.5.Enable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.5.AutoChannelEnable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.6.SSID",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.6.Channel",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.6.Enable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.6.AutoChannelEnable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.7.SSID",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.7.Channel",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.7.Enable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.7.AutoChannelEnable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.8.SSID",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.8.Channel",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.8.Enable",
    			                           "InternetGatewayDevice.LANDevice.1.WLANConfiguration.8.AutoChannelEnable"
										};
			
			GetParameterResult getParameterResult = diagnoseServicePortType.getCpeParameterByNodeName(user, parameterNames);
			
			Map<Integer, ResponseDataWiFiInfo> wifiMap = new HashMap<>();
			
			for (Para i: getParameterResult.getParas()) {
				
				String name = i.getName();
			    String value = i.getValue();

			    String[] parts = name.split("\\.");
		        int index = Integer.parseInt(parts[4]);
		        
		        ResponseDataWiFiInfo data = wifiMap.get(index);
		        if (data == null) {
		            data = new ResponseDataWiFiInfo();
		            data.setIndex(String.valueOf(index));
		            wifiMap.put(index, data);
		        }

		        if (name.endsWith(".SSID")) {
		        	wifiMap.get(index).setSsid(value);
		        } else if (name.endsWith(".Channel")) {
		        	wifiMap.get(index).setChannel(value);
		        } else if (name.endsWith(".Enable")) {
		        	wifiMap.get(index).setEnable(value.equals("1")?"1":"0");
		        } else if (name.endsWith(".AutoChannelEnable")) {
		        	wifiMap.get(index).setAutoChannelEnable(value);
		        }
				
			}
			
			List<Integer> indexList = new ArrayList<>(wifiMap.keySet());
			Collections.sort(indexList);

			for (Integer index : indexList) {
			    ResponseDataWiFiInfo data = wifiMap.get(index);

			    ResponseDataWiFiInfo responseDataWiFiInfo = new ResponseDataWiFiInfo();
			    responseDataWiFiInfo.setIndex(data.getIndex());
			    if (data.getSsid() == null || data.getSsid().equals("-")) {
				    responseDataWiFiInfo.setSsid("-");
				    responseDataWiFiInfo.setChannel("0");
				    responseDataWiFiInfo.setEnable("0");
				    responseDataWiFiInfo.setAutoChannelEnable("0");
			    } else {
			    	responseDataWiFiInfo.setSsid(data.getSsid());
				    responseDataWiFiInfo.setChannel("1".equals(data.getAutoChannelEnable()) ? "0" : data.getChannel());
				    responseDataWiFiInfo.setEnable(data.getEnable());
				    responseDataWiFiInfo.setAutoChannelEnable(data.getAutoChannelEnable());
			    }

			    responseDataWiFiInfoList.add(responseDataWiFiInfo);
			}

			responseMessage.getResponseData().setWiFiInfo(responseDataWiFiInfoList);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));			
  			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getWifiInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("getWifiInfo response=" + e.getMessage() + ", ");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getWifiInfo| " + requestMessage.toString() + "| " + Arrays.toString(responseDataWiFiInfoList.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}

	public ResponseMessage wifiSetup( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		String serialNumber = null;
		
		try {
			
			OperationDistributeServiceSoapBindingStub operationDistributeServicePortType
			= new OperationDistributeServiceSoapBindingStub(new URL("http://10.10.19.134:8688/NorthInterface/services/OperationDistributeService?wsdl"), new OperationDistributeServiceServiceLocator());
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) operationDistributeServicePortType;
			s.setTimeout(2500);
			
			UserDetail[] userDetail = operationDistributeServicePortType.queryUserDetail(3, requestMessage.getInternetUsername());
			
			if(requestMessage.getFibreId().equals("8889000061")) {
				serialNumber = "48575443A4109DA3";
			} else {				
				if(userDetail[0].getCpe_id() != null) {
					serialNumber = userDetail[0].getCpe_id().split("-")[1];
				}
			}
			
			DiagnoseServiceSoapBindingStub diagnoseServicePortType
			= new DiagnoseServiceSoapBindingStub(new URL("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService?wsdl"), new DiagnoseServiceServiceLocator());
			org.apache.axis.client.Stub s2 = (org.apache.axis.client.Stub) diagnoseServicePortType;
			s2.setTimeout(10000);
			
			UserIndex user = new UserIndex(serialNumber, 5);
			
			List<ParaWithType> paraList = new ArrayList<>();

			for (RequestWiFiInfo i : requestMessage.getWifiInfo()) {
				if (i.getSsid() != null && !i.getSsid().equals("-")) {
				    if (i.getSsid() != null) {
				        ParaWithType p = new ParaWithType();
				        p.setName("InternetGatewayDevice.LANDevice.1.WLANConfiguration." + i.getIndex() + ".SSID");
				        p.setValue(i.getSsid());
				        paraList.add(p);
				    }
				    if (i.getEnable() != null) {
				        ParaWithType p = new ParaWithType();
				        p.setName("InternetGatewayDevice.LANDevice.1.WLANConfiguration." + i.getIndex() + ".Enable");
				        p.setValue(i.getEnable());
				        paraList.add(p);
				    }
				    if (i.getAutoChannelEnable() != null) {
				        ParaWithType p = new ParaWithType();
				        p.setName("InternetGatewayDevice.LANDevice.1.WLANConfiguration." + i.getIndex() + ".AutoChannelEnable");
				        p.setValue(i.getAutoChannelEnable());
				        paraList.add(p);
				    }
				    if (i.getChannel() != null) {
				    	if (i.getAutoChannelEnable() == null || (i.getAutoChannelEnable() != null && i.getAutoChannelEnable().equals("0"))) {
					        ParaWithType p = new ParaWithType();
					        p.setName("InternetGatewayDevice.LANDevice.1.WLANConfiguration." + i.getIndex() + ".Channel");
					        p.setValue(i.getChannel());
					        paraList.add(p);
				    	}
				    }
				    if (i.getKey() != null) {
				        ParaWithType p = new ParaWithType();
				        p.setName("InternetGatewayDevice.LANDevice.1.WLANConfiguration." + i.getIndex() + ".PreSharedKey.1.KeyPassphrase");
				        p.setValue(i.getKey());
				        paraList.add(p);
				    }
				}
			}

			ParaWithType[] paraArray = paraList.toArray(new ParaWithType[0]);
			SetParameterResult setParameterResult = diagnoseServicePortType.setCpeParameterValues(user, paraArray);
			int response = -1;
			if(setParameterResult.getErrorCode() == 1) {
				response = 0;
			}
			
			if(response == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.FAILURE);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.FAILURE));
			}
			responseMessage.setDetail("wifiSetup response=" + response);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wifiSetup("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("wifiSetup response=" + e.getMessage() + ", ");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=wifiSetup| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
			
		return responseMessage;
	}
	
	public ResponseMessage getParameterValues( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		ArrayList<ResponseDataKeyValue> getParameterValuesResponse = new ArrayList<ResponseDataKeyValue>();
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			
			List<String> item_ = new ArrayList<>();
			for (RequestItem i: requestMessage.getParamNameVec()) {
				item_.add(i.getItem());
			
			}
			
			String[] item = item_.stream().toArray(String[]::new);
			
			GetParameterValuesRequestEntry baseRequestEntry = new GetParameterValuesRequestEntry(bindAccount, requestMessage.getRefId(), item);
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getParameterValues(baseRequestEntry);
			
			for (ResponseMapEntry res: responseMapEntry) {
				ResponseDataKeyValue responseDataKeyValue = new ResponseDataKeyValue();
				responseDataKeyValue.setKey(res.getKey());	
				if(res.getKey().endsWith("AutoChannelEnable")) {
					if(res.getValue().equals("true")) {
						responseDataKeyValue.setValue("1"); 
					} else if (res.getValue().equals("false")) {
						responseDataKeyValue.setValue("0"); 
					} else {
						responseDataKeyValue.setValue(res.getValue()); 
					}
				} else {
					responseDataKeyValue.setValue(res.getValue()); 
				} 
				getParameterValuesResponse.add(responseDataKeyValue);
			}	
			
			responseMessage.getResponseData().setGetParameterValuesResponse(getParameterValuesResponse);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
  			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getParameterValues("+requestMessage.getFibreId()+"): exc_fail", e);

			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("getWifiInfo response=" + e.getMessage() + ", ");	
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getParameterValues| " + requestMessage.toString() + "| " + Arrays.toString(getParameterValuesResponse.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}

	public ResponseMessage setParameterValues( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}	
		
			List<String> paramNames_ = new ArrayList<>();
			List<String> paramValue_ = new ArrayList<>();
			for (RequestDataKeyValue i: requestMessage.getParameterValues()) {
				paramNames_.add(i.getKey());
				paramValue_.add(i.getValue());
			
			}
			
			String[] paramNames = paramNames_.stream().toArray(String[]::new);
			String[] paramValue = paramValue_.stream().toArray(String[]::new);
			
			SetParameterValuesRequestEntry setParameterValuesRequestEntry = new SetParameterValuesRequestEntry();
			setParameterValuesRequestEntry.setParamNames(paramNames);
			setParameterValuesRequestEntry.setParamValues(paramValue);
			setParameterValuesRequestEntry.setBindAccount(bindAccount);
			int response = cpe112DiagnosisWebServicesPortType.setParameterValues(setParameterValuesRequestEntry);
			
			if(response == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.FAILURE);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}
			responseMessage.setDetail("setParameterValues response=" + response);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("setParameterValues("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("setParameterValues response=" + e.getMessage() + ", ");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=setParameterValues| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
			
		return responseMessage;
	}
	
	public ResponseMessage reboot( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		String deviceId = null;
		
		try {

			OperationDistributeServiceSoapBindingStub operationDistributeServicePortType
			= new OperationDistributeServiceSoapBindingStub(new URL("http://10.10.19.134:8688/NorthInterface/services/OperationDistributeService?wsdl"), new OperationDistributeServiceServiceLocator());
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) operationDistributeServicePortType;
			s.setTimeout(2500);
			
			UserDetail[] userDetail = operationDistributeServicePortType.queryUserDetail(3, requestMessage.getInternetUsername());
			
			if(requestMessage.getFibreId().equals("8889000061")) {
				deviceId = "00259E-48575443A4109DA3";
			} else {				
				if(userDetail[0].getCpe_id() != null) {
					deviceId = userDetail[0].getCpe_id();
				}
			}
			
			DiagnoseServiceSoapBindingStub diagnoseServicePortType
			= new DiagnoseServiceSoapBindingStub(new URL("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService?wsdl"), new DiagnoseServiceServiceLocator());
			org.apache.axis.client.Stub s2 = (org.apache.axis.client.Stub) diagnoseServicePortType;
			s2.setTimeout(10000);
			
			UserIndex user = new UserIndex(deviceId, 3);
			
			int response = diagnoseServicePortType.cpeReboot(user);
			int cpeReboot = -1;
			if(response == 1) {
				cpeReboot = 0;
			}
			
			// Reboot Success
			responseMessage.setDetail(String.valueOf(cpeReboot));
			if(cpeReboot == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			responseMessage.setDetail("reboot response=" + cpeReboot);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("reboot("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=reboot| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);

		return responseMessage;	
	}
	
	public ResponseMessage checkVoIPProfile(RequestMessage requestMessage, ResponseMessage responseMessage) {

		long start = System.currentTimeMillis();

		String uri = "";
		try {

			uri = "settingValues/deviceProfile/" + responseMessage.getDeviceId() + "?withDeviceProperties=false&exactId=false";	
			
			responseMessage = send("checkVoIPProfile (deviceId)", methodGET, uri, true, new Gson().toJson(""), responseMessage);
			
			if(!responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
			}
			
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("checkVoIPProfile("+requestMessage.getFibreId()+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail("checkVoIPProfile response=" + e.getMessage() + ", ");	
			} finally {
				responseMessage.setDeviceId(null);
				responseMessage.setListConfig(null);
				responseMessage.setUmpResponseConfigs(null);
				if(responseMessage.getResponseData() != null) {
					responseMessage.getResponseData().setBasicInfo(null);
				}
			}
	
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=checkVoIPProfile| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 			
	}
	
	public static ResponseMessage send(String name, String method, String uri, boolean enable_ssl, String request, ResponseMessage responseMessage) {
		// Generate UUID for transaction tracking
		long start = System.currentTimeMillis();
		String ssid = UUID.randomUUID().toString();	
		HttpURLConnection conn = null;
		OutputStream os = null;	
		StringBuilder sb = new StringBuilder();
		try {	
				
			if (InitialParameter.MODE == 1) {
		        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
		                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		                    return null;
		                }
		                public void checkClientTrusted(X509Certificate[] certs, String authType) {
		                }
		                public void checkServerTrusted(X509Certificate[] certs, String authType) {
		                }
		            }
		        };
		 
		        SSLContext sc = SSLContext.getInstance("TLSv1.2");
		        sc.init(null, trustAllCerts, new java.security.SecureRandom());
		        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		 
		        HostnameVerifier allHostsValid = new HostnameVerifier() {
		            public boolean verify(String hostname, SSLSession session) {
		                return true;
		            }
		        };
	 
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        
			}
			// Gen Smpp Connection From SMPP Connection Pool				
			URL url = new URL(InitialParameter.url_ump_avs + uri);
			conn = (HttpURLConnection) url.openConnection();
			
			if(method.equals(methodPATCH)) {
				allowMethods("PATCH");
				conn.setRequestMethod(method);	
			} else {
				conn.setRequestMethod(method);
			}
			
			conn.setRequestProperty("Accept-Charset", "UTF-8");
			conn.setRequestProperty("charset", "UTF-8");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setDoOutput(true);
			String userpass = InitialParameter.username_ump_avs + ":" + InitialParameter.password_ump_avs;
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
			conn.setRequestProperty ("Authorization", basicAuth);

			if( method.equals(methodGET)) {
				
			} else {	
				os = conn.getOutputStream();
				if(method.equals(methodDELETE) ) {
					byte[] data = "{}".getBytes("UTF-8");
					os.write(data);
					os.flush();
				} else if(name.equals("executeSession")) {
					byte[] data = "{}".getBytes("UTF-8");
					os.write(data);
					os.flush();
				} else {
					byte[] data = request.getBytes("UTF-8");
					os.write(data);
					os.flush();
				}
			}

			
			BufferedReader br;
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK && conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL)+ ", " + conn.getResponseCode() + ":" + conn.getResponseMessage());			
				
			} else {
				br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}

            
            String line;
            while ((line = br.readLine()) != null) {
            	sb.append(line+"\n");
            }
            br.close();

            if (sb.toString() != null) {
            	responseMessage.setDetail(name+ "=" + sb.toString());
            	Gson gson= new Gson();
            	if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            		if(name.equals("provisioning (get)")) {
		            	UMPProvisioning umpProvisioning = gson.fromJson(sb.toString() , UMPProvisioning.class);
		            	responseMessage.setUmpProvisioning(umpProvisioning);
            		}
            		if(name.equals("getLastSessionTime (deviceId)")) {
            			
            			JSONArray arr = new JSONArray(sb.toString());
            			ArrayList<String> deviceId = new ArrayList<String>();
            			for(int i = 0; i < arr.length(); i++){
            				deviceId.add(arr.getString(i));
            			}
            			if(deviceId.size() == 0)	{
            				responseMessage.setResponseCode(Code._3500008);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3500008));
            				responseMessage.setDetail(ReponseCode.fromId(Code._3500008));
            				
            			} else if(deviceId.size() == 1)	{
            				responseMessage.setDeviceId(deviceId.get(0));
            				
            			} else {
            				responseMessage.setResponseCode(Code.MULTIPLE_DEVICE);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MULTIPLE_DEVICE));
            				responseMessage.setDetail(ReponseCode.fromId(Code.MULTIPLE_DEVICE));
            			}
            			
            		}
            		if(name.equals("getLastSessionTime (info)")) {
            			UMPResponse umpResponse = gson.fromJson(sb.toString() , UMPResponse.class);
		            	responseMessage.setUmpResponse(umpResponse);
		            	responseMessage.setDetail(name+ "=" + "Success");
            		}
            		if(name.equals("listConfig (deviceId)")) {
            			JSONArray arr = new JSONArray(sb.toString());
            			ArrayList<String> listConfig = new ArrayList<String>();
            			for(int i = 0; i < arr.length(); i++){
            				listConfig.add(arr.getString(i));
            			}
            			
            			if(listConfig.size() == 0)	{
            				responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
            				responseMessage.setDetail(ReponseCode.fromId(Code.DATA_NOT_FOUND));
            				
            			} else {
            				responseMessage.setListConfig(listConfig);
            			}
            			
            		}
            		if(name.equals("listConfig (filename)")) {
            			UMPResponseConfigs umpResponseConfigs = gson.fromJson(sb.toString() , UMPResponseConfigs.class);
            			responseMessage.setUmpResponseConfigs(umpResponseConfigs);
            			responseMessage.setDetail(name+ "=" + "Success");
            		}
            		
            		if(name.equals("checkVoIPProfile (deviceId)")) {
            			JSONArray arr = new JSONArray(sb.toString());
            			for(int i = 0; i < arr.length(); i++){
            				UMPResponseSettingValue res = gson.fromJson(arr.getString(i) , UMPResponseSettingValue.class);
            				
            				if(res.getName().equals("supportsVoip")) {
            					if(res.getValue().equals("false")) {
            						responseMessage.getResponseData().setVoipProfile("N");
            					} else {
            						responseMessage.getResponseData().setVoipProfile("Y");
            					}
            					responseMessage.setDetail(null);
                				break;
            				}

            			}
            			
            		}
            		
            	}

            }
            				
			if(os != null) os.close();
			conn.disconnect();
			
		} catch(Exception e) {		
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("send("+name+":"+uri+"): exc_fail", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL)+ " =" +e.getMessage());
			responseMessage.setDetail(name+ "=" + e);
			///return responseMessage;
			
		} finally {
			if(os != null)
				try {
					os.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(conn != null) conn.disconnect();
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		String res = sb.toString().replace("\n", "").replace("\r", "");
		LOGGER_DEBUG.log("method="+name+"(send)| uri=" + uri + "| message=" + request + "| response=" + res + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}
	
	private static void allowMethods(String... methods) {
        try {
            Field methodsField = HttpURLConnection.class.getDeclaredField("methods");

            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(methodsField, methodsField.getModifiers() & ~Modifier.FINAL);

            methodsField.setAccessible(true);

            String[] oldMethods = (String[]) methodsField.get(null);
            Set<String> methodsSet = new LinkedHashSet<>(Arrays.asList(oldMethods));
            methodsSet.addAll(Arrays.asList(methods));
            String[] newMethods = methodsSet.toArray(new String[0]);

            methodsField.set(null/*static field*/, newMethods);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new IllegalStateException(e);
        }
    }
	
	
	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}
	
	private ResponseMessage axisFault(RequestMessage requestMessage, ResponseMessage responseMessage, AxisFault axisFault) {
		try {
			String message = "";
			if( axisFault.getFaultSubCodes() != null && axisFault.getFaultSubCodes()[0] != null) {
				message = message + axisFault.getFaultSubCodes()[0].toString();
			}
			message = message + axisFault.getFaultCode().toString();
			
			if(message.contains("3501700")) {
				responseMessage.setResponseCode(Code._3501700);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3501700));
				responseMessage.setDetail(ReponseCode.fromId(Code._3501700));
			} else if(message.contains("3501703")) {
				responseMessage.setResponseCode(Code._3501703);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3501703));
				responseMessage.setDetail(ReponseCode.fromId(Code._3501703));
			} else if(message.contains("3500008")) {
				responseMessage.setResponseCode(Code._3500008);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3500008));
				responseMessage.setDetail(ReponseCode.fromId(Code._3500008));
			} else if(message.contains("3519000")) {
				responseMessage.setResponseCode(Code._3519000);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519000));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519000));
			} else if(message.contains("3519002")) {
				responseMessage.setResponseCode(Code._3519002);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519002));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519002));
			} else if(message.contains("3519003")) {
				responseMessage.setResponseCode(Code._3519003);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519003));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519003));
			} else if(message.contains("3519005")) {
				responseMessage.setResponseCode(Code._3519005);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519005));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519005));
			} else if(message.contains("3519008")) {
				responseMessage.setResponseCode(Code._3519008);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519008));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519008));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(axisFault.getFaultString());
			} 
			
		} catch(Exception e) {
			e.printStackTrace();
			LOGGER_DEBUG.log("axisFault("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
			return responseMessage;
		}
		
		return responseMessage;
	}

}
