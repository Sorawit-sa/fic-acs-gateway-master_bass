/**
 * DiagnoseServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.service.DiagnoseService;

public interface DiagnoseServiceService extends javax.xml.rpc.Service {
    public java.lang.String getDiagnoseServiceAddress();

    public th.co.tbb.acshw.service.DiagnoseService.DiagnoseService getDiagnoseService() throws javax.xml.rpc.ServiceException;

    public th.co.tbb.acshw.service.DiagnoseService.DiagnoseService getDiagnoseService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
