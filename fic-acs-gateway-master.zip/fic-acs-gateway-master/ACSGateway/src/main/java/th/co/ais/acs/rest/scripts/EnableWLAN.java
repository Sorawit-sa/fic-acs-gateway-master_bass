package th.co.ais.acs.rest.scripts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.rpc.Stub;

import org.apache.axis.AxisFault;

import com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry;

import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceLocator;
import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestDataKeyValue;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseDataWiFiInfo;
import th.co.ais.acs.rest.model.ResponseMessage;

public class EnableWLAN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		setParameterValues("8800919664");
		setParameterValues("8802645457");
		setParameterValues("8802701874");
		setParameterValues("8803528698");
		setParameterValues("8803560701");
		setParameterValues("8803562441");
		setParameterValues("8803614127");
		setParameterValues("8803639678");
		setParameterValues("8803670696");
		setParameterValues("8803692167");
		setParameterValues("8803758849");
		setParameterValues("8803800617");
		setParameterValues("8803800757");
		setParameterValues("8803802078");
	}

	public static void setParameterValues( String str ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL("https://ws.avacs.intra.ais:8051/ACSService/ais/cpeDiagnosis112/?wsdl"), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, "fic");
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, "@Fbb&fcp0");
			s.setTimeout(30000);
			
			// Check ActivationId and FibreId
		
			String bindAccount = "PPPoEUser=" + str;

		
			List<String> paramNames_ = new ArrayList<>();
			List<String> paramValue_ = new ArrayList<>();

				paramNames_.add("InternetGatewayDevice.LANDevice.1.X_HW_WlanEnable");
				paramValue_.add("1");

			
			String[] paramNames = paramNames_.stream().toArray(String[]::new);
			String[] paramValue = paramValue_.stream().toArray(String[]::new);
			
			SetParameterValuesRequestEntry setParameterValuesRequestEntry = new SetParameterValuesRequestEntry();
			setParameterValuesRequestEntry.setParamNames(paramNames);
			setParameterValuesRequestEntry.setParamValues(paramValue);
			setParameterValuesRequestEntry.setBindAccount(bindAccount);
			int response = cpe112DiagnosisWebServicesPortType.setParameterValues(setParameterValuesRequestEntry);
			
			if(response == 0) {
				System.out.println(str + ", " + response);
			} else {
				System.out.println(str + ", " + response);
			}

		} catch( AxisFault axisFault) {
			System.out.println(str + ", " + axisFault.getMessage());
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			System.out.println(str + ", " + e.getMessage());

		} 
		

	}
	
}



