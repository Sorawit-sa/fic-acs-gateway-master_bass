/**
 * CPEMission.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class CPEMission  implements java.io.Serializable {
    private int iMissionID;

    private int iOperResult;

    public CPEMission() {
    }

    public CPEMission(
           int iMissionID,
           int iOperResult) {
           this.iMissionID = iMissionID;
           this.iOperResult = iOperResult;
    }


    /**
     * Gets the iMissionID value for this CPEMission.
     * 
     * @return iMissionID
     */
    public int getIMissionID() {
        return iMissionID;
    }


    /**
     * Sets the iMissionID value for this CPEMission.
     * 
     * @param iMissionID
     */
    public void setIMissionID(int iMissionID) {
        this.iMissionID = iMissionID;
    }


    /**
     * Gets the iOperResult value for this CPEMission.
     * 
     * @return iOperResult
     */
    public int getIOperResult() {
        return iOperResult;
    }


    /**
     * Sets the iOperResult value for this CPEMission.
     * 
     * @param iOperResult
     */
    public void setIOperResult(int iOperResult) {
        this.iOperResult = iOperResult;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CPEMission)) return false;
        CPEMission other = (CPEMission) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.iMissionID == other.getIMissionID() &&
            this.iOperResult == other.getIOperResult();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIMissionID();
        _hashCode += getIOperResult();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CPEMission.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "CPEMission"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IMissionID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "iMissionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IOperResult");
        elemField.setXmlName(new javax.xml.namespace.QName("", "iOperResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
