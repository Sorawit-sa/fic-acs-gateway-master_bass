package th.co.ais.acs.rest.model;

public class Code {
	public static final String SUCCESS = "00000";
	public static final String SUCCESS_WITH_CONDITION = "00010";
	public static final String USER_OR_PASSWORD_INVALID = "00001";
	public static final String MISSING_OR_INVALID_PARAMETER = "00002";
	public static final String NO_TOKEN_PROVIDED = "00003";
	public static final String INVALID_TOKEN_PROVIDED = "00004";
	public static final String TOKEN_MISSMATCH = "00005";
	public static final String TOKEN_EXPIRED = "00006";
	public static final String USER_DOES_NOT_HAVE_PERMISSION_TO_THIS_RESOURCE = "00007";
	public static final String DATA_NOT_FOUND = "01002";
	public static final String SUCCESS_SWAPPED = "03001";
	public static final String SUCCESS_CPE_ALREADY_BOUND = "03200";
	public static final String THE_DEVICE_HAS_NOT_REGISTER = "03201";
	public static final String ACTIVATION_ID_DOES_NOT_EXIST = "03202";
//	public static final String UNKNOW return from ACS = "03299";
//	public static final String MISSING_MADATORY_FIELD = "99001";
	public static final String _3501700 = "99200";
	public static final String MULTIPLE_DEVICE = "99201";
	public static final String _3501703 = "99202";
	public static final String _3500008 = "99203";
	public static final String _3519000 = "99204";
	public static final String _3519002 = "99205";
	public static final String _3519003 = "99206";
	public static final String _3519005 = "99207";
	public static final String _3519008 = "99208";
	
	public static final String FAILURE = "99000";
	public static final String MISSING_MADATORY_FIELD = "99001";
	public static final String OPERATIONS_FAIL = "99999";

}
