/**
 * OperationDistributeServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.service.OperationDistributeService;

public interface OperationDistributeServiceService extends javax.xml.rpc.Service {
    public java.lang.String getOperationDistributeServiceAddress();

    public th.co.tbb.acshw.service.OperationDistributeService.OperationDistributeService getOperationDistributeService() throws javax.xml.rpc.ServiceException;

    public th.co.tbb.acshw.service.OperationDistributeService.OperationDistributeService getOperationDistributeService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
