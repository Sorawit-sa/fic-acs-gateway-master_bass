/**
 * UserDetail.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.OperationDistributeService;

public class UserDetail  implements java.io.Serializable {
    private java.lang.String user_name;

    private java.lang.String user_address;

    private java.lang.String ad_account;

    private java.lang.String cpe_id;

    private java.lang.String cpe_status;

    private java.lang.String online_status;

    private java.lang.String version_status;

    private java.lang.String cpe_version;

    private java.lang.String wifi_status;

    private java.lang.String last_connect;

    private java.lang.String cpe_domain;

    private java.lang.String cpe_service;

    public UserDetail() {
    }

    public UserDetail(
           java.lang.String user_name,
           java.lang.String user_address,
           java.lang.String ad_account,
           java.lang.String cpe_id,
           java.lang.String cpe_status,
           java.lang.String online_status,
           java.lang.String version_status,
           java.lang.String cpe_version,
           java.lang.String wifi_status,
           java.lang.String last_connect,
           java.lang.String cpe_domain,
           java.lang.String cpe_service) {
           this.user_name = user_name;
           this.user_address = user_address;
           this.ad_account = ad_account;
           this.cpe_id = cpe_id;
           this.cpe_status = cpe_status;
           this.online_status = online_status;
           this.version_status = version_status;
           this.cpe_version = cpe_version;
           this.wifi_status = wifi_status;
           this.last_connect = last_connect;
           this.cpe_domain = cpe_domain;
           this.cpe_service = cpe_service;
    }


    /**
     * Gets the user_name value for this UserDetail.
     * 
     * @return user_name
     */
    public java.lang.String getUser_name() {
        return user_name;
    }


    /**
     * Sets the user_name value for this UserDetail.
     * 
     * @param user_name
     */
    public void setUser_name(java.lang.String user_name) {
        this.user_name = user_name;
    }


    /**
     * Gets the user_address value for this UserDetail.
     * 
     * @return user_address
     */
    public java.lang.String getUser_address() {
        return user_address;
    }


    /**
     * Sets the user_address value for this UserDetail.
     * 
     * @param user_address
     */
    public void setUser_address(java.lang.String user_address) {
        this.user_address = user_address;
    }


    /**
     * Gets the ad_account value for this UserDetail.
     * 
     * @return ad_account
     */
    public java.lang.String getAd_account() {
        return ad_account;
    }


    /**
     * Sets the ad_account value for this UserDetail.
     * 
     * @param ad_account
     */
    public void setAd_account(java.lang.String ad_account) {
        this.ad_account = ad_account;
    }


    /**
     * Gets the cpe_id value for this UserDetail.
     * 
     * @return cpe_id
     */
    public java.lang.String getCpe_id() {
        return cpe_id;
    }


    /**
     * Sets the cpe_id value for this UserDetail.
     * 
     * @param cpe_id
     */
    public void setCpe_id(java.lang.String cpe_id) {
        this.cpe_id = cpe_id;
    }


    /**
     * Gets the cpe_status value for this UserDetail.
     * 
     * @return cpe_status
     */
    public java.lang.String getCpe_status() {
        return cpe_status;
    }


    /**
     * Sets the cpe_status value for this UserDetail.
     * 
     * @param cpe_status
     */
    public void setCpe_status(java.lang.String cpe_status) {
        this.cpe_status = cpe_status;
    }


    /**
     * Gets the online_status value for this UserDetail.
     * 
     * @return online_status
     */
    public java.lang.String getOnline_status() {
        return online_status;
    }


    /**
     * Sets the online_status value for this UserDetail.
     * 
     * @param online_status
     */
    public void setOnline_status(java.lang.String online_status) {
        this.online_status = online_status;
    }


    /**
     * Gets the version_status value for this UserDetail.
     * 
     * @return version_status
     */
    public java.lang.String getVersion_status() {
        return version_status;
    }


    /**
     * Sets the version_status value for this UserDetail.
     * 
     * @param version_status
     */
    public void setVersion_status(java.lang.String version_status) {
        this.version_status = version_status;
    }


    /**
     * Gets the cpe_version value for this UserDetail.
     * 
     * @return cpe_version
     */
    public java.lang.String getCpe_version() {
        return cpe_version;
    }


    /**
     * Sets the cpe_version value for this UserDetail.
     * 
     * @param cpe_version
     */
    public void setCpe_version(java.lang.String cpe_version) {
        this.cpe_version = cpe_version;
    }


    /**
     * Gets the wifi_status value for this UserDetail.
     * 
     * @return wifi_status
     */
    public java.lang.String getWifi_status() {
        return wifi_status;
    }


    /**
     * Sets the wifi_status value for this UserDetail.
     * 
     * @param wifi_status
     */
    public void setWifi_status(java.lang.String wifi_status) {
        this.wifi_status = wifi_status;
    }


    /**
     * Gets the last_connect value for this UserDetail.
     * 
     * @return last_connect
     */
    public java.lang.String getLast_connect() {
        return last_connect;
    }


    /**
     * Sets the last_connect value for this UserDetail.
     * 
     * @param last_connect
     */
    public void setLast_connect(java.lang.String last_connect) {
        this.last_connect = last_connect;
    }


    /**
     * Gets the cpe_domain value for this UserDetail.
     * 
     * @return cpe_domain
     */
    public java.lang.String getCpe_domain() {
        return cpe_domain;
    }


    /**
     * Sets the cpe_domain value for this UserDetail.
     * 
     * @param cpe_domain
     */
    public void setCpe_domain(java.lang.String cpe_domain) {
        this.cpe_domain = cpe_domain;
    }


    /**
     * Gets the cpe_service value for this UserDetail.
     * 
     * @return cpe_service
     */
    public java.lang.String getCpe_service() {
        return cpe_service;
    }


    /**
     * Sets the cpe_service value for this UserDetail.
     * 
     * @param cpe_service
     */
    public void setCpe_service(java.lang.String cpe_service) {
        this.cpe_service = cpe_service;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UserDetail)) return false;
        UserDetail other = (UserDetail) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.user_name==null && other.getUser_name()==null) || 
             (this.user_name!=null &&
              this.user_name.equals(other.getUser_name()))) &&
            ((this.user_address==null && other.getUser_address()==null) || 
             (this.user_address!=null &&
              this.user_address.equals(other.getUser_address()))) &&
            ((this.ad_account==null && other.getAd_account()==null) || 
             (this.ad_account!=null &&
              this.ad_account.equals(other.getAd_account()))) &&
            ((this.cpe_id==null && other.getCpe_id()==null) || 
             (this.cpe_id!=null &&
              this.cpe_id.equals(other.getCpe_id()))) &&
            ((this.cpe_status==null && other.getCpe_status()==null) || 
             (this.cpe_status!=null &&
              this.cpe_status.equals(other.getCpe_status()))) &&
            ((this.online_status==null && other.getOnline_status()==null) || 
             (this.online_status!=null &&
              this.online_status.equals(other.getOnline_status()))) &&
            ((this.version_status==null && other.getVersion_status()==null) || 
             (this.version_status!=null &&
              this.version_status.equals(other.getVersion_status()))) &&
            ((this.cpe_version==null && other.getCpe_version()==null) || 
             (this.cpe_version!=null &&
              this.cpe_version.equals(other.getCpe_version()))) &&
            ((this.wifi_status==null && other.getWifi_status()==null) || 
             (this.wifi_status!=null &&
              this.wifi_status.equals(other.getWifi_status()))) &&
            ((this.last_connect==null && other.getLast_connect()==null) || 
             (this.last_connect!=null &&
              this.last_connect.equals(other.getLast_connect()))) &&
            ((this.cpe_domain==null && other.getCpe_domain()==null) || 
             (this.cpe_domain!=null &&
              this.cpe_domain.equals(other.getCpe_domain()))) &&
            ((this.cpe_service==null && other.getCpe_service()==null) || 
             (this.cpe_service!=null &&
              this.cpe_service.equals(other.getCpe_service())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUser_name() != null) {
            _hashCode += getUser_name().hashCode();
        }
        if (getUser_address() != null) {
            _hashCode += getUser_address().hashCode();
        }
        if (getAd_account() != null) {
            _hashCode += getAd_account().hashCode();
        }
        if (getCpe_id() != null) {
            _hashCode += getCpe_id().hashCode();
        }
        if (getCpe_status() != null) {
            _hashCode += getCpe_status().hashCode();
        }
        if (getOnline_status() != null) {
            _hashCode += getOnline_status().hashCode();
        }
        if (getVersion_status() != null) {
            _hashCode += getVersion_status().hashCode();
        }
        if (getCpe_version() != null) {
            _hashCode += getCpe_version().hashCode();
        }
        if (getWifi_status() != null) {
            _hashCode += getWifi_status().hashCode();
        }
        if (getLast_connect() != null) {
            _hashCode += getLast_connect().hashCode();
        }
        if (getCpe_domain() != null) {
            _hashCode += getCpe_domain().hashCode();
        }
        if (getCpe_service() != null) {
            _hashCode += getCpe_service().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UserDetail.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("OperationDistributeService", "UserDetail"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("user_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "user_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("user_address");
        elemField.setXmlName(new javax.xml.namespace.QName("", "user_address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ad_account");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ad_account"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpe_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpe_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpe_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpe_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("online_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "online_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "version_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpe_version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpe_version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wifi_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wifi_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_connect");
        elemField.setXmlName(new javax.xml.namespace.QName("", "last_connect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpe_domain");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpe_domain"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpe_service");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpe_service"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
