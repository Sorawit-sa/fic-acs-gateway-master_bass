package th.co.ais.acs.rest.model;

public class RequestItem {

	private String item = null;

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "RequestItem [item=" + item + "]";
	}



	
	
}
