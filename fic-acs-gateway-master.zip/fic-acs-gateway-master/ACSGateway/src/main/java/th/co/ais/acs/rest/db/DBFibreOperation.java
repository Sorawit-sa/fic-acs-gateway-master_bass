
package th.co.ais.acs.rest.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.google.gson.Gson;

import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogDB;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.ReponseDetail;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UserSecurity;



public class DBFibreOperation {

	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	private static final LogDB LOGGER_INFO = new LogDB();
	
	DataSourceFactoryFibre dbPoolFibre = InitialParameter.getDataSourceFactoryFibre();
	
	private static final String OPTION_1 = "1";
	private static final String OPTION_2 = "2";
	private static final String OPTION_0 = "0";
	
	static final String lastSessiontimeOption = "lastsessiontime";
	
	public ResponseMessage queryACSendpoint( String requsetMessage, String option ) {
			RequestMessage input = new RequestMessage();
			ResponseMessage responseMessage = new ResponseMessage(null);
			ResponseData responseData = new ResponseData();
			long start = System.currentTimeMillis();
			
			String customerId = "";
			String newMac = "";
			
			try {
				Gson gson = new Gson();
				input = gson.fromJson(requsetMessage, RequestMessage.class);
				
				if( option.equals(OPTION_1) ) {
					if (!( checkMandatory(input.getBindAccount())
							&& checkMandatory(input.getRefId()))) {

						responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
						responseMessage.setDetail("{bindAccount, refId}");

						return responseMessage;
					} else {
						customerId = input.getBindAccount();
						
					}
					
				} else if(option.equals(OPTION_2)) {
					if (!( (checkMandatory(input.getFibreId()) || checkMandatory(input.getActivationId()))
							&& checkMandatory(input.getMacAddress()) && checkMandatory(input.getRefId()))) {

						responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
						responseMessage.setDetail("{activationId, macAddress, fibreId, refId}");

						return responseMessage;
					} else {
						customerId = input.getFibreId();
						
					}
				} else {
					if (!( (checkMandatory(input.getFibreId()) || checkMandatory(input.getActivationId()))
							&& checkMandatory(input.getRefId()))) {

						responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
						responseMessage.setDetail("{activationId, fibreId, refId}");

						return responseMessage;
					} else {
						customerId = input.getFibreId();
						
					}
				}

				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("queryACSendpoint("+customerId+"): exception", e);
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(e.getMessage());
			}
			
			Connection conn = null;
			NamedParameterStatement pStmt0 = null;
			ResultSet rs = null;
			int result = 0;
			try {
						
					conn = dbPoolFibre.getConnection();
					String sqlStr0 = "";
					if(option.equals(OPTION_2)) {
						String macLower = input.getMacAddress().toLowerCase().trim();
						newMac = macLower;
						newMac = newMac.replace(":", "");
						newMac = newMac.replace("-", "");
						newMac = newMac.replace(".", "");
		
						if(newMac.length() == 12) {
							 String mac1 = newMac.substring(0, 2);
							 String mac2 = newMac.substring(2, 4);
							 String mac3 = newMac.substring(4, 6);
							 String mac4 = newMac.substring(6, 8);
							 String mac5 = newMac.substring(8, 10);
							 String mac6 = newMac.substring(10, 12);
							 newMac = mac1 + ":" + mac2 + ":" + mac3 + ":" + mac4 + ":" + mac5 + ":" + mac6;
						} else {
							 newMac = macLower;
						}
					
						sqlStr0 = Sql.QUERY_ACS_ENDPOINT_MAC.getMessage();		
						pStmt0 = new NamedParameterStatement(conn, sqlStr0);
						pStmt0.setString("mac_address", newMac);	
					} else if(input.getFibreId() != null) {
						sqlStr0 = Sql.QUERY_ACS_ENDPOINT_FIBREID.getMessage();		
						pStmt0 = new NamedParameterStatement(conn, sqlStr0);
						pStmt0.setString("customerId", customerId);	
					} else if(input.getBindAccount() != null) {
						sqlStr0 = Sql.QUERY_ACS_ENDPOINT_FIBREID.getMessage();		
						pStmt0 = new NamedParameterStatement(conn, sqlStr0);
						pStmt0.setString("customerId", input.getBindAccount());	
					} else {
						sqlStr0 = Sql.QUERY_ACS_ENDPOINT_TOKEN.getMessage();	
						pStmt0 = new NamedParameterStatement(conn, sqlStr0);
						pStmt0.setString("token_id", input.getActivationId());	
					}	
					
					rs = pStmt0.executeQuery();
					
					if(option.equals(OPTION_2)) {
						if (rs.next()) {
							if(rs.getString("ACS_SYSTEM") != null) {
								responseData.setAcsSystem(rs.getString("ACS_SYSTEM"));
							} else {
								responseData.setAcsSystem("EG");
							}

						} else {
							responseData.setAcsSystem("EG");
						}
						
						responseMessage.setResponseCode(Code.SUCCESS);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
						
					} else {
						if (rs.next()) {
							if(rs.getString("ACS_SYSTEM") != null) {
								responseData.setAcsSystem(rs.getString("ACS_SYSTEM"));
							} else {
								responseData.setAcsSystem("EG");
							}
							if(customerId.startsWith("888")) {
								if(rs.getString("USER_ID") != null) {
									responseData.setUsername(rs.getString("USER_ID"));
								}
							}
							responseMessage.setResponseCode(Code.SUCCESS);
							responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
						}
					}
					
					if(!(responseData.getAcsSystem() != null)) {
						responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
						responseMessage.setDetail("ACS_SYSTEM not found");
						
						responseData = null;
					}
					
					responseMessage.setResponseData(responseData);
					
					long elapsedTimeMillis = System.currentTimeMillis()-start;
		  			LOGGER_INFO.log("method=queryACSendpoint| " + input.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		  			
		  			return responseMessage;
		  			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("queryACSendpoint("+customerId+"): sql_exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(e.getMessage());
				return responseMessage;
			
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("getInstallationInfo("+customerId+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(e.getMessage());
				return responseMessage;
				
			} finally {

				try {
					if (conn != null) conn.close();
					if (pStmt0 != null) pStmt0.close();
					if (rs != null) rs.close();
					
					input = null;
					responseMessage = null;
					responseData = null;

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LOGGER_DEBUG.log("queryACSendpoint("+customerId+"): sql_exc_fail", e);
					
					responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
					responseMessage.setDetail(e.getMessage());
					return responseMessage;
				
				} catch(Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LOGGER_DEBUG.log("getInstallationInfo("+customerId+"): exc_fail", e);
					
					responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
					responseMessage.setDetail(e.getMessage());
					return responseMessage;
					
				}
			}

	}
	
	public String queryFibreId( String requsetMessage_ ) {
		long start = System.currentTimeMillis();
		RequestMessage requsetMessage = new Gson().fromJson(requsetMessage_, RequestMessage.class);
		String customerId = "";
		String newMac = "";
		String ip = "";
		String sqlStr0 = "";

			if( requsetMessage.getMacAddress() != null && requsetMessage.getOption().contains(lastSessiontimeOption) ) {
				String macLower = requsetMessage.getMacAddress().toLowerCase().trim();
					newMac = macLower;
					newMac = newMac.replace(":", "");
					newMac = newMac.replace("-", "");
					newMac = newMac.replace(".", "");
	
				if(newMac.length() == 12) {
					 String mac1 = newMac.substring(0, 2);
					 String mac2 = newMac.substring(2, 4);
					 String mac3 = newMac.substring(4, 6);
					 String mac4 = newMac.substring(6, 8);
					 String mac5 = newMac.substring(8, 10);
					 String mac6 = newMac.substring(10, 12);
					 newMac = mac1 + ":" + mac2 + ":" + mac3 + ":" + mac4 + ":" + mac5 + ":" + mac6;
					 sqlStr0 = Sql.QUERY_FIBREID_BY_MAC.getMessage();
				} else {
					 newMac = macLower;
				}
				
			} else if( requsetMessage.getIpAddress() != null && requsetMessage.getOption().contains(lastSessiontimeOption) ) {
				ip = requsetMessage.getIpAddress().toLowerCase().trim();
				sqlStr0 = Sql.QUERY_FIBREID_BY_IP.getMessage();
			} else {
				return requsetMessage_;
			}
			

		Connection conn = null;
		NamedParameterStatement pStmt0 = null;
		ResultSet rs = null;
		int result = 0;
		try {
					
				conn = dbPoolFibre.getConnection();
								
				pStmt0 = new NamedParameterStatement(conn, sqlStr0);
				if( requsetMessage.getMacAddress() != null && requsetMessage.getOption().contains(lastSessiontimeOption) ) {
					pStmt0.setString("calling_station_id", newMac);	
				} else {
					pStmt0.setString("framed_ip_address", ip);	
				}
				
				rs = pStmt0.executeQuery();
				
				if (rs.next()) {
					requsetMessage.setFibreId(rs.getString("CUSTOMER_ID"));

				} 

				long elapsedTimeMillis = System.currentTimeMillis()-start;
	  			LOGGER_INFO.log("method=queryFibreId| " + requsetMessage.toString() + ", elapsed=" + elapsedTimeMillis);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("queryACSendpoint("+customerId+"): sql_exc_fail", e);

		
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getInstallationInfo("+customerId+"): exc_fail", e);

			
		} finally {
			try {
				if (conn != null) conn.close();
				if (pStmt0 != null) pStmt0.close();
				if (rs != null) rs.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return new Gson().toJson(requsetMessage);

	}
	
	public ResponseMessage queryFibreIdx( String requsetMessage_ ) {
		long start = System.currentTimeMillis();
		RequestMessage requsetMessage = new Gson().fromJson(requsetMessage_, RequestMessage.class);
		String customerId = "";
		String newMac = "";
		String ip = "";
		String sqlStr0 = "";
		
		RequestMessage input = new RequestMessage();
		ResponseMessage responseMessage = new ResponseMessage(null);
		ResponseData responseData = new ResponseData();

		Gson gson = new Gson();
		input = new Gson().fromJson(requsetMessage_, RequestMessage.class);

			if( requsetMessage.getMacAddress() != null  ) {
				String macLower = requsetMessage.getMacAddress().toLowerCase().trim();
					newMac = macLower;
					newMac = newMac.replace(":", "");
					newMac = newMac.replace("-", "");
					newMac = newMac.replace(".", "");
	
				if(newMac.length() == 12) {
					 String mac1 = newMac.substring(0, 2);
					 String mac2 = newMac.substring(2, 4);
					 String mac3 = newMac.substring(4, 6);
					 String mac4 = newMac.substring(6, 8);
					 String mac5 = newMac.substring(8, 10);
					 String mac6 = newMac.substring(10, 12);
					 newMac = mac1 + ":" + mac2 + ":" + mac3 + ":" + mac4 + ":" + mac5 + ":" + mac6;
					 sqlStr0 = Sql.QUERY_FIBREID_BY_MAC2.getMessage();
				} else {
					 newMac = macLower;
				}
				
			} else if( requsetMessage.getIpAddress() != null  ) {
				ip = requsetMessage.getIpAddress().toLowerCase().trim();
				sqlStr0 = Sql.QUERY_FIBREID_BY_IP2.getMessage();
			} 
			

		Connection conn = null;
		NamedParameterStatement pStmt0 = null;
		ResultSet rs = null;
		int result = 0;
		try {
					
				conn = dbPoolFibre.getConnection();
								
				pStmt0 = new NamedParameterStatement(conn, sqlStr0);
				if( requsetMessage.getMacAddress() != null && requsetMessage.getOption().contains(lastSessiontimeOption) ) {
					pStmt0.setString("calling_station_id", newMac);	
				} else {
					pStmt0.setString("framed_ip_address", ip);	
				}
				
				rs = pStmt0.executeQuery();

				if (rs.next()) {
					requsetMessage.setFibreId(rs.getString("CUSTOMER_ID"));
					if(rs.getString("ACS_SYSTEM") != null) {
						responseData.setAcsSystem(rs.getString("ACS_SYSTEM"));
					} else {
						responseData.setAcsSystem("EG");
					}
					
					
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					
				} else {
					responseData.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
				}
				
				if(!(responseData.getAcsSystem() != null)) {
					responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
					responseMessage.setDetail("ACS_SYSTEM not found");
					
					responseData = null;
				}
				
				responseMessage.setResponseData(responseData);

				long elapsedTimeMillis = System.currentTimeMillis()-start;
	  			LOGGER_INFO.log("method=queryFibreId| " + requsetMessage.toString() + ", elapsed=" + elapsedTimeMillis);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("queryACSendpoint("+customerId+"): sql_exc_fail", e);

		
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getInstallationInfo("+customerId+"): exc_fail", e);

			
		} finally {
			try {
				if (conn != null) conn.close();
				if (pStmt0 != null) pStmt0.close();
				if (rs != null) rs.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return responseMessage;

	}
	
	public int updateACSsystem(String customerId, String acsSystem) {		
		Connection conn = null;
		NamedParameterStatement pStmt0 = null;
		int result = 0;
		try {
				long start = System.currentTimeMillis();	
				conn = dbPoolFibre.getConnection();

        	  	String sqlStr0 = Sql.UPDATE_ACS_SYSTEM.getMessage();
        	  	
    			pStmt0 = new NamedParameterStatement(conn, sqlStr0);
    	
    			pStmt0.setString("customerId", customerId);
    			pStmt0.setString("acsSystem", acsSystem);
    			
	  			result = pStmt0.executeUpdate();
	  			
	  			long elapsedTimeMillis = System.currentTimeMillis()-start;
	  			LOGGER_INFO.log("method=updateACSsystem, customerId=" + customerId + ", acsSystem=" + acsSystem + ", elapsed=" + elapsedTimeMillis);
	  			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (conn != null) conn.close();
				if (pStmt0 != null) pStmt0.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}	

	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}

}
