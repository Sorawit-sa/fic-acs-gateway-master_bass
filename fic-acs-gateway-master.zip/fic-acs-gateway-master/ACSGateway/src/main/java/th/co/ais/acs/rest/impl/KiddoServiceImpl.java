package th.co.ais.acs.rest.impl;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.dao.AcsService;
import th.co.ais.acs.rest.db.DBStreamOperation;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseMessage;

public class KiddoServiceImpl implements AcsService {
	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	
	AcsService KiddoServiceDao;
	KiddoOperation kiddoOperation = InitialParameter.getKiddoOperation();
	
	static final String basicInfoOption = "basicinfo";
	static final String advanceInfoOption = "advanceinfo";
	static final String hostInfoOption = "hostinfo";
	static final String onlineStatusOption = "onlinestatus";
	static final String lastSessiontimeOption = "lastsessiontime";
	
	static final String backupOption = "backup";
	static final String listBackupOption = "listbackup";
	static final String restoreOption = "restore";
	
	static final String addOption = "add";
	static final String updateOption = "update";
	static final String removeOption = "remove";
	static final String removeAllCustomerOption = "removeAll";
	
	static final String executionEnable = "1";
	
	static final String mainOption = "main";
	static final String EG = "EG";
	static final String AVS = "AVS";
	static final String KIDDO = "KIDDO";

	@Override
	public ResponseMessage getParameterValues(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(KIDDO);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		List<String> optionList = null;
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getParamNameVec()!= null && checkMandatory(requestMessage.getParamNameVec().get(0).getItem()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, paramNameVec [], refId}");
				return responseMessage;
			}
			
			responseMessage = kiddoOperation.getParameterValues(requestMessage, responseMessage);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getparameterValues("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage setParameterValues(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(KIDDO);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getParameterValues() != null && checkMandatory(requestMessage.getParameterValues().get(0).getKey()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, parameterValues [], refId}");
				return responseMessage;
			} 
			
			responseMessage = kiddoOperation.setParameterValues(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("setParameterValues("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
				
		return responseMessage;
	}
	
	@Override
	public ResponseMessage reboot(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(KIDDO);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			}
			
			responseMessage = kiddoOperation.reboot(requestMessage, responseMessage);					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("reboot("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		return responseMessage;
	}
	
	@Override
	public ResponseMessage checkVoIPProfile(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(KIDDO);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			} 
			
			responseMessage = kiddoOperation.getBasicInfo(requestMessage, responseMessage);
			if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				if(responseMessage.getResponseData() != null && responseMessage.getResponseData().getBasicInfo() != null ) {
					responseMessage.setDeviceId(responseMessage.getResponseData().getBasicInfo().getDeviceId());
					
					responseMessage = kiddoOperation.checkVoIPProfile(requestMessage, responseMessage);
					
				} else {
					responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
					responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				}
				
				
			} else {
				responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
			}
			
			
			
			
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("checkVoIPProfile("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
				
		return responseMessage;
	}
	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}

	@Override
	public ResponseMessage provisioning(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public ResponseMessage wifiProvisioning(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseMessage binding(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseMessage unbinding(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseMessage getCpeinfo(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseMessage wanSetup(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseMessage getWifiInfo(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseMessage wifiSetup(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseMessage upgradeFirmware(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public ResponseMessage factoryReset(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseMessage configFile(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		return null;
	}


	
}
