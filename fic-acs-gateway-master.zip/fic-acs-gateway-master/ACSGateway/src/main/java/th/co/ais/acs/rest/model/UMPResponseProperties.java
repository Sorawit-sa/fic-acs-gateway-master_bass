package th.co.ais.acs.rest.model;

public class UMPResponseProperties {
	String activeVoip                              = null;
	String connectionRequestUsername               = null;
	String activeLanEthernet                       = null;
	String vdmWlan7                                = null;
	String vdmWlan1                                = null;
	String testProperty1                           = null;
	String selfManagementRefreshStart              = null;
	String mac                                     = null;
	String selfManagementRefreshEnd                = null;
	String resetConnectionRequestCredentials       = null;
	String activeEthernet                          = null;
	String quickFixTimestamp                       = null;
	String targetConnectionRequestPassword         = null;
	String subrouters                              = null;
	String vdmWlan6                                = null;
	String activeLanUsb                            = null;
	String quickFixActionName                      = null;
	String registrationStatus                      = null;
	String connectionRequestPassword               = null;
	String activeLan                               = null;
	String fibernetID                              = null;
	String activationDate                          = null;
	String vdmWlan2                                = null;
	String targetConnectionRequestUsername         = null;
	String sn                                      = null;
	String editedBy                                = null;
	String CurrentWanUsername                      = null;
	String connectionRequestUrl                    = null;
	String id                                      = null;
	String lastKnownIp                             = null;
	String vdmWlan3                                = null;
	String activeWlan                              = null;
	String activeVoiceProfile                      = null;
	String vdmWlan8                                = null;
	String remappingEnabled                        = null;
	String mainRouter                              = null;
	String vdmWlan5                                = null;
	String additionalProp4                         = null;
	String rebootRequired                          = null;
	String periodicInformInterval                  = null;
	String MeshRelationTarget                      = null;
	String customOnline                            = null;
	String vdmWlan4                                = null;
	String activeWan                               = null;
	String activePpp                               = null;
	String configuredBridge                        = null;
	String configuredInternetUsername              = null;
	String configuredSIPUsername1                  = null;
	String configuredSIPUsername2                  = null;
	public String getActiveVoip() {
		return activeVoip;
	}
	public void setActiveVoip(String activeVoip) {
		this.activeVoip = activeVoip;
	}
	public String getConnectionRequestUsername() {
		return connectionRequestUsername;
	}
	public void setConnectionRequestUsername(String connectionRequestUsername) {
		this.connectionRequestUsername = connectionRequestUsername;
	}
	public String getActiveLanEthernet() {
		return activeLanEthernet;
	}
	public void setActiveLanEthernet(String activeLanEthernet) {
		this.activeLanEthernet = activeLanEthernet;
	}
	public String getVdmWlan7() {
		return vdmWlan7;
	}
	public void setVdmWlan7(String vdmWlan7) {
		this.vdmWlan7 = vdmWlan7;
	}
	public String getVdmWlan1() {
		return vdmWlan1;
	}
	public void setVdmWlan1(String vdmWlan1) {
		this.vdmWlan1 = vdmWlan1;
	}
	public String getTestProperty1() {
		return testProperty1;
	}
	public void setTestProperty1(String testProperty1) {
		this.testProperty1 = testProperty1;
	}
	public String getSelfManagementRefreshStart() {
		return selfManagementRefreshStart;
	}
	public void setSelfManagementRefreshStart(String selfManagementRefreshStart) {
		this.selfManagementRefreshStart = selfManagementRefreshStart;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public String getSelfManagementRefreshEnd() {
		return selfManagementRefreshEnd;
	}
	public void setSelfManagementRefreshEnd(String selfManagementRefreshEnd) {
		this.selfManagementRefreshEnd = selfManagementRefreshEnd;
	}
	public String getResetConnectionRequestCredentials() {
		return resetConnectionRequestCredentials;
	}
	public void setResetConnectionRequestCredentials(String resetConnectionRequestCredentials) {
		this.resetConnectionRequestCredentials = resetConnectionRequestCredentials;
	}
	public String getActiveEthernet() {
		return activeEthernet;
	}
	public void setActiveEthernet(String activeEthernet) {
		this.activeEthernet = activeEthernet;
	}
	public String getQuickFixTimestamp() {
		return quickFixTimestamp;
	}
	public void setQuickFixTimestamp(String quickFixTimestamp) {
		this.quickFixTimestamp = quickFixTimestamp;
	}
	public String getTargetConnectionRequestPassword() {
		return targetConnectionRequestPassword;
	}
	public void setTargetConnectionRequestPassword(String targetConnectionRequestPassword) {
		this.targetConnectionRequestPassword = targetConnectionRequestPassword;
	}
	public String getSubrouters() {
		return subrouters;
	}
	public void setSubrouters(String subrouters) {
		this.subrouters = subrouters;
	}
	public String getVdmWlan6() {
		return vdmWlan6;
	}
	public void setVdmWlan6(String vdmWlan6) {
		this.vdmWlan6 = vdmWlan6;
	}
	public String getActiveLanUsb() {
		return activeLanUsb;
	}
	public void setActiveLanUsb(String activeLanUsb) {
		this.activeLanUsb = activeLanUsb;
	}
	public String getQuickFixActionName() {
		return quickFixActionName;
	}
	public void setQuickFixActionName(String quickFixActionName) {
		this.quickFixActionName = quickFixActionName;
	}
	public String getRegistrationStatus() {
		return registrationStatus;
	}
	public void setRegistrationStatus(String registrationStatus) {
		this.registrationStatus = registrationStatus;
	}
	public String getConnectionRequestPassword() {
		return connectionRequestPassword;
	}
	public void setConnectionRequestPassword(String connectionRequestPassword) {
		this.connectionRequestPassword = connectionRequestPassword;
	}
	public String getActiveLan() {
		return activeLan;
	}
	public void setActiveLan(String activeLan) {
		this.activeLan = activeLan;
	}
	public String getFibernetID() {
		return fibernetID;
	}
	public void setFibernetID(String fibernetID) {
		this.fibernetID = fibernetID;
	}
	public String getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}
	public String getVdmWlan2() {
		return vdmWlan2;
	}
	public void setVdmWlan2(String vdmWlan2) {
		this.vdmWlan2 = vdmWlan2;
	}
	public String getTargetConnectionRequestUsername() {
		return targetConnectionRequestUsername;
	}
	public void setTargetConnectionRequestUsername(String targetConnectionRequestUsername) {
		this.targetConnectionRequestUsername = targetConnectionRequestUsername;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getEditedBy() {
		return editedBy;
	}
	public void setEditedBy(String editedBy) {
		this.editedBy = editedBy;
	}
	public String getCurrentWanUsername() {
		return CurrentWanUsername;
	}
	public void setCurrentWanUsername(String currentWanUsername) {
		CurrentWanUsername = currentWanUsername;
	}
	public String getConnectionRequestUrl() {
		return connectionRequestUrl;
	}
	public void setConnectionRequestUrl(String connectionRequestUrl) {
		this.connectionRequestUrl = connectionRequestUrl;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLastKnownIp() {
		return lastKnownIp;
	}
	public void setLastKnownIp(String lastKnownIp) {
		this.lastKnownIp = lastKnownIp;
	}
	public String getVdmWlan3() {
		return vdmWlan3;
	}
	public void setVdmWlan3(String vdmWlan3) {
		this.vdmWlan3 = vdmWlan3;
	}
	public String getActiveWlan() {
		return activeWlan;
	}
	public void setActiveWlan(String activeWlan) {
		this.activeWlan = activeWlan;
	}
	public String getActiveVoiceProfile() {
		return activeVoiceProfile;
	}
	public void setActiveVoiceProfile(String activeVoiceProfile) {
		this.activeVoiceProfile = activeVoiceProfile;
	}
	public String getVdmWlan8() {
		return vdmWlan8;
	}
	public void setVdmWlan8(String vdmWlan8) {
		this.vdmWlan8 = vdmWlan8;
	}
	public String getRemappingEnabled() {
		return remappingEnabled;
	}
	public void setRemappingEnabled(String remappingEnabled) {
		this.remappingEnabled = remappingEnabled;
	}
	public String getMainRouter() {
		return mainRouter;
	}
	public void setMainRouter(String mainRouter) {
		this.mainRouter = mainRouter;
	}
	public String getVdmWlan5() {
		return vdmWlan5;
	}
	public void setVdmWlan5(String vdmWlan5) {
		this.vdmWlan5 = vdmWlan5;
	}
	public String getAdditionalProp4() {
		return additionalProp4;
	}
	public void setAdditionalProp4(String additionalProp4) {
		this.additionalProp4 = additionalProp4;
	}
	public String getRebootRequired() {
		return rebootRequired;
	}
	public void setRebootRequired(String rebootRequired) {
		this.rebootRequired = rebootRequired;
	}
	public String getPeriodicInformInterval() {
		return periodicInformInterval;
	}
	public void setPeriodicInformInterval(String periodicInformInterval) {
		this.periodicInformInterval = periodicInformInterval;
	}
	public String getMeshRelationTarget() {
		return MeshRelationTarget;
	}
	public void setMeshRelationTarget(String meshRelationTarget) {
		MeshRelationTarget = meshRelationTarget;
	}
	public String getCustomOnline() {
		return customOnline;
	}
	public void setCustomOnline(String customOnline) {
		this.customOnline = customOnline;
	}
	public String getVdmWlan4() {
		return vdmWlan4;
	}
	public void setVdmWlan4(String vdmWlan4) {
		this.vdmWlan4 = vdmWlan4;
	}
	public String getActiveWan() {
		return activeWan;
	}
	public void setActiveWan(String activeWan) {
		this.activeWan = activeWan;
	}
	public String getActivePpp() {
		return activePpp;
	}
	public void setActivePpp(String activePpp) {
		this.activePpp = activePpp;
	}
	public String getConfiguredBridge() {
		return configuredBridge;
	}
	public void setConfiguredBridge(String configuredBridge) {
		this.configuredBridge = configuredBridge;
	}
	public String getConfiguredInternetUsername() {
		return configuredInternetUsername;
	}
	public void setConfiguredInternetUsername(String configuredInternetUsername) {
		this.configuredInternetUsername = configuredInternetUsername;
	}
	public String getConfiguredSIPUsername1() {
		return configuredSIPUsername1;
	}
	public void setConfiguredSIPUsername1(String configuredSIPUsername1) {
		this.configuredSIPUsername1 = configuredSIPUsername1;
	}
	public String getConfiguredSIPUsername2() {
		return configuredSIPUsername2;
	}
	public void setConfiguredSIPUsername2(String configuredSIPUsername2) {
		this.configuredSIPUsername2 = configuredSIPUsername2;
	}
	
	
}
