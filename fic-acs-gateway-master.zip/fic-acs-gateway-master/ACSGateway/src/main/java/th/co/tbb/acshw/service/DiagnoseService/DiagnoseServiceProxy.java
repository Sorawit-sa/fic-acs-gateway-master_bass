package th.co.tbb.acshw.service.DiagnoseService;

import th.co.tbb.acshw.model.DiagnoseService.CPEMission;
import th.co.tbb.acshw.model.DiagnoseService.CPEMissionResult;
import th.co.tbb.acshw.model.DiagnoseService.CpeInfoRst;
import th.co.tbb.acshw.model.DiagnoseService.CpeOnlineInfo;
import th.co.tbb.acshw.model.DiagnoseService.DiagnoseResult;
import th.co.tbb.acshw.model.DiagnoseService.GetCpeOnlineRst;
import th.co.tbb.acshw.model.DiagnoseService.GetParameterResult;
import th.co.tbb.acshw.model.DiagnoseService.Para;
import th.co.tbb.acshw.model.DiagnoseService.ParaWithType;
import th.co.tbb.acshw.model.DiagnoseService.PingInfo;
import th.co.tbb.acshw.model.DiagnoseService.PingResult;
import th.co.tbb.acshw.model.DiagnoseService.SetParameterResult;
import th.co.tbb.acshw.model.DiagnoseService.UserIndex;
import th.co.tbb.acshw.model.DiagnoseService.VoipPwdInfo;

public class DiagnoseServiceProxy implements th.co.tbb.acshw.service.DiagnoseService.DiagnoseService {
  private String _endpoint = null;
  private th.co.tbb.acshw.service.DiagnoseService.DiagnoseService diagnoseService = null;
  
  public DiagnoseServiceProxy() {
    _initDiagnoseServiceProxy();
  }
  
  public DiagnoseServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initDiagnoseServiceProxy();
  }
  
  private void _initDiagnoseServiceProxy() {
    try {
      diagnoseService = (new th.co.tbb.acshw.service.DiagnoseService.DiagnoseServiceServiceLocator()).getDiagnoseService();
      if (diagnoseService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)diagnoseService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)diagnoseService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (diagnoseService != null)
      ((javax.xml.rpc.Stub)diagnoseService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public th.co.tbb.acshw.service.DiagnoseService.DiagnoseService getDiagnoseService() {
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService;
  }
  
  public GetCpeOnlineRst getCpeOnlineInfoForDsl(UserIndex user) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getCpeOnlineInfoForDsl(user);
  }
  
  public CpeInfoRst getCpeInfo(UserIndex user, java.lang.String interfaceType) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getCpeInfo(user, interfaceType);
  }
  
  public int startPing(UserIndex user, PingInfo ping) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.startPing(user, ping);
  }
  
  public int diagnoseTest(UserIndex user, java.lang.String procName, Para[] paraList) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.diagnoseTest(user, procName, paraList);
  }
  
  public int cpeReboot(UserIndex user) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.cpeReboot(user);
  }
  
  public PingResult getPingResult(UserIndex user) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getPingResult(user);
  }
  
  public int resetService(UserIndex user) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.resetService(user);
  }
  
  public GetParameterResult getCpeParameterByNodePath(UserIndex user, java.lang.String nodePath) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getCpeParameterByNodePath(user, nodePath);
  }
  
  public GetParameterResult getCpeParameterByNodeName(UserIndex user, java.lang.String[] parameterNames) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getCpeParameterByNodeName(user, parameterNames);
  }
  
  public CpeOnlineInfo getCpeOnlineInfo(UserIndex user) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getCpeOnlineInfo(user);
  }
  
  public int cpeFactoryReset(UserIndex user, int type) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.cpeFactoryReset(user, type);
  }
  
  public VoipPwdInfo getVoipPwdInfo(java.lang.String strInput, java.lang.String strEncryptInput) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getVoipPwdInfo(strInput, strEncryptInput);
  }
  
  public SetParameterResult setCpeParameterValues(UserIndex user, ParaWithType[] parameterValues) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.setCpeParameterValues(user, parameterValues);
  }
  
  public DiagnoseResult getDiagnoseResult(UserIndex user, java.lang.String procName) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getDiagnoseResult(user, procName);
  }
  
  public CPEMission startCPEMission(UserIndex user, java.lang.String fileName, int iOperType) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.startCPEMission(user, fileName, iOperType);
  }
  
  public CPEMissionResult getCPEMissionResult(int iMissionID, UserIndex user) throws java.rmi.RemoteException{
    if (diagnoseService == null)
      _initDiagnoseServiceProxy();
    return diagnoseService.getCPEMissionResult(iMissionID, user);
  }
  
}