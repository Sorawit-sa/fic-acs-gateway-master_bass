
package th.co.ais.acs.rest.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.rpc.Stub;

import org.apache.axis.AxisFault;
import org.codehaus.jettison.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplServiceLocator;
import com.avsystem.ump.smg.mod.ws.ais.worklist.ws.AISBindServicesPortTypeImplServiceSoapBindingStub;
import com.google.gson.Gson;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisFactoryResetRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisRebootRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadConifgFileForAisRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.OperateResponce;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry;


import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceLocator;
import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub;

import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortTypeImplServiceLocator;
import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogAVS;

import th.co.ais.acs.rest.log.LogDebug;

import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.ReponseDetail;
import th.co.ais.acs.rest.model.RequestDataKeyValue;
import th.co.ais.acs.rest.model.RequestItem;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.RequestWiFiInfo;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseDataAdvanceInfo;
import th.co.ais.acs.rest.model.ResponseDataBasicInfo;
import th.co.ais.acs.rest.model.ResponseDataCFGList;
import th.co.ais.acs.rest.model.ResponseDataConfigs;
import th.co.ais.acs.rest.model.ResponseDataHostInfo;
import th.co.ais.acs.rest.model.ResponseDataKeyValue;
import th.co.ais.acs.rest.model.ResponseDataWiFiInfo;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UMPConfig;
import th.co.ais.acs.rest.model.UMPNameValue;
import th.co.ais.acs.rest.model.UMPProvisioning;
import th.co.ais.acs.rest.model.UMPProvisioningProperties;
import th.co.ais.acs.rest.model.UMPResponse;
import th.co.ais.acs.rest.model.UMPResponseConfigs;
import th.co.ais.acs.rest.model.UMPResponseSettingValue;
import th.co.ais.acs.rest.model.UMPTaskTemplate;
import th.co.ais.acs.rest.model.UMPUnbinding;

public class AvsOperation {
	private static final Logger logger = LoggerFactory.getLogger(AvsOperation.class);
	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	private static final LogAVS LOGGER_INFO = new LogAVS();
	
	static final String basicInfoOption = "basicinfo";
	static final String advanceInfoOption = "advanceinfo";
	static final String hostInfoOption = "hostinfo";
	static final String onlineStatusOption = "onlinestatus";
	
	private static final String PPPoEUser = "PPPoEUser=";
	private static final String Online = "online";
	private static final String Offline = "offline";
	
	private static final String GetHostInformation = "GetHostInformation";
	private static final String GetWifiInformation = "GetWifiInformation";
	
	private static final String methodGET = "GET";
	private static final String methodPUT = "PUT";
	private static final String methodPATCH = "PATCH";
	private static final String methodDELETE = "DELETE";
	private static final String methodPOST = "POST";
	
	static final String enable = "enable";
	static final String disable = "disable";
	
	static final String newOption = "new";
	static final String updateOption = "update";
	static final String removeOption = "remove";
	static final String removeAllCustomerOption = "removeAll";
	
	static final String singleConfigurationBackup = "singleConfigurationBackup";
	static final String chosenConfigurationRestore = "chosenConfigurationRestore";
	static final String VOIPSIP1C = "VOIPSIP1C";
	static final String VOIPSIP2C = "VOIPSIP2C";
	static final String BridgeWanConnectionC = "BridgeWanConnectionC";
	static final String factoryResetTemplate = "factoryResetTemplate";
	
	

	public ResponseMessage provisioning( RequestMessage requestMessage, ResponseMessage responseMessage) {
		long start = System.currentTimeMillis();
		UMPProvisioning umpProvisioning = new UMPProvisioning();
		UMPProvisioningProperties umpProvisioningProperties = new UMPProvisioningProperties();
		List<String> paramNames_ = new ArrayList<>();
		String productOwner = "FBB";
		
		String uri = "propertyServices/actionID/";

		try {
			uri = uri + requestMessage.getActivationId();
			if(requestMessage.getInternetUsername() != null && !requestMessage.getRefId().startsWith("BCS-0")) {
				umpProvisioningProperties.setInternetUsername(requestMessage.getInternetUsername());
				paramNames_.add("internetUsername");
			}
			if(requestMessage.getInternetPassword() != null && !requestMessage.getRefId().startsWith("BCS-0")) {
				umpProvisioningProperties.setInternetPassword(requestMessage.getInternetPassword());
				paramNames_.add("internetPassword");
			}
			if(requestMessage.getSipUsername1() != null) {
				if(requestMessage.getSipUsername1().startsWith("0")) {
					String replacement = "66" + requestMessage.getSipUsername1().substring(1);
					requestMessage.setSipUsername1(replacement);
				}
				if(requestMessage.getSipUsername1().startsWith("66")) {
					umpProvisioningProperties.setSIPUsername1(requestMessage.getSipUsername1());
					umpProvisioningProperties.setSIPURI1(requestMessage.getSipUsername1());
				} else {
					responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
					responseMessage.setDetail("SIPUsername1 is wrong format number");
					return responseMessage;
				}
			}
			if(requestMessage.getSipPassword1() != null) {
				umpProvisioningProperties.setSIPPassword1(requestMessage.getSipPassword1());				
			}
			if(requestMessage.getSipUsername2() != null) {
				if(requestMessage.getSipUsername2().startsWith("0")) {
					String replacement = "66" + requestMessage.getSipUsername2().substring(1);
					requestMessage.setSipUsername2(replacement);
				}
				if(requestMessage.getSipUsername2().startsWith("66")) {
					umpProvisioningProperties.setSIPUsername2(requestMessage.getSipUsername2());
					umpProvisioningProperties.setSIPURI2(requestMessage.getSipUsername2());
				} else {
					responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
					responseMessage.setDetail("SIPUsername2 is wrong format number");
					return responseMessage;
				}
			}
			if(requestMessage.getSipPassword2() != null) {
				umpProvisioningProperties.setSIPPassword2(requestMessage.getSipPassword2());
			}
			if(requestMessage.getBridgeVlan() != null) {
				umpProvisioningProperties.setBridgeVLAN(requestMessage.getBridgeVlan() );
				umpProvisioningProperties.setBridgeWAN(enable);
			}
			if(requestMessage.getFibreId() != null) {
				umpProvisioningProperties.setFibernetID(requestMessage.getFibreId());
				if(requestMessage.getFibreId().startsWith("888")) {
					productOwner = "3BB";
				}
			}
			if(requestMessage.getProductOwner() != null) {
				productOwner = requestMessage.getProductOwner();
			}
			
			if(requestMessage.getOption().equals(newOption)) {
				umpProvisioning.setProperties(umpProvisioningProperties);
				responseMessage = send("provisioning (new)", methodPUT, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
			}
			if(requestMessage.getOption().equals(updateOption)) {
				ResponseMessage reresponseMessage_ = send("provisioning (get)", methodGET, uri + "?returnMatchedDevice=true", true, new Gson().toJson("{}"), responseMessage);
				String sip1 = null;
				String sip2 = null;
				
				// 07/11/2025 06:42 - Add ProductOwner to Support VoIP Fixed Line Provisioning on AVS
				umpProvisioningProperties.setProductOwner(productOwner);
				
				if(reresponseMessage_.getResponseCode().equals(Code.SUCCESS)) {
					
					if(umpProvisioningProperties.getSIPUsername1() != null && !(umpProvisioningProperties.getSIPUsername2() != null)) {
						if((reresponseMessage_.getUmpProvisioning() != null
								&& reresponseMessage_.getUmpProvisioning().getProperties() != null
								&& reresponseMessage_.getUmpProvisioning().getProperties().getSIPUsername1() != null)) {
							sip1 = reresponseMessage_.getUmpProvisioning().getProperties().getSIPUsername1();
						}
						if((reresponseMessage_.getUmpProvisioning() != null
								&& reresponseMessage_.getUmpProvisioning().getProperties() != null
								&& reresponseMessage_.getUmpProvisioning().getProperties().getSIPUsername2() != null)) {
							sip2 = reresponseMessage_.getUmpProvisioning().getProperties().getSIPUsername2();
						}
						
						if(sip1 != null && !sip1.equals(umpProvisioningProperties.getSIPUsername1()) && !(sip2 != null)) {
							umpProvisioningProperties.setSIPUsername2(umpProvisioningProperties.getSIPUsername1());
							umpProvisioningProperties.setSIPPassword2(umpProvisioningProperties.getSIPPassword1());
							umpProvisioningProperties.setSIPURI2(umpProvisioningProperties.getSIPURI1());
							umpProvisioningProperties.setSIPUsername1(null);
							umpProvisioningProperties.setSIPPassword1(null);
							umpProvisioningProperties.setSIPURI1(null);
						}
						if(sip2 != null && sip2.equals(umpProvisioningProperties.getSIPUsername1())) {
							umpProvisioningProperties.setSIPUsername2(umpProvisioningProperties.getSIPUsername1());
							umpProvisioningProperties.setSIPPassword2(umpProvisioningProperties.getSIPPassword1());
							umpProvisioningProperties.setSIPURI2(umpProvisioningProperties.getSIPURI1());
							umpProvisioningProperties.setSIPUsername1(null);
							umpProvisioningProperties.setSIPPassword1(null);
							umpProvisioningProperties.setSIPURI1(null);
						}
					}
					
					umpProvisioning.setAdd(umpProvisioningProperties);
					responseMessage = send("provisioning (update)", methodPATCH, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
					ExecutorService execServiceFCollector = Executors.newSingleThreadExecutor();
					execServiceFCollector.execute( new ExecutionSession(requestMessage, responseMessage));
					
				} else {
					umpProvisioning.setProperties(umpProvisioningProperties);
					responseMessage = send("provisioning (add)", methodPUT, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
				}
			}
			if(requestMessage.getOption().equals(removeOption)) {
				ResponseMessage reresponseMessage_ = send("provisioning (get)", methodGET, uri + "?returnMatchedDevice=true", true, new Gson().toJson("{}"), responseMessage);
				String sip1 = "";
				String sip2 = "";
				
				if(reresponseMessage_.getResponseCode().equals(Code.SUCCESS)) {
					
					if((reresponseMessage_.getUmpProvisioning() != null
							&& reresponseMessage_.getUmpProvisioning().getProperties() != null
							&& reresponseMessage_.getUmpProvisioning().getProperties().getSIPUsername1() != null)) {
						sip1 = reresponseMessage_.getUmpProvisioning().getProperties().getSIPUsername1();
					}
					if((reresponseMessage_.getUmpProvisioning() != null
							&& reresponseMessage_.getUmpProvisioning().getProperties() != null
							&& reresponseMessage_.getUmpProvisioning().getProperties().getSIPUsername2() != null)) {
						sip2 = reresponseMessage_.getUmpProvisioning().getProperties().getSIPUsername2();
					}
					
					if(umpProvisioningProperties.getSIPUsername1() != null) {
						if(umpProvisioningProperties.getSIPUsername1().equals(sip1)) {
							paramNames_.add("SIPUsername1");
							paramNames_.add("SIPURI1");
							paramNames_.add("SIPPassword1");
							tasksFromTemplates(requestMessage, reresponseMessage_, VOIPSIP1C);
						}
						if(umpProvisioningProperties.getSIPUsername1().equals(sip2)) {
							paramNames_.add("SIPUsername2");
							paramNames_.add("SIPURI2");
							paramNames_.add("SIPPassword2");
							tasksFromTemplates(requestMessage, reresponseMessage_, VOIPSIP2C);
						}
					}
					
					if(umpProvisioningProperties.getSIPUsername2() != null) {
						if(umpProvisioningProperties.getSIPUsername2().equals(sip1)) {
							paramNames_.add("SIPUsername1");
							paramNames_.add("SIPURI1");
							paramNames_.add("SIPPassword1");
							tasksFromTemplates(requestMessage, reresponseMessage_, VOIPSIP1C);
						}
						if(umpProvisioningProperties.getSIPUsername2().equals(sip2)) {
							paramNames_.add("SIPUsername2");
							paramNames_.add("SIPURI2");
							paramNames_.add("SIPPassword2");
							tasksFromTemplates(requestMessage, reresponseMessage_, VOIPSIP2C);
						}
					}
					
					umpProvisioning.setRemove(paramNames_.stream().toArray(String[]::new));
					responseMessage = send("provisioning (remove)", methodPATCH, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
					ExecutorService execServiceFCollector = Executors.newSingleThreadExecutor();
					execServiceFCollector.execute( new ExecutionSession(requestMessage, responseMessage));
				} else {
					responseMessage = reresponseMessage_;
				}
			}
			if(requestMessage.getOption().equals(removeAllCustomerOption)) {
				ResponseMessage reresponseMessage_ = send("provisioning (get)", methodGET, uri + "?returnMatchedDevice=true", true, new Gson().toJson("{}"), responseMessage);
				if(reresponseMessage_.getResponseCode().equals(Code.SUCCESS)) {
					paramNames_.add("internetUsername");
					paramNames_.add("internetPassword");
					paramNames_.add("SIPUsername1");
					paramNames_.add("SIPURI1");
					paramNames_.add("SIPPassword1");
					paramNames_.add("SIPUsername2");
					paramNames_.add("SIPURI2");
					paramNames_.add("SIPPassword2");
					paramNames_.add("bridgeVLAN");
					paramNames_.add("bridgeWAN");
					umpProvisioning.setRemove(paramNames_.stream().toArray(String[]::new));
					// 26/05/2025 06:13 - Remove some commands for Change Owner
					if(!requestMessage.getRefId().startsWith("BCS-2")) {
						responseMessage = send("provisioning (remove)", methodPATCH, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
					}
					responseMessage = send("provisioning (removeAll)", methodDELETE, uri, true, new Gson().toJson("{}"), responseMessage);
					
					
					ResponseMessage responseMessageTemp = new ResponseMessage("AVS");
					ResponseData responseDataTemp = new ResponseData();
					responseMessageTemp.setResponseData(responseDataTemp);
					requestMessage.setOption(basicInfoOption);	
					responseMessageTemp = getBasicInfo(requestMessage, responseMessageTemp);
					
					if(responseMessageTemp.getResponseCode() != null && responseMessageTemp.getResponseCode().equals(Code.SUCCESS) && !requestMessage.getRefId().startsWith("BCS-2")) {
						if(responseMessageTemp.getResponseData() != null && responseMessageTemp.getResponseData().getBasicInfo() != null ) {
							String mac = responseMessageTemp.getResponseData().getBasicInfo().getMacAddress();
							uri = "propertyServices/sn/";
							uri = uri + mac;

							List<String> paramNames_temp = new ArrayList<>();
							paramNames_temp.add("actionID");
							paramNames_temp.add("fibernetID");
							
							umpProvisioning.setRemove(paramNames_temp.stream().toArray(String[]::new));
							send("provisioning (remove)", methodPATCH, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
							send("provisioning (removeAll)", methodDELETE, uri, true, new Gson().toJson("{}"), responseMessage);
							tasksFromTemplates(requestMessage, reresponseMessage_, factoryResetTemplate);
						}
	
					}
					
					
					ExecutionSession ex = new ExecutionSession(requestMessage, responseMessage);
					ex.ex();
					if(responseMessageTemp.getResponseData() != null && responseMessageTemp.getResponseData().getBasicInfo() != null && responseMessageTemp.getResponseData().getBasicInfo().getDeviceId() != null && !requestMessage.getRefId().startsWith("BCS-2")) {
						uri = "devices/" + responseMessageTemp.getResponseData().getBasicInfo().getDeviceId() + "?exactId=false";
						send("provisioning (removeAll)", methodDELETE, uri, true, new Gson().toJson("{}"), responseMessage);
					}
				} else {
					responseMessage = reresponseMessage_;
				}
			}
			
			responseMessage.setUmpProvisioning(null);
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("provisioning("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("provisioningNew=" + e);
		} finally {
			responseMessage.setUmpProvisioning(null);
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=provisioning| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;

	}
	
	public ResponseMessage wifiProvisioning( RequestMessage requestMessage, ResponseMessage responseMessage) {
		long start = System.currentTimeMillis();
		UMPProvisioning umpProvisioning = new UMPProvisioning();
		UMPProvisioningProperties umpProvisioningProperties = new UMPProvisioningProperties();
		
		String uri = "propertyServices/actionID/";

		try {
			uri = uri + requestMessage.getActivationId();
			if(requestMessage.getFibreId() != null) {
				umpProvisioningProperties.setFibernetID(requestMessage.getFibreId());
			}
		
			for (RequestWiFiInfo i: requestMessage.getWifiInfo()) {
				if(i.getSsid() != null) {
					if(i.getIndex().equals("1")) {
						umpProvisioningProperties.setSSID_1(i.getSsid());
						umpProvisioningProperties.setKeyPassphrase_1(i.getKey());
					} else if(i.getIndex().equals("2")) {
						umpProvisioningProperties.setSSID_2(i.getSsid());
						umpProvisioningProperties.setKeyPassphrase_2(i.getKey());
					} else if(i.getIndex().equals("3")) {
						umpProvisioningProperties.setSSID_3(i.getSsid());
						umpProvisioningProperties.setKeyPassphrase_3(i.getKey());
					} else if(i.getIndex().equals("4")) {
						umpProvisioningProperties.setSSID_4(i.getSsid());
						umpProvisioningProperties.setKeyPassphrase_4(i.getKey());
					} else if(i.getIndex().equals("5")) {
						umpProvisioningProperties.setSSID_5(i.getSsid());
						umpProvisioningProperties.setKeyPassphrase_5(i.getKey());
					} else if(i.getIndex().equals("6")) {
						umpProvisioningProperties.setSSID_6(i.getSsid());
						umpProvisioningProperties.setKeyPassphrase_6(i.getKey());
					} else if(i.getIndex().equals("7")) {
						umpProvisioningProperties.setSSID_7(i.getSsid());
						umpProvisioningProperties.setKeyPassphrase_7(i.getKey());
					} else if(i.getIndex().equals("8")) {
						umpProvisioningProperties.setSSID_8(i.getSsid());
						umpProvisioningProperties.setKeyPassphrase_8(i.getKey());
					}
				}			
			}

			ResponseMessage reresponseMessage_ = send("wifiprovisioning (get)", methodGET, uri + "?returnMatchedDevice=true", true, new Gson().toJson("{}"), responseMessage);
			
			if(reresponseMessage_.getResponseCode().equals(Code.SUCCESS)) {				
				umpProvisioning.setAdd(umpProvisioningProperties);
				responseMessage = send("wifiprovisioning (update)", methodPATCH, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
				ExecutorService execServiceFCollector = Executors.newSingleThreadExecutor();
				execServiceFCollector.execute( new ExecutionSession(requestMessage, responseMessage));
			} else {
				umpProvisioning.setProperties(umpProvisioningProperties);
				responseMessage = send("wifiprovisioning (add)", methodPUT, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
			}
			
			responseMessage.setUmpProvisioning(null);
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wifiprovisioning("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("wifiprovisioning=" + e);
		} finally {
			responseMessage.setUmpProvisioning(null);
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=wifiprovisioning| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;

	}
	
	public ResponseMessage binding( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		OperateResponce operateResponce = new OperateResponce();
		
		if(requestMessage.getRefId().startsWith("BCS")) {
			// BCS
			UMPProvisioning umpProvisioning = new UMPProvisioning();
			UMPProvisioningProperties umpProvisioningProperties = new UMPProvisioningProperties();
			
			try {
				
				String mac = requestMessage.getMacAddress();
				String uri = "propertyServices/sn/";
				uri = uri + mac;
				
				umpProvisioningProperties.setFibernetID(requestMessage.getFibreId());
				umpProvisioningProperties.setActionID(requestMessage.getActivationId());
				
				umpProvisioning.setProperties(umpProvisioningProperties);
				responseMessage = send("binding", methodPUT, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
				responseMessage.setUmpProvisioning(null);
				
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("binding("+requestMessage.getFibreId()+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail("binding=" + e);
			} finally {
				responseMessage.setUmpProvisioning(null);
			}
			
		} else {
			// WRP
			try {
				
				AISBindServicesPortTypeImplServiceSoapBindingStub aisBindServicesSoap12BindingStub 
				= new AISBindServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_binding_avs), new AISBindServicesPortTypeImplServiceLocator());
				org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) aisBindServicesSoap12BindingStub;
				Stub axisPort = (Stub) aisBindServicesSoap12BindingStub;
				axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
				axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
				s.setTimeout(InitialParameter.connection_timeout);		
				
				// Check ActivationId and FibreId
				operateResponce = aisBindServicesSoap12BindingStub.binding(requestMessage.getActivationId(), requestMessage.getMacAddress().replace(":", "").toUpperCase(), requestMessage.getFibreId());
				
				if(operateResponce.getFaultcode() != null && operateResponce.getFaultcode().equals("0") && operateResponce.getFaultstring().contains("The cpe successfully bound") ) {
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseMessage.setDetail("The cpe successfully bound.");
				} else if (operateResponce.getFaultstring().contains("swapped")) {
					responseMessage.setResponseCode(Code.SUCCESS_SWAPPED);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS_SWAPPED));
					responseMessage.setDetail(ReponseDetail.fromId(Code.SUCCESS_SWAPPED));
				} else if (operateResponce.getFaultstring().contains("has already been")) {
					responseMessage.setResponseCode(Code.SUCCESS_CPE_ALREADY_BOUND);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS_CPE_ALREADY_BOUND));
					responseMessage.setDetail(ReponseDetail.fromId(Code.SUCCESS_CPE_ALREADY_BOUND));
				} else if (operateResponce.getFaultstring().contains("device has not register")) {
					responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
					responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				} else if (operateResponce.getFaultstring().contains("does not exist")) {
					responseMessage.setResponseCode(Code.ACTIVATION_ID_DOES_NOT_EXIST);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.ACTIVATION_ID_DOES_NOT_EXIST));
					responseMessage.setDetail(ReponseCode.fromId(Code.ACTIVATION_ID_DOES_NOT_EXIST));
				} else {
					responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
					responseMessage.setDetail(operateResponce.getFaultstring()!=null?operateResponce.getFaultstring():"");
				}
	
	//  			output:{"rescode":"000","resmsg":"SUCCESS","detail":""}
	//  			output:{"rescode":"001","resmsg":"The cpe successfully swapped with the old.","detail":{"faultcode":"0","faultstring":"The cpe successfully swapped with the old."}}
	//  			output:{"rescode":"100","resmsg":"activationID cannot be input empty","detail":""}
	//  			output:{"rescode":"200","resmsg":"The cpe has already been bound with this activation id.","detail":{"faultcode":"0","faultstring":"The cpe has already been bound with this activation id."}}
	//  			output:{"rescode":"201","resmsg":"The device has not registered to the ACS server.","detail":""}
	//  			output:{"rescode":"202","resmsg":"ActivationID does not exist.","detail":""}
	//  			output:{"rescode":"299","resmsg":"UNKNOW return from ACS","detail":{"faultcode":"-1","faultstring":"UnBind occurs exception."}}
	//  			output:{"rescode":"299","resmsg":"UNKNOW return from ACS","detail":{"faultcode":"4","faultstring":"The cpe is binding. Don't bind it repeated please."}}
			} catch( AxisFault axisFault) {
				responseMessage = axisFault(requestMessage, responseMessage, axisFault);
				
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("binding("+requestMessage.getFibreId()+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail("binding response=" +operateResponce.getFaultstring()!=null?operateResponce.getFaultstring():"");	
			}
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=binding| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;

	}
	
	public ResponseMessage unbinding( RequestMessage requestMessage, ResponseMessage responseMessage) {
		long start = System.currentTimeMillis();
		UMPProvisioning umpProvisioning = new UMPProvisioning();
		UMPProvisioningProperties umpProvisioningProperties = new UMPProvisioningProperties();
		String uri = "";
		UMPUnbinding umpUnbinding = new UMPUnbinding();
		List<String> paramNames_ = new ArrayList<>();
		
		try {
			
			String mac = requestMessage.getMacAddress();
			uri = "propertyServices/sn/" + mac;
			
			umpProvisioningProperties.setFibernetID(requestMessage.getFibreId());
			umpProvisioningProperties.setActionID(requestMessage.getActivationId());
			
			umpProvisioning.setProperties(umpProvisioningProperties);
			responseMessage = send("unbinding", methodDELETE, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
			responseMessage.setUmpProvisioning(null);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("unbinding("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("unbinding=" + e);
		} finally {
			responseMessage.setUmpProvisioning(null);
		}

		// 26/05/2025 06:21 - Fix Error Code 99201 Multiple devices found for given Customer ID
		try {
			
			RequestMessage requestMessageTmp = new RequestMessage();
			requestMessageTmp = requestMessage;
			requestMessageTmp.setOption(basicInfoOption);
			ResponseMessage responseMessageTemp = new ResponseMessage("AVS");
			ResponseData responseDataTemp = new ResponseData();
			responseMessageTemp.setResponseData(responseDataTemp);
			responseMessageTemp = getBasicInfo(requestMessageTmp, responseMessageTemp);
			
			if(responseMessageTemp.getResponseCode() != null && responseMessageTemp.getResponseCode().equals(Code.SUCCESS)) {
				if(responseMessageTemp.getResponseData() != null && responseMessageTemp.getResponseData().getBasicInfo() != null && responseMessageTemp.getResponseData().getBasicInfo().getDeviceId() != null) {
					uri = "devices/" + responseMessageTemp.getResponseData().getBasicInfo().getDeviceId() + "?exactId=false";
					paramNames_.add("actionID");
					paramNames_.add("fibernetID");
					paramNames_.add("internetUsername");
					paramNames_.add("internetPassword");
					paramNames_.add("SSID_1");
					paramNames_.add("SSID_2");
					paramNames_.add("SSID_5");
					paramNames_.add("KeyPassphrase_1");
					paramNames_.add("KeyPassphrase_2");
					paramNames_.add("KeyPassphrase_5");
					paramNames_.add("SIPUsername1");
					paramNames_.add("SIPUsername2");
					paramNames_.add("SIPPassword1");
					paramNames_.add("SIPPassword2");
					paramNames_.add("configuredInternetUsername");
					paramNames_.add("configuredSSID1");
					paramNames_.add("configuredSSID2");
					paramNames_.add("configuredSSID5");
					paramNames_.add("configuredSIPUsername1");
					paramNames_.add("configuredSIPUsername2");
					umpUnbinding.setRemoveProperties(paramNames_.stream().toArray(String[]::new));
					send("unbinding", methodPUT, uri, true, new Gson().toJson(umpUnbinding), responseMessageTemp);
				}
			}
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("unbinding-clearproperties("+requestMessage.getFibreId()+"): exc_fail", e);
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=unbinding| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;

	}
	
	public ResponseMessage getBasicInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
			ResponseDataBasicInfo responseDataBasicInfo = new ResponseDataBasicInfo();
			long start = System.currentTimeMillis();
			
			try {
				
				Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
				= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());
				//= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new File("/opt/wx02-tomcat9.0.7_acsgateway/wsdl/cpediagnosis112_avs.xml").toURI().toURL(), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());			
				org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
				Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
				axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
				axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
				s.setTimeout(InitialParameter.connection_timeout);	
				
				// Check ActivationId and FibreId
				String bindAccount = null;
				if(requestMessage.getActivationId() != null) {
					bindAccount = requestMessage.getActivationId();
				}
				if(requestMessage.getFibreId() != null) {
					bindAccount = PPPoEUser+requestMessage.getFibreId();
				}
				CpeHgBaseInfo cpeHgBaseInfo = cpe112DiagnosisWebServicesPortType.getCpeBasicInfo(requestMessage.getRefId(), bindAccount);
				
				if(cpeHgBaseInfo.getDeviceID() != null) {
					responseDataBasicInfo.setDeviceId(cpeHgBaseInfo.getDeviceID());
				}
				if(cpeHgBaseInfo.getDeviceType() != null) {
					responseDataBasicInfo.setDeviceType(cpeHgBaseInfo.getDeviceType());
				}
				if(cpeHgBaseInfo.getHardVer() != null) {
					responseDataBasicInfo.setHardwareVersion(cpeHgBaseInfo.getHardVer());
				}
				if(cpeHgBaseInfo.getMac() != null) {
					responseDataBasicInfo.setMacAddress(cpeHgBaseInfo.getMac());
				}
				if(cpeHgBaseInfo.getManufacturer() != null) {
					responseDataBasicInfo.setManufacturer(cpeHgBaseInfo.getManufacturer());
				}
				if(cpeHgBaseInfo.getOui() != null) {
					responseDataBasicInfo.setOui(cpeHgBaseInfo.getOui());
				}
				if(cpeHgBaseInfo.getProductClass() != null) {
					responseDataBasicInfo.setProductClass(cpeHgBaseInfo.getProductClass());
				}
				if(cpeHgBaseInfo.getPublicIP() != null) {
					responseDataBasicInfo.setIpAddress(cpeHgBaseInfo.getPublicIP());
				}
				if(cpeHgBaseInfo.getRegistStatus() != null) {
					responseDataBasicInfo.setRegisterStatus(String.valueOf(cpeHgBaseInfo.getRegistStatus()));
				}
				if(cpeHgBaseInfo.getSoftVer() != null) {
					responseDataBasicInfo.setSoftwareVersion(cpeHgBaseInfo.getSoftVer());
				}
				if(cpeHgBaseInfo.getStatus() != null) {
					responseDataBasicInfo.setOnlineStatus((String.valueOf(cpeHgBaseInfo.getStatus()).toLowerCase().equals("0")?Online:Offline));
				}
				
				if(!(responseMessage.getResponseData() != null)) {
					ResponseData responseData = new ResponseData();
					responseMessage.setResponseData(responseData);
				}
				responseMessage.getResponseData().setBasicInfo(responseDataBasicInfo);
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
				
			} catch( AxisFault axisFault) {
				responseMessage = axisFault(requestMessage, responseMessage, axisFault);
				responseMessage.setDetail(EgServiceImpl.basicInfoOption + " response=" + axisFault.getFaultString() + ", ");	
				
			} catch(Exception e) {
				// TODO Auto-generated catch block
				StringWriter stack = new StringWriter();
				e.printStackTrace(new PrintWriter(stack));
				LOGGER_DEBUG.log("getBasicInfo("+requestMessage.getFibreId()+"): exc_fail", stack.toString());
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(AvsServiceImpl.basicInfoOption + " response=" + e.getMessage() + ", ");	
			} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
	
		LOGGER_INFO.log("method=getBasicInfo| " + requestMessage.toString() + "| " + responseDataBasicInfo.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 			
	}
	
	public ResponseMessage getAdvanceInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ResponseDataAdvanceInfo responseDataAdvanceInfo = new ResponseDataAdvanceInfo();
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, requestMessage.getRefId());	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getCpeCommonInfo(baseRequestEntry);
			
			for (ResponseMapEntry i: responseMapEntry) {
				if(i.getKey().toLowerCase().equals("OUI".toLowerCase())) {
					responseDataAdvanceInfo.setOui(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuProductclass".toLowerCase())) {
					responseDataAdvanceInfo.setProductClass(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("DeviceID".toLowerCase())) {
					responseDataAdvanceInfo.setDeviceId(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SsidStatus".toLowerCase())) {
					responseDataAdvanceInfo.setSsidStatus(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SsidName".toLowerCase())) {
					responseDataAdvanceInfo.setSsidName(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuManufacturer".toLowerCase())) {
					responseDataAdvanceInfo.setManufacturer(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("HardVersion".toLowerCase())) {
					responseDataAdvanceInfo.setHardwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuInternetAddr".toLowerCase())) {
					responseDataAdvanceInfo.setIpAddress(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SoftwareVersion".toLowerCase())) {
					responseDataAdvanceInfo.setSoftwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuConnectionType".toLowerCase())) {
					responseDataAdvanceInfo.setOnuConnectionType(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuSoftwareVersion".toLowerCase())) {
					responseDataAdvanceInfo.setOnuSoftwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass".toLowerCase())) {
					responseDataAdvanceInfo.setOnuVoipIp(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthName".toLowerCase())) {
					responseDataAdvanceInfo.setSipUsername1(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass".toLowerCase())) {
					responseDataAdvanceInfo.setSipPassword1(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthName2".toLowerCase())) {
					responseDataAdvanceInfo.setSipUsername2(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass2".toLowerCase())) {
					responseDataAdvanceInfo.setSipPassword2(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuVoipIp".toLowerCase())) {
					responseDataAdvanceInfo.setOnuVoipIp(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("Online".toLowerCase())) {
					responseDataAdvanceInfo.setOnlineStatus(i.getValue().toLowerCase().equals("true")?Online:Offline);
				}
				if(i.getKey().toLowerCase().equals("LANStatus".toLowerCase())) {
					responseDataAdvanceInfo.setLanStatus(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("CpeStatus".toLowerCase())) {
					responseDataAdvanceInfo.setOui(i.getValue());
				}
				
			}

			responseMessage.getResponseData().setAdvanceInfo(responseDataAdvanceInfo);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + EgServiceImpl.advanceInfoOption + " response=" + axisFault.getFaultString() + ", ");	
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getAdvanceInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + AvsServiceImpl.advanceInfoOption + " response=" + e.getMessage() + ", ");	
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getAdvanceInfo| " + requestMessage.toString() + "| " + responseDataAdvanceInfo.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}
	
	public ResponseMessage getHostInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ArrayList<ResponseDataHostInfo> responseDataHostInfoList = new ArrayList<ResponseDataHostInfo>();
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, requestMessage.getRefId());	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getMultiParameterValuesByItemName(baseRequestEntry, GetHostInformation);
			
			for (ResponseMapEntry i: responseMapEntry) {
				ResponseDataHostInfo responseDataHostInfo = new ResponseDataHostInfo();
				if(i.getKey().toLowerCase().endsWith("_active")) {
					responseDataHostInfo.setPortNumber(i.getKey().split("_")[0]);
					responseDataHostInfoList.add(responseDataHostInfo);
				}				
			}
			
			for (ResponseDataHostInfo i: responseDataHostInfoList) {
				String index = i.getPortNumber();
				for (ResponseMapEntry res: responseMapEntry) {
					if(res.getKey().toLowerCase().equals((index+"_Active").toLowerCase())) {
						i.setActive(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_HostName").toLowerCase())) {
						i.setHostName(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_InterfaceType").toLowerCase())) {
						i.setInterfaceType(res.getValue());
					}
					if(res.getKey().toLowerCase().equals((index+"_Layer2Interface").toLowerCase())) {
						i.setLayer2Interface(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_IPAddress").toLowerCase())) {
						i.setIpAddress(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_MACAddress").toLowerCase())) {
						i.setMacAddress(res.getValue());
					}	
				}				
			}
			

			responseMessage.getResponseData().setHostInfo(responseDataHostInfoList);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + AvsServiceImpl.hostInfoOption + " response=" + axisFault.getFaultString() + ", ");	
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getHostInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + EgServiceImpl.hostInfoOption + " response=" + e.getMessage() + ", ");	
		} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getHostInfo| " + requestMessage.toString() + "| " + Arrays.toString(responseDataHostInfoList.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}
	
	public ResponseMessage getOnlineStatus( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		String onlineStatus = Offline;
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			int response = cpe112DiagnosisWebServicesPortType.getCpeOnlineStatus(requestMessage.getRefId(), bindAccount);
			
			if (response == 0) {
				onlineStatus = Online;			
			} else {
				onlineStatus = Offline;	
			}
			responseMessage.getResponseData().setOnlineStatus(onlineStatus);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + EgServiceImpl.onlineStatusOption + " response=" + axisFault.getFaultString() + ", ");
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getonlineStatus("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + AvsServiceImpl.onlineStatusOption + " response=" + e.getMessage() + ", ");
		} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getonlineStatus| " + requestMessage.toString() + "| " + onlineStatus + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;	
	}
	
	public ResponseMessage getLastSessionTime( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ResponseDataBasicInfo responseDataBasicInfo = new ResponseDataBasicInfo();
		long start = System.currentTimeMillis();
		UMPResponse umpResponse = new UMPResponse();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		boolean check = false;
		String uri = "";
		String newMac = "";
		try {

			if(requestMessage.getMacAddress() != null) {
				String macLower = requestMessage.getMacAddress().toLowerCase().trim();
				newMac = macLower;
				newMac = newMac.replace(":", "");
				newMac = newMac.replace("-", "");
				newMac = newMac.replace(".", "");
		
		
		
				if(newMac.length() == 12) {
				String mac1 = newMac.substring(0, 2);
				String mac2 = newMac.substring(2, 4);
				String mac3 = newMac.substring(4, 6);
				String mac4 = newMac.substring(6, 8);
				String mac5 = newMac.substring(8, 10);
				String mac6 = newMac.substring(10, 12);
				newMac = mac1 + ":" + mac2 + ":" + mac3 + ":" + mac4 + ":" + mac5 + ":" + mac6;
				} else {
				newMac = macLower;
				}
		
				uri = "devices?searchCriteria=properties.sn%20eq%20%27" + newMac.toUpperCase().replace(":", "") + "%27";
			}

			if(requestMessage.getIpAddress() != null) {
				uri = "devices?searchCriteria=ipAddress%20eq%20%27" + requestMessage.getIpAddress() + "%27";
			}

			responseMessage = send("getLastSessionTime (deviceId)", methodGET, uri, true, new Gson().toJson(""), responseMessage);
			
			if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				uri = "devices/" + responseMessage.getDeviceId() + "?exactId=false";
				responseMessage = send("getLastSessionTime (info)", methodGET, uri, true, new Gson().toJson(""), responseMessage);
				if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
					if(responseMessage.getUmpResponse() != null) {
						umpResponse = responseMessage.getUmpResponse();
						
						
						responseDataBasicInfo.setDeviceId(responseMessage.getDeviceId());
						if(umpResponse.getHardwareVersion() != null) {
							responseDataBasicInfo.setHardwareVersion(umpResponse.getHardwareVersion());
						}
						if(umpResponse.getProperties() != null && umpResponse.getProperties().getMac() != null) {
							responseDataBasicInfo.setMacAddress(umpResponse.getProperties().getMac());
						}
						if(umpResponse.getManufacturer() != null) {
							responseDataBasicInfo.setManufacturer(umpResponse.getManufacturer());
						}
						if(umpResponse.getOui() != null) {
							responseDataBasicInfo.setOui(umpResponse.getOui());
						}
						if(umpResponse.getProductClass() != null) {
							responseDataBasicInfo.setProductClass(umpResponse.getProductClass());
						}
						if(umpResponse.getIpAddress() != null) {
							responseDataBasicInfo.setIpAddress(umpResponse.getIpAddress());
						}
						if(umpResponse.getProperties() != null && umpResponse.getProperties().getRegistrationStatus() != null) {
							responseDataBasicInfo.setRegisterStatus(umpResponse.getProperties().getRegistrationStatus());
						}
						if(umpResponse.getSoftwareVersion() != null) {
							responseDataBasicInfo.setSoftwareVersion(umpResponse.getSoftwareVersion());
						}
						if(umpResponse.getProperties() != null && umpResponse.getProperties().getCustomOnline() != null) {
							responseDataBasicInfo.setOnlineStatus(umpResponse.getProperties().getCustomOnline().equals("true")?Online:Offline);
						}
						if(umpResponse.getLastSessionTime() != null ) {
							try {	
								String tempDate = umpResponse.getLastSessionTime().split("\\.")[0].replace("T", " ");
								SimpleDateFormat newDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
								Date newDate = null;
								try {	
								    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								    Date parsedDate = dateFormat.parse(tempDate);
								    
								    long HOUR = 3600*1000;     
								    newDate = new Date(parsedDate.getTime() + 7 * HOUR);
								} catch(Exception e) { //this generic but you can control another types of exception
								    // look the origin of excption
									e.printStackTrace();
									responseDataBasicInfo.setLastSessionTime(null);
								}
								responseDataBasicInfo.setLastSessionTime(newDateFormat.format(newDate));
								Date today = new Date();
								Date beforedate = new Date(today.getTime() - (1000 * 60 * 60 * 24));
								if(newDate.after(beforedate)) {
									check = true;
								}
							} catch(Exception e) {e.printStackTrace();}
						}
						if(check) {
							responseMessage.getResponseData().setBasicInfo(responseDataBasicInfo);
							responseMessage.setResponseCode(Code.SUCCESS);
							responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
						} else {
							responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
							responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
						}
					}
				} else {
					responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
				}
				
			} else {
				responseMessage.setDetail(detail + AvsServiceImpl.lastSessiontimeOption + " ="+ responseMessage.getResponseMessage());
				
			}
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getLastSessionTime("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + AvsServiceImpl.lastSessiontimeOption + " response=" + e.getMessage() + ", ");	
		} finally {
			responseMessage.setUmpResponse(null);
			responseMessage.setDeviceId(null);
		}

	long elapsedTimeMillis = System.currentTimeMillis()-start;
	LOGGER_INFO.log("method=getLastSessionTime| " + requestMessage.toString() + "| " + responseDataBasicInfo.toString() + ", elapsed=" + elapsedTimeMillis);
	
	return responseMessage; 			
	}
	
	public ResponseMessage wanSetup( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, requestMessage.getRefId());	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.testWanSetup(baseRequestEntry,
					requestMessage.getInternetUsername(), 
					requestMessage.getInternetPassword(), 
					requestMessage.getPrimaryDns()!=null?requestMessage.getPrimaryDns():null, 
					requestMessage.getSecondDns()!=null?requestMessage.getSecondDns():null);			
			for (ResponseMapEntry res: responseMapEntry) {
				if(res.getKey().toLowerCase().equals("result")) {
					if(res.getValue().toLowerCase().equals("success")) {
						responseMessage.setResponseCode(Code.SUCCESS);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					} else {
						responseMessage.setResponseCode(Code.FAILURE);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.FAILURE));
					}
				}
				if(res.getKey().toLowerCase().equals("error message")) {
					responseMessage.setDetail(res.getValue());
				}
			}


		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wanSetup("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("wanSetup response=" + e.getMessage() + ", ");	
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=wanSetup| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}

	public ResponseMessage getWifiInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ArrayList<ResponseDataWiFiInfo> responseDataWiFiInfoList = new ArrayList<ResponseDataWiFiInfo>();
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, requestMessage.getRefId());	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getParameterValuesByItemName(baseRequestEntry, GetWifiInformation);
			
			for (ResponseMapEntry i: responseMapEntry) {
				ResponseDataWiFiInfo responseDataWiFiInfo = new ResponseDataWiFiInfo();
				if(i.getKey().toLowerCase().endsWith("_channel")) {
					responseDataWiFiInfo.setIndex(i.getKey().split("_")[0]);
					responseDataWiFiInfoList.add(responseDataWiFiInfo);
				}				
			}
			
			String autoChannelEnable1 = "0";
			String autoChannelEnable5 = "0";
			for(int i=0; i<=1; i++) {
				String index = "1";
				if(i==1) {
					index = "5";
				}
				
				List<String> item_ = new ArrayList<>();
				item_.add("InternetGatewayDevice.LANDevice.1.WLANConfiguration." + index + ".AutoChannelEnable");
				String[] item = item_.stream().toArray(String[]::new);
				
				GetParameterValuesRequestEntry baseRequestEntry2 = new GetParameterValuesRequestEntry(bindAccount, requestMessage.getRefId(), item);
				ResponseMapEntry [] responseMapEntry2 = cpe112DiagnosisWebServicesPortType.getParameterValues(baseRequestEntry2);
				
				for (ResponseMapEntry res2: responseMapEntry2) {
					if(res2.getKey().equals("AutoChannelEnable")) {
						if(res2.getValue().equals("true")) {
							if(index.equals("1")) {
								autoChannelEnable1 = "1";
							} else if(index.equals("5")) {
								autoChannelEnable5 = "1";
							}
						}
					}
				}
			}
			
			for (ResponseDataWiFiInfo i: responseDataWiFiInfoList) {
				String index = i.getIndex();
				for (ResponseMapEntry res: responseMapEntry) {
					if(res.getKey().toLowerCase().equals((index+"_CHANNEL").toLowerCase())) {						
						if(Integer.parseInt(index) >= 1 && Integer.parseInt(index) <= 4) {
							i.setAutoChannelEnable(autoChannelEnable1);
						} else {
							i.setAutoChannelEnable(autoChannelEnable5);
						}
						i.setChannel("1".equals(i.getAutoChannelEnable()) ? "0" : res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_ENABLE").toLowerCase())) {
						if(res.getValue().equals("true")) {
							i.setEnable("1");
						} else if (res.getValue().equals("false")) {
							i.setEnable("0");
						} else {
							i.setEnable(res.getValue());
						}
					}	
					if(res.getKey().toLowerCase().equals((index+"_SSID").toLowerCase())) {
						i.setSsid(res.getValue());
					}					
				}				
			}
			

			responseMessage.getResponseData().setWiFiInfo(responseDataWiFiInfoList);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));			
  			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getWifiInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("getWifiInfo response=" + e.getMessage() + ", ");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getWifiInfo| " + requestMessage.toString() + "| " + Arrays.toString(responseDataWiFiInfoList.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}

	public ResponseMessage wifiSetup( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}	
		
			List<String> paramNames_ = new ArrayList<>();
			List<String> paramValue_ = new ArrayList<>();
			for (RequestWiFiInfo i: requestMessage.getWifiInfo()) {
				if(i.getSsid() != null) {
					paramNames_.add(i.getIndex() + "_SSID");
					paramValue_.add(i.getSsid());
				}
				if(i.getEnable() != null) {
					paramNames_.add(i.getIndex() + "_ENABLE");
					paramValue_.add(i.getEnable());
				}
				if(i.getAutoChannelEnable() != null) {
					paramNames_.add(i.getIndex() + "_AutoChannelEnable");
					paramValue_.add(i.getAutoChannelEnable());
				}
				if(i.getChannel() != null) {
					if (i.getAutoChannelEnable() == null || (i.getAutoChannelEnable() != null && i.getAutoChannelEnable().equals("0"))) {
						paramNames_.add(i.getIndex() + "_CHANNEL");
						paramValue_.add(i.getChannel());
					}
				}
				if(i.getKey() != null) {
					paramNames_.add(i.getIndex() + "_KEY");
					paramValue_.add(i.getKey());
				}
			
			}
			
			String[] paramNames = paramNames_.stream().toArray(String[]::new);
			String[] paramValue = paramValue_.stream().toArray(String[]::new);
			
			SetParameterValuesRequestEntry setParameterValuesRequestEntry = new SetParameterValuesRequestEntry();
			setParameterValuesRequestEntry.setParamNames(paramNames);
			setParameterValuesRequestEntry.setParamValues(paramValue);
			setParameterValuesRequestEntry.setBindAccount(bindAccount);
			int response = cpe112DiagnosisWebServicesPortType.setSpecifiedParameterValuesByItemName(setParameterValuesRequestEntry, "DiagnosisWifiSetUp");
			
			if(response == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.FAILURE);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}
			responseMessage.setDetail("wifiSetup response=" + response);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wifiSetup("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("wifiSetup response=" + e.getMessage() + ", ");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=wifiSetup| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
			
		return responseMessage;
	}
	
	public ResponseMessage getParameterValues( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		ArrayList<ResponseDataKeyValue> getParameterValuesResponse = new ArrayList<ResponseDataKeyValue>();
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			
			List<String> item_ = new ArrayList<>();
			for (RequestItem i: requestMessage.getParamNameVec()) {
				item_.add(i.getItem());
			
			}
			
			String[] item = item_.stream().toArray(String[]::new);
			
			GetParameterValuesRequestEntry baseRequestEntry = new GetParameterValuesRequestEntry(bindAccount, requestMessage.getRefId(), item);
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getParameterValues(baseRequestEntry);
			
			for (ResponseMapEntry res: responseMapEntry) {
				ResponseDataKeyValue responseDataKeyValue = new ResponseDataKeyValue();
				responseDataKeyValue.setKey(res.getKey());	
				if(res.getKey().endsWith("AutoChannelEnable")) {
					if(res.getValue().equals("true")) {
						responseDataKeyValue.setValue("1"); 
					} else if (res.getValue().equals("false")) {
						responseDataKeyValue.setValue("0"); 
					} else {
						responseDataKeyValue.setValue(res.getValue()); 
					}
				} else {
					responseDataKeyValue.setValue(res.getValue()); 
				} 
				getParameterValuesResponse.add(responseDataKeyValue);
			}	
			
			responseMessage.getResponseData().setGetParameterValuesResponse(getParameterValuesResponse);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
  			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getParameterValues("+requestMessage.getFibreId()+"): exc_fail", e);

			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("getWifiInfo response=" + e.getMessage() + ", ");	
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getParameterValues| " + requestMessage.toString() + "| " + Arrays.toString(getParameterValuesResponse.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}

	public ResponseMessage setParameterValues( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_avs), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpe112DiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}	
		
			List<String> paramNames_ = new ArrayList<>();
			List<String> paramValue_ = new ArrayList<>();
			for (RequestDataKeyValue i: requestMessage.getParameterValues()) {
				paramNames_.add(i.getKey());
				paramValue_.add(i.getValue());
			
			}
			
			String[] paramNames = paramNames_.stream().toArray(String[]::new);
			String[] paramValue = paramValue_.stream().toArray(String[]::new);
			
			SetParameterValuesRequestEntry setParameterValuesRequestEntry = new SetParameterValuesRequestEntry();
			setParameterValuesRequestEntry.setParamNames(paramNames);
			setParameterValuesRequestEntry.setParamValues(paramValue);
			setParameterValuesRequestEntry.setBindAccount(bindAccount);
			int response = cpe112DiagnosisWebServicesPortType.setParameterValues(setParameterValuesRequestEntry);
			
			if(response == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.FAILURE);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}
			responseMessage.setDetail("setParameterValues response=" + response);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("setParameterValues("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("setParameterValues response=" + e.getMessage() + ", ");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=setParameterValues| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
			
		return responseMessage;
	}
	
	public ResponseMessage upgradeFirmware(RequestMessage requestMessage, ResponseMessage responseMessage) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		
		try {

			CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_avs), new CpeDiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpeDiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			DownloadRequestEntry downloadRequestEntry = new DownloadRequestEntry(bindAccount, requestMessage.getRefId(), requestMessage.getFirmwareVersion() != null?requestMessage.getFirmwareVersion():null);					
			int cpeUpgrade = cpeDiagnosisWebServicesPortType.downloadVersion(downloadRequestEntry);
		
			// CPE Upgrade Success
			responseMessage.setDetail(String.valueOf(cpeUpgrade));
			if(cpeUpgrade == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			responseMessage.setDetail("upgradeFirmware response=" + cpeUpgrade);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("upgradeFirmware("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=upgradeFirmware| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);

		return responseMessage;		
	}
	
	public ResponseMessage reboot( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {

			CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_avs), new CpeDiagnosisWebServicesPortTypeImplServiceLocator());
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpeDiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);			

			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			DiagnosisRebootRequestEntry diagnosisRebootRequestEntry = new DiagnosisRebootRequestEntry(bindAccount, requestMessage.getRefId());
			int cpeReboot = cpeDiagnosisWebServicesPortType.reboot(diagnosisRebootRequestEntry);
			
			// Reboot Success
			responseMessage.setDetail(String.valueOf(cpeReboot));
			if(cpeReboot == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			responseMessage.setDetail("reboot response=" + cpeReboot);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("reboot("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=reboot| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);

		return responseMessage;	
	}
	
	public ResponseMessage factoryReset(RequestMessage requestMessage, ResponseMessage responseMessage) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		
		try {

			CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_avs), new CpeDiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			Stub axisPort = (Stub) cpeDiagnosisWebServicesPortType;
			axisPort._setProperty(javax.xml.rpc.Stub.USERNAME_PROPERTY, InitialParameter.username_avs);
			axisPort._setProperty(javax.xml.rpc.Stub.PASSWORD_PROPERTY, InitialParameter.password_avs);
			s.setTimeout(InitialParameter.connection_timeout);			
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			DiagnosisFactoryResetRequestEntry diagnosisFactoryResetRequestEntry = new DiagnosisFactoryResetRequestEntry(bindAccount, requestMessage.getRefId());					
			int factoryReset = cpeDiagnosisWebServicesPortType.factoryReset(diagnosisFactoryResetRequestEntry);
		
			// Factory Reset Success
			responseMessage.setDetail(String.valueOf(factoryReset));
			if(factoryReset == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			responseMessage.setDetail("factoryReset response=" + factoryReset);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
	
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("factoryReset("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=factoryReset| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
	
		return responseMessage;			
	}

	public ResponseMessage uploadCFG(RequestMessage requestMessage, ResponseMessage responseMessage) {
		UMPTaskTemplate umpTaskTemplate = new UMPTaskTemplate();
		long start = System.currentTimeMillis();

		String uri = "";
		try {
			uri = "tasksFromTemplates/device/" + responseMessage.getDeviceId() + "?exactId=false";
			
			UMPConfig umpConfig = new UMPConfig();
			ArrayList<UMPNameValue> parameters = new ArrayList<UMPNameValue>();
			umpConfig.setTaskName(singleConfigurationBackup);
			umpConfig.setParameters(parameters);
			
			umpTaskTemplate.setTemplateName(singleConfigurationBackup);
			umpTaskTemplate.setConfig(umpConfig);
			responseMessage = send("backupConfig (deviceId)", methodPOST, uri, true, new Gson().toJson(umpTaskTemplate), responseMessage);
			
			if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				ExecutorService execServiceFCollector = Executors.newSingleThreadExecutor();
				execServiceFCollector.execute( new ExecutionSession(requestMessage, responseMessage));
			}
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("uploadCFG("+requestMessage.getFibreId()+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail("uploadCFG response=" + e.getMessage() + ", ");	
			} finally {
				responseMessage.setUmpResponse(null);
				responseMessage.setDeviceId(null);
			}
	
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=uploadCFG| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 			
	}	


	public ResponseMessage getCFGList(RequestMessage requestMessage, ResponseMessage responseMessage) {
		ResponseData responseData = new ResponseData();
		ArrayList<ResponseDataConfigs> configs = new ArrayList<ResponseDataConfigs>();
		long start = System.currentTimeMillis();

		String uri = "";
		try {
			responseData.setDeviceId(responseMessage.getDeviceId());
			uri = "resources?searchCriteria=device%20eq%20%27" + responseMessage.getDeviceId() + "%27%2C%20category%20eq%20%27CONFIG%27";	
			
			responseMessage = send("listConfig (deviceId)", methodGET, uri, true, new Gson().toJson(""), responseMessage);
			
			if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				if(responseMessage.getListConfig() != null && responseMessage.getListConfig().size() > 0) {
					for(String i : responseMessage.getListConfig()) {
						uri = "resources/" + i;	
						ResponseMessage responseMessage_ = send("listConfig (filename)", methodGET, uri, true, new Gson().toJson(""), responseMessage); 
						
						if(responseMessage_.getUmpResponseConfigs() != null) {
							ResponseDataConfigs responseDataConfigs = new ResponseDataConfigs();
							responseDataConfigs.setFileName(i);
							responseDataConfigs.setFileSize(responseMessage_.getUmpResponseConfigs().getFileSize());
							try {
								//responseDataConfigs.setTime(responseMessage_.getUmpResponseConfigs().getAddDate().split("\\.")[0].replace("T", " "));
								
								String tempDate = responseMessage_.getUmpResponseConfigs().getAddDate().split("\\.")[0].replace("T", " ");
								SimpleDateFormat newDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
								Date newDate = null;
								try {	
								    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								    Date parsedDate = dateFormat.parse(tempDate);
								    
								    long HOUR = 3600*1000;     
								    newDate = new Date(parsedDate.getTime() + 7 * HOUR);
								} catch(Exception e) { //this generic but you can control another types of exception
								    // look the origin of excption
									e.printStackTrace();
									responseDataConfigs.setTime(null);
								}
								responseDataConfigs.setTime(newDateFormat.format(newDate));
								
							} catch(Exception e) {e.printStackTrace();}
							responseDataConfigs.setBackupType(responseMessage_.getUmpResponseConfigs().getDescription());
							configs.add(responseDataConfigs);
							responseMessage.setUmpResponseConfigs(null);
						}
					}
					responseData.setConfigs(configs);
					responseMessage.setResponseData(responseData);
				}
			}
			
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("getCFGList("+requestMessage.getFibreId()+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail("getCFGList response=" + e.getMessage() + ", ");	
			} finally {
				responseMessage.setDeviceId(null);
				responseMessage.setListConfig(null);
				responseMessage.setUmpResponseConfigs(null);
			}
	
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getCFGList| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 			
	}

	public ResponseMessage downloadCFGToDevice(RequestMessage requestMessage, ResponseMessage responseMessage) {
		// TODO Auto-generated method stub
		UMPTaskTemplate umpTaskTemplate = new UMPTaskTemplate();
		long start = System.currentTimeMillis();

		String uri = "";
		try {
			uri = "tasksFromTemplates/device/" + responseMessage.getDeviceId() + "?exactId=false";
			
			UMPConfig umpConfig = new UMPConfig();
			ArrayList<UMPNameValue> parameters = new ArrayList<UMPNameValue>();
			UMPNameValue umpNameValue = new UMPNameValue();
			umpNameValue.setName("fileID");
			umpNameValue.setValue(requestMessage.getConfigFileName());
			parameters.add(umpNameValue);
			umpConfig.setTaskName(chosenConfigurationRestore);
			umpConfig.setParameters(parameters);
			
			umpTaskTemplate.setTemplateName(chosenConfigurationRestore);
			umpTaskTemplate.setConfig(umpConfig);
			responseMessage = send("restoreConfig (deviceId)", methodPOST, uri, true, new Gson().toJson(umpTaskTemplate), responseMessage);
			
			if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				ExecutorService execServiceFCollector = Executors.newSingleThreadExecutor();
				execServiceFCollector.execute( new ExecutionSession(requestMessage, responseMessage));
			}
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("uploadCFG("+requestMessage.getFibreId()+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail("uploadCFG response=" + e.getMessage() + ", ");	
			} finally {
				responseMessage.setUmpResponse(null);
				responseMessage.setDeviceId(null);
			}
	
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=uploadCFG| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 
	}
	
	public ResponseMessage checkVoIPProfile(RequestMessage requestMessage, ResponseMessage responseMessage) {

		long start = System.currentTimeMillis();

		String uri = "";
		try {

			uri = "settingValues/deviceProfile/" + responseMessage.getDeviceId() + "?withDeviceProperties=false&exactId=false";	
			
			responseMessage = send("checkVoIPProfile (deviceId)", methodGET, uri, true, new Gson().toJson(""), responseMessage);
			
			if(!responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
			}
			
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("checkVoIPProfile("+requestMessage.getFibreId()+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail("checkVoIPProfile response=" + e.getMessage() + ", ");	
			} finally {
				responseMessage.setDeviceId(null);
				responseMessage.setListConfig(null);
				responseMessage.setUmpResponseConfigs(null);
				if(responseMessage.getResponseData() != null) {
					responseMessage.getResponseData().setBasicInfo(null);
				}
			}
	
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=checkVoIPProfile| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 			
	}
	
	public ResponseMessage tasksFromTemplates(RequestMessage requestMessage, ResponseMessage responseMessage, String template) {
		UMPTaskTemplate umpTaskTemplate = new UMPTaskTemplate();
		long start = System.currentTimeMillis();
		
		ResponseMessage responseMessage_ = new ResponseMessage("AVS");
		ResponseData responseData = new ResponseData();
		responseMessage_.setResponseData(responseData);

		String uri = "";
		try {
			if(responseMessage.getDeviceId() != null ) {
				uri = "tasksFromTemplates/device/" + responseMessage.getDeviceId() + "?exactId=false";
				
				UMPConfig umpConfig = new UMPConfig();
				ArrayList<UMPNameValue> parameters = new ArrayList<UMPNameValue>();
				umpConfig.setTaskName(template);
				umpConfig.setParameters(parameters);
				
				umpTaskTemplate.setTemplateName(template);
				umpTaskTemplate.setConfig(umpConfig);
				responseMessage = send("tasksFromTemplates (deviceId)", methodPOST, uri, true, new Gson().toJson(umpTaskTemplate), responseMessage);
				
			} else {
				requestMessage.setOption(basicInfoOption);	
				responseMessage_ = getBasicInfo(requestMessage, responseMessage);
				if(responseMessage_.getResponseCode().equals(Code.SUCCESS)) {
					if(responseMessage_.getResponseData() != null && responseMessage_.getResponseData().getBasicInfo() != null ) {
						
						responseMessage.setDeviceId(responseMessage_.getResponseData().getBasicInfo().getDeviceId());
						
						uri = "tasksFromTemplates/device/" + responseMessage.getDeviceId() + "?exactId=false";
						
						UMPConfig umpConfig = new UMPConfig();
						ArrayList<UMPNameValue> parameters = new ArrayList<UMPNameValue>();
						umpConfig.setTaskName(template);
						umpConfig.setParameters(parameters);
						
						umpTaskTemplate.setTemplateName(template);
						umpTaskTemplate.setConfig(umpConfig);
						responseMessage = send("tasksFromTemplates (deviceId)", methodPOST, uri, true, new Gson().toJson(umpTaskTemplate), responseMessage);
						
						
					} 
					
				}
			}
			
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("tasksFromTemplates("+requestMessage.getFibreId()+"): exc_fail", e);
				
//				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail("tasksFromTemplates response=" + e.getMessage() + ", ");	
			} finally {
				responseMessage.setUmpResponse(null);
				responseMessage.setDeviceId(null);
			}
	
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=tasksFromTemplates| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 			
	}	
	
	
	public static ResponseMessage send(String name, String method, String uri, boolean enable_ssl, String request, ResponseMessage responseMessage) {
		// Generate UUID for transaction tracking
		long start = System.currentTimeMillis();
		String ssid = UUID.randomUUID().toString();	
		HttpURLConnection conn = null;
		OutputStream os = null;	
		StringBuilder sb = new StringBuilder();
		try {	
				
			if (InitialParameter.MODE == 1) {
		        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
		                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		                    return null;
		                }
		                public void checkClientTrusted(X509Certificate[] certs, String authType) {
		                }
		                public void checkServerTrusted(X509Certificate[] certs, String authType) {
		                }
		            }
		        };
		 
		        SSLContext sc = SSLContext.getInstance("TLSv1.2");
		        sc.init(null, trustAllCerts, new java.security.SecureRandom());
		        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		 
		        HostnameVerifier allHostsValid = new HostnameVerifier() {
		            public boolean verify(String hostname, SSLSession session) {
		                return true;
		            }
		        };
	 
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        
			}
			// Gen Smpp Connection From SMPP Connection Pool				
			URL url = new URL(InitialParameter.url_ump_avs + uri);
			conn = (HttpURLConnection) url.openConnection();
			
			if(method.equals(methodPATCH)) {
				allowMethods("PATCH");
				conn.setRequestMethod(method);	
			} else {
				conn.setRequestMethod(method);
			}
			
			conn.setRequestProperty("Accept-Charset", "UTF-8");
			conn.setRequestProperty("charset", "UTF-8");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setDoOutput(true);
			String userpass = InitialParameter.username_ump_avs + ":" + InitialParameter.password_ump_avs;
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
			conn.setRequestProperty ("Authorization", basicAuth);

			if( method.equals(methodGET)) {
				
			} else {	
				os = conn.getOutputStream();
				if(method.equals(methodDELETE) ) {
					byte[] data = "{}".getBytes("UTF-8");
					os.write(data);
					os.flush();
				} else if(name.equals("executeSession")) {
					byte[] data = "{}".getBytes("UTF-8");
					os.write(data);
					os.flush();
				} else {
					byte[] data = request.getBytes("UTF-8");
					os.write(data);
					os.flush();
				}
			}

			
			BufferedReader br;
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK && conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL)+ ", " + conn.getResponseCode() + ":" + conn.getResponseMessage());			
				
			} else {
				br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}

            
            String line;
            while ((line = br.readLine()) != null) {
            	sb.append(line+"\n");
            }
            br.close();

            if (sb.toString() != null) {
            	responseMessage.setDetail(name+ "=" + sb.toString());
            	Gson gson= new Gson();
            	if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            		if(name.equals("provisioning (get)")) {
		            	UMPProvisioning umpProvisioning = gson.fromJson(sb.toString() , UMPProvisioning.class);
		            	responseMessage.setUmpProvisioning(umpProvisioning);
            		}
            		if(name.equals("getLastSessionTime (deviceId)")) {
            			
            			JSONArray arr = new JSONArray(sb.toString());
            			ArrayList<String> deviceId = new ArrayList<String>();
            			for(int i = 0; i < arr.length(); i++){
            				deviceId.add(arr.getString(i));
            			}
            			if(deviceId.size() == 0)	{
            				responseMessage.setResponseCode(Code._3500008);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3500008));
            				responseMessage.setDetail(ReponseCode.fromId(Code._3500008));
            				
            			} else if(deviceId.size() == 1)	{
            				responseMessage.setDeviceId(deviceId.get(0));
            				
            			} else {
            				responseMessage.setResponseCode(Code.MULTIPLE_DEVICE);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MULTIPLE_DEVICE));
            				responseMessage.setDetail(ReponseCode.fromId(Code.MULTIPLE_DEVICE));
            			}
            			
            		}
            		if(name.equals("getLastSessionTime (info)")) {
            			UMPResponse umpResponse = gson.fromJson(sb.toString() , UMPResponse.class);
		            	responseMessage.setUmpResponse(umpResponse);
		            	responseMessage.setDetail(name+ "=" + "Success");
            		}
            		if(name.equals("listConfig (deviceId)")) {
            			JSONArray arr = new JSONArray(sb.toString());
            			ArrayList<String> listConfig = new ArrayList<String>();
            			for(int i = 0; i < arr.length(); i++){
            				listConfig.add(arr.getString(i));
            			}
            			
            			if(listConfig.size() == 0)	{
            				responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
            				responseMessage.setDetail(ReponseCode.fromId(Code.DATA_NOT_FOUND));
            				
            			} else {
            				responseMessage.setListConfig(listConfig);
            			}
            			
            		}
            		if(name.equals("listConfig (filename)")) {
            			UMPResponseConfigs umpResponseConfigs = gson.fromJson(sb.toString() , UMPResponseConfigs.class);
            			responseMessage.setUmpResponseConfigs(umpResponseConfigs);
            			responseMessage.setDetail(name+ "=" + "Success");
            		}
            		
            		if(name.equals("checkVoIPProfile (deviceId)")) {
            			JSONArray arr = new JSONArray(sb.toString());
            			for(int i = 0; i < arr.length(); i++){
            				UMPResponseSettingValue res = gson.fromJson(arr.getString(i) , UMPResponseSettingValue.class);
            				
            				if(res.getName().equals("supportsVoip")) {
            					if(res.getValue().equals("false")) {
            						responseMessage.getResponseData().setVoipProfile("N");
            					} else {
            						responseMessage.getResponseData().setVoipProfile("Y");
            					}
            					responseMessage.setDetail(null);
                				break;
            				}

            			}
            			
            		}
            		
            	}

            }
            				
			if(os != null) os.close();
			conn.disconnect();
			
		} catch(Exception e) {		
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("send("+name+":"+uri+"): exc_fail", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL)+ " =" +e.getMessage());
			responseMessage.setDetail(name+ "=" + e);
			///return responseMessage;
			
		} finally {
			if(os != null)
				try {
					os.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(conn != null) conn.disconnect();
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		String res = sb.toString().replace("\n", "").replace("\r", "");
		LOGGER_DEBUG.log("method="+name+"(send)| uri=" + uri + "| message=" + request + "| response=" + res + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}
	
	private static void allowMethods(String... methods) {
        try {
            Field methodsField = HttpURLConnection.class.getDeclaredField("methods");

            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(methodsField, methodsField.getModifiers() & ~Modifier.FINAL);

            methodsField.setAccessible(true);

            String[] oldMethods = (String[]) methodsField.get(null);
            Set<String> methodsSet = new LinkedHashSet<>(Arrays.asList(oldMethods));
            methodsSet.addAll(Arrays.asList(methods));
            String[] newMethods = methodsSet.toArray(new String[0]);

            methodsField.set(null/*static field*/, newMethods);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new IllegalStateException(e);
        }
    }
	
	
	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}
	
	private ResponseMessage axisFault(RequestMessage requestMessage, ResponseMessage responseMessage, AxisFault axisFault) {
		try {
			String message = "";
			if( axisFault.getFaultSubCodes() != null && axisFault.getFaultSubCodes()[0] != null) {
				message = message + axisFault.getFaultSubCodes()[0].toString();
			}
			message = message + axisFault.getFaultCode().toString();
			
			if(message.contains("3501700")) {
				responseMessage.setResponseCode(Code._3501700);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3501700));
				responseMessage.setDetail(ReponseCode.fromId(Code._3501700));
			} else if(message.contains("3501703")) {
				responseMessage.setResponseCode(Code._3501703);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3501703));
				responseMessage.setDetail(ReponseCode.fromId(Code._3501703));
			} else if(message.contains("3500008")) {
				responseMessage.setResponseCode(Code._3500008);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3500008));
				responseMessage.setDetail(ReponseCode.fromId(Code._3500008));
			} else if(message.contains("3519000")) {
				responseMessage.setResponseCode(Code._3519000);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519000));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519000));
			} else if(message.contains("3519002")) {
				responseMessage.setResponseCode(Code._3519002);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519002));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519002));
			} else if(message.contains("3519003")) {
				responseMessage.setResponseCode(Code._3519003);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519003));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519003));
			} else if(message.contains("3519005")) {
				responseMessage.setResponseCode(Code._3519005);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519005));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519005));
			} else if(message.contains("3519008")) {
				responseMessage.setResponseCode(Code._3519008);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519008));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519008));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(axisFault.getFaultString());
			} 
			
		} catch(Exception e) {
			e.printStackTrace();
			LOGGER_DEBUG.log("axisFault("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
			return responseMessage;
		}
		
		return responseMessage;
	}

}
