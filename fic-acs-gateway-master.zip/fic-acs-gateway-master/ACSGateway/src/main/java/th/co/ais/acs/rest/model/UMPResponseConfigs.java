package th.co.ais.acs.rest.model;

public class UMPResponseConfigs {
	String id           = null;
	String name         = null;
	String description  = null;
	String category     = null;
	String filename     = null;
	String fileSize     = null;
	String device       = null;
	String fileType     = null;
	String username     = null;
	String password     = null;
	String location     = null;
	String addDate      = null;
	String domain       = null;
	String dataId       = null;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getAddDate() {
		return addDate;
	}
	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getDataId() {
		return dataId;
	}
	public void setDataId(String dataId) {
		this.dataId = dataId;
	}
	@Override
	public String toString() {
		return "UMPResponseConfigs [id=" + id + ", name=" + name + ", description=" + description + ", category="
				+ category + ", filename=" + filename + ", fileSize=" + fileSize + ", device=" + device + ", fileType="
				+ fileType + ", username=" + username + ", password=" + password + ", location=" + location
				+ ", addDate=" + addDate + ", domain=" + domain + ", dataId=" + dataId + "]";
	}
	
	
}
