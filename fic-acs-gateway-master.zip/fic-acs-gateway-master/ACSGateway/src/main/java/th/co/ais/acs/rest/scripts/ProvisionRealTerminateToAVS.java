package th.co.ais.acs.rest.scripts;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.codehaus.jettison.json.JSONArray;

import com.google.gson.Gson;

import th.co.ais.acs.rest.db.NamedParameterStatement;
import th.co.ais.acs.rest.db.Sql;
import th.co.ais.acs.rest.impl.ExecutionSession;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseDataKeyValue;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UMPProvisioning;
import th.co.ais.acs.rest.model.UMPProvisioningProperties;
import th.co.ais.acs.rest.model.UMPResponse;

public class ProvisionRealTerminateToAVS {
	
	private static final String methodGET = "GET";
	private static final String methodPUT = "PUT";
	private static final String methodPATCH = "PATCH";
	private static final String methodDELETE = "DELETE";
	private static final String methodPOST = "POST";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		int count = 0;
		try {
			
			System.out.println(new Date());
			System.out.println("Start ProvisionRealTerminateToAVS v1.0");
			ArrayList<CustomerIdTokenInfo> tokenList = queryActivationId();
	
			if(tokenList.size() > 0) {
				ResponseMessage responseMessage = new ResponseMessage("AVS");
				UMPProvisioning umpProvisioning = new UMPProvisioning();
				List<String> paramNames_ = new ArrayList<>();
				
				for (CustomerIdTokenInfo i : tokenList) {
					String uri = "propertyServices/actionID/";
					uri = uri + i.getTokenId();
					
					
					ResponseMessage reresponseMessage_ = send("provisioning (get)", methodGET, uri + "?returnMatchedDevice=true", true, new Gson().toJson("{}"), responseMessage);
					if(reresponseMessage_.getResponseCode().equals(Code.SUCCESS)) {
						
						paramNames_.add("internetUsername");
						paramNames_.add("internetPassword");
						paramNames_.add("SIPUsername1");
						paramNames_.add("SIPURI1");
						paramNames_.add("SIPPassword1");
						paramNames_.add("SIPUsername2");
						paramNames_.add("SIPURI2");
						paramNames_.add("SIPPassword2");
						paramNames_.add("bridgeVLAN");
						paramNames_.add("bridgeWAN");
						umpProvisioning.setRemove(paramNames_.stream().toArray(String[]::new));
						responseMessage = send("provisioning (remove)", methodPATCH, uri, true, new Gson().toJson(umpProvisioning), responseMessage);
						long elapsedTimeMillis = System.currentTimeMillis()-start;
						System.out.println(new Date()+", customerId=" + i.getCustomerId()+", activationId=" + i.getTokenId()+ ", provisioning (remove), " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
						
						responseMessage = send("provisioning (removeAll)", methodDELETE, uri, true, new Gson().toJson("{}"), responseMessage);	
						elapsedTimeMillis = System.currentTimeMillis()-start;
						System.out.println(new Date()+", customerId=" + i.getCustomerId()+", activationId=" + i.getTokenId()+ ", provisioning (removeAll), " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
						
					} else {
						long elapsedTimeMillis = System.currentTimeMillis()-start;
						System.out.println(new Date()+", customerId=" + i.getCustomerId()+", activationId=" + i.getTokenId()+ ", provisioning (notfound), " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
						
					}
					count++;
				}
				
				long elapsedTimeMillis = System.currentTimeMillis()-start;
				ExecutorService execServiceFCollector = Executors.newSingleThreadExecutor();
				execServiceFCollector.execute( new InsertReportThread("R089", count, Integer.valueOf(String.valueOf(elapsedTimeMillis)), "SUCCESS"));
			}
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			long elapsedTimeMillis = System.currentTimeMillis()-start;
			ExecutorService execServiceFCollector = Executors.newSingleThreadExecutor();
			execServiceFCollector.execute( new InsertReportThread("R089", count, 0, "FAIL"));
		}

	}
	
	public static ArrayList<CustomerIdTokenInfo> queryActivationId() {
		long start = System.currentTimeMillis();
		ArrayList<CustomerIdTokenInfo> tokenList = new ArrayList<CustomerIdTokenInfo>();
		Connection conn = null;
		NamedParameterStatement pStmt0 = null;
		ResultSet rs = null;
		int result = 0;
		String sqlStr0 = "select customer_id, token_id from internet_account where status='TERMINATE' and terminate_date > TRUNC(SYSDATE-64) and terminate_date < TRUNC(SYSDATE-63)";
		try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url = "jdbc:oracle:thin:@" + "10.154.10.16" + ":" + "1510" + ":"+ "AISFIBRE";
				conn = DriverManager.getConnection(url, "aisfibre", "f1cA1sfibr3");
								
				pStmt0 = new NamedParameterStatement(conn, sqlStr0);
				rs = pStmt0.executeQuery();
				
				while (rs.next()) {
					CustomerIdTokenInfo customerIdTokenInfo = new CustomerIdTokenInfo();
					customerIdTokenInfo.setCustomerId(rs.getString("customer_id"));
					customerIdTokenInfo.setTokenId(rs.getString("token_id"));
					tokenList.add(customerIdTokenInfo);
				} 
	
				long elapsedTimeMillis = System.currentTimeMillis()-start;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
	
		}
		
		return tokenList;
	
	}
	
	public static ResponseMessage send(String name, String method, String uri, boolean enable_ssl, String request, ResponseMessage responseMessage) {
		// Generate UUID for transaction tracking
		String ssid = UUID.randomUUID().toString();	
		HttpURLConnection conn = null;
		OutputStream os = null;	
		try {	
				
			if (enable_ssl) {
		        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
		                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		                    return null;
		                }
		                public void checkClientTrusted(X509Certificate[] certs, String authType) {
		                }
		                public void checkServerTrusted(X509Certificate[] certs, String authType) {
		                }
		            }
		        };
		 
		        SSLContext sc = SSLContext.getInstance("TLSv1.2");
		        sc.init(null, trustAllCerts, new java.security.SecureRandom());
		        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		 
		        HostnameVerifier allHostsValid = new HostnameVerifier() {
		            public boolean verify(String hostname, SSLSession session) {
		                return true;
		            }
		        };
	 
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        
			}
			// Gen Smpp Connection From SMPP Connection Pool				
			URL url = new URL("https://ws.avacs.intra.ais:8087/api/ump/v3/" + uri);
			conn = (HttpURLConnection) url.openConnection();
			
			if(method.equals(methodPATCH)) {
				allowMethods("PATCH");
				conn.setRequestMethod(method);	
			} else {
				conn.setRequestMethod(method);
			}
			
			conn.setRequestProperty("Accept-Charset", "UTF-8");
			conn.setRequestProperty("charset", "UTF-8");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setDoOutput(true);
			String userpass = "fic" + ":" + "@Fbb&fcp0";
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
			conn.setRequestProperty ("Authorization", basicAuth);
			
			
			if( method.equals(methodGET)) {
				
			} else {	
				os = conn.getOutputStream();
				if(method.equals(methodDELETE) ) {
					byte[] data = "{}".getBytes("UTF-8");
					os.write(data);
					os.flush();
				} else {
					byte[] data = request.getBytes("UTF-8");
					os.write(data);
					os.flush();
				}
			}

			
			BufferedReader br;
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK && conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			} else {
				br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
            	sb.append(line+"\n");
            }
            br.close();

            if (sb.toString() != null) {
            	responseMessage.setDetail(name+ "=" + sb.toString().replace("\n", ""));
            	Gson gson= new Gson();
            	if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            		if(name.equals("provisioning (get)")) {
		            	UMPProvisioning umpProvisioning = gson.fromJson(sb.toString() , UMPProvisioning.class);
		            	responseMessage.setUmpProvisioning(umpProvisioning);
            		}
            		if(name.equals("getLastSessionTime (deviceId)")) {
            			
            			JSONArray arr = new JSONArray(sb.toString());
            			ArrayList<String> deviceId = new ArrayList<String>();
            			for(int i = 0; i < arr.length(); i++){
            				deviceId.add(arr.getString(i));
            			}
            			if(deviceId.size() == 0)	{
            				responseMessage.setResponseCode(Code._3500008);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3500008));
            				responseMessage.setDetail(ReponseCode.fromId(Code._3500008));
            				
            			} else if(deviceId.size() == 1)	{
            				responseMessage.setDeviceId(deviceId.get(0));
            				
            			} else {
            				responseMessage.setResponseCode(Code.MULTIPLE_DEVICE);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MULTIPLE_DEVICE));
            				responseMessage.setDetail(ReponseCode.fromId(Code.MULTIPLE_DEVICE));
            			}
            		
            		}
            		if(name.equals("getLastSessionTime (info)")) {
            			UMPResponse umpResponse = gson.fromJson(sb.toString() , UMPResponse.class);
		            	responseMessage.setUmpResponse(umpResponse);
            		}
            		if(name.equals("listConfig (deviceId)")) {
            			JSONArray arr = new JSONArray(sb.toString());
            			ArrayList<String> listConfig = new ArrayList<String>();
            			for(int i = 0; i < arr.length(); i++){
            				listConfig.add(arr.getString(i));
            			}
            			
            			if(listConfig.size() == 0)	{
            				responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
            				responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
            				responseMessage.setDetail(ReponseCode.fromId(Code.DATA_NOT_FOUND));
            				
            			} else {
            				responseMessage.setListConfig(listConfig);
            			}
            			
            		}
            		
            		
            	}

            }
            				
			if(os != null) os.close();
			conn.disconnect();
			
		} catch(Exception e) {		
			// TODO Auto-generated catch block
			e.printStackTrace();
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(name+ "=" + e);
			return responseMessage;
			
		} finally {
			if(os != null)
				try {
					os.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(conn != null) conn.disconnect();
		}
		
		return responseMessage;
	}
	
	private static void allowMethods(String... methods) {
        try {
            Field methodsField = HttpURLConnection.class.getDeclaredField("methods");

            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(methodsField, methodsField.getModifiers() & ~Modifier.FINAL);

            methodsField.setAccessible(true);

            String[] oldMethods = (String[]) methodsField.get(null);
            Set<String> methodsSet = new LinkedHashSet<>(Arrays.asList(oldMethods));
            methodsSet.addAll(Arrays.asList(methods));
            String[] newMethods = methodsSet.toArray(new String[0]);

            methodsField.set(null/*static field*/, newMethods);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new IllegalStateException(e);
        }
    }

}


	
