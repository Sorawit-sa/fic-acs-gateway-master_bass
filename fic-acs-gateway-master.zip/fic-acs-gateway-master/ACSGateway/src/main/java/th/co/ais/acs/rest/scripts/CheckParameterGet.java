package th.co.ais.acs.rest.scripts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.rpc.Stub;

import org.apache.axis.AxisFault;

import com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry;

import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceLocator;
import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestDataKeyValue;
import th.co.ais.acs.rest.model.RequestItem;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseDataKeyValue;
import th.co.ais.acs.rest.model.ResponseDataWiFiInfo;
import th.co.ais.acs.rest.model.ResponseMessage;

public class CheckParameterGet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		getParameterValues("8801435850");
		
		getParameterValues("8800490650");
		getParameterValues("8800198101");
		getParameterValues("8801648147");
		getParameterValues("8800328135");
		getParameterValues("8802340981");
		getParameterValues("8801435850");
		getParameterValues("8800435014");
		getParameterValues("8803701599");
		getParameterValues("8801346076");
		getParameterValues("8802291298");
		getParameterValues("8802272937");
		getParameterValues("8800819553");
		getParameterValues("8802379767");
		getParameterValues("8802449860");
		getParameterValues("8800905150");
		getParameterValues("8801410768");
		getParameterValues("8800661837");
		getParameterValues("8800834910");
		getParameterValues("8800563830");
		getParameterValues("8802087554");
		getParameterValues("8802410441");
		getParameterValues("8802346246");
		getParameterValues("8802404557");
		getParameterValues("8800982054");
		getParameterValues("8802419956");
		getParameterValues("8802386885");
		getParameterValues("8800476950");
		getParameterValues("8802542840");
		getParameterValues("8802267023");
		getParameterValues("8802357954");
		getParameterValues("8801382630");
		getParameterValues("8802339429");
		getParameterValues("8800917592");
		getParameterValues("8802278176");
		getParameterValues("8800669103");
		getParameterValues("8800408627");
		getParameterValues("8802375060");
		getParameterValues("8802386397");
		getParameterValues("8802300534");
		getParameterValues("8801665082");
		getParameterValues("8802277163");
		getParameterValues("8800632422");
		getParameterValues("8802418948");
		getParameterValues("8801308565");
		getParameterValues("8802261686");
		getParameterValues("8800585362");
		getParameterValues("8800410648");
		getParameterValues("8800138977");
		getParameterValues("8801337517");
		getParameterValues("8802350154");
		getParameterValues("8802300867");
		getParameterValues("8802291639");
		getParameterValues("8800820309");
		getParameterValues("8802388189");
		getParameterValues("8802349679");
		getParameterValues("8801545947");
		getParameterValues("8802405040");
		getParameterValues("8800446543");
		getParameterValues("8801478520");
		getParameterValues("8800478894");
		getParameterValues("8800602733");
		getParameterValues("8802290774");
		getParameterValues("8800999022");
		getParameterValues("8802312741");
		getParameterValues("8802398780");
		getParameterValues("8800987891");
		getParameterValues("8801294713");
		getParameterValues("8800928481");
		getParameterValues("8801263607");
		getParameterValues("8800802981");
		getParameterValues("8802323385");
		getParameterValues("8802403169");
		getParameterValues("8802287904");
		getParameterValues("8801767560");
		getParameterValues("8802276389");
		getParameterValues("8802362981");
		getParameterValues("8802428201");
		getParameterValues("8801795142");
		getParameterValues("8802282168");
		getParameterValues("8800072540");
		getParameterValues("8802401988");
		getParameterValues("8801529852");
		getParameterValues("8802326593");
		getParameterValues("8801623220");
		getParameterValues("8802343123");
		getParameterValues("8802404711");
		getParameterValues("8802297402");
		getParameterValues("8802272910");
		getParameterValues("8802725530");
		getParameterValues("8802400514");
		getParameterValues("8801406673");
		getParameterValues("8802301082");
		getParameterValues("8802327071");
		getParameterValues("8802310120");
		getParameterValues("8802410416");
		getParameterValues("8802409640");
		getParameterValues("8802346220");
		getParameterValues("8802408592");
		getParameterValues("8802411051");
		getParameterValues("8802455783");
		getParameterValues("8800742774");
		getParameterValues("8801142134");
		getParameterValues("8801314678");
		getParameterValues("8800441979");
		getParameterValues("8802461503");
		getParameterValues("8801654827");
		getParameterValues("8802304018");
		getParameterValues("8801948039");
		getParameterValues("8801419626");
		getParameterValues("8801296201");
		getParameterValues("8802413768");
		getParameterValues("8800519348");
		getParameterValues("8802305029");
		getParameterValues("8802414867");
		getParameterValues("8800599700");
		getParameterValues("8802315758");
		getParameterValues("8800960760");
		getParameterValues("8800292430");
		getParameterValues("8801583144");
		getParameterValues("8802416357");
		getParameterValues("8800565489");
		getParameterValues("8802413429");
		getParameterValues("8802290411");
		getParameterValues("8801434536");
		getParameterValues("8802309072");
		getParameterValues("8802347519");
		getParameterValues("8802417044");
		getParameterValues("8801684785");
		getParameterValues("8800852132");
		getParameterValues("8800283700");
		getParameterValues("8801740322");
		getParameterValues("8802421980");
		getParameterValues("8800961832");
		getParameterValues("8801546863");
		getParameterValues("8802124235");
		getParameterValues("8800249634");
		getParameterValues("8800276053");
		getParameterValues("8800536905");
		getParameterValues("8802426446");
		getParameterValues("8800684848");
		getParameterValues("8800806801");
		getParameterValues("8802345120");
		getParameterValues("8802423462");
		getParameterValues("8802355225");
		getParameterValues("8801669086");
		getParameterValues("8802353957");
		getParameterValues("8800043602");
		getParameterValues("8802332985");
		getParameterValues("8802297236");
		getParameterValues("8802778775");
		getParameterValues("8802405211");
		getParameterValues("8800975153");
		getParameterValues("8800677416");
		getParameterValues("8802422236");
		getParameterValues("8802458309");
		getParameterValues("8802423382");
		getParameterValues("8802697091");
		getParameterValues("8802304216");
		getParameterValues("8801478366");
		getParameterValues("8802345933");
		getParameterValues("8802456327");
		getParameterValues("8800737475");
		getParameterValues("8803706594");
		getParameterValues("8802277797");
		getParameterValues("8802425168");
		getParameterValues("8802430458");
		getParameterValues("8800735961");
		getParameterValues("8802344549");
		getParameterValues("8800045869");
		getParameterValues("8802347610");
		getParameterValues("8801810172");
		getParameterValues("8802341788");
		getParameterValues("8802288863");
		getParameterValues("8801618997");
		getParameterValues("8800830895");
		getParameterValues("8800780802");
		getParameterValues("8802298783");
		getParameterValues("8802289081");
		getParameterValues("8802441031");
		getParameterValues("8802281695");
		getParameterValues("8802355389");
		getParameterValues("8802425388");
		getParameterValues("8802318840");
		getParameterValues("8802334256");
		getParameterValues("8802319471");
		getParameterValues("8802339259");
		getParameterValues("8801172959");
		getParameterValues("8802465855");
		getParameterValues("8800566525");
		getParameterValues("8802156690");
		getParameterValues("8800837348");
		getParameterValues("8802477844");
		getParameterValues("8800735095");
		getParameterValues("8802355238");
		getParameterValues("8800712184");
		getParameterValues("8800477623");
		getParameterValues("8802281325");
		getParameterValues("8800063383");
		getParameterValues("8800297199");
		getParameterValues("8800556626");
		getParameterValues("8802474741");
		getParameterValues("8801145384");
		getParameterValues("8802245807");
		getParameterValues("8801450995");
		getParameterValues("8800323590");
		getParameterValues("8802333433");
		getParameterValues("8801983128");
		getParameterValues("8802584227");
		getParameterValues("8802307979");
		getParameterValues("8801994636");
		getParameterValues("8800282541");
		getParameterValues("8802050390");
		getParameterValues("8800477197");
		getParameterValues("8800520698");
		getParameterValues("8800588691");
		getParameterValues("8800456777");
		getParameterValues("8800634425");
		getParameterValues("8800311997");
		getParameterValues("8800561737");
		getParameterValues("8802130305");
		getParameterValues("8800695038");
		getParameterValues("8800633007");
		getParameterValues("8800388151");
		getParameterValues("8802157200");
		getParameterValues("8802183035");
		getParameterValues("8802160940");
		getParameterValues("8802186909");
		getParameterValues("8801552960");
		getParameterValues("8800079353");
		getParameterValues("8800176628");
		getParameterValues("8800267569");
		getParameterValues("8802211607");
		getParameterValues("8801060922");
		getParameterValues("8800601096");
		getParameterValues("8800335903");
		getParameterValues("8800439960");
		getParameterValues("8800758498");
		getParameterValues("8800900216");
		getParameterValues("8802936760");
		getParameterValues("8800637052");
		getParameterValues("8800401329");
		getParameterValues("8800076433");
		getParameterValues("8800751225");
		getParameterValues("8800442039");
		getParameterValues("8801524335");
		getParameterValues("8800444545");
		getParameterValues("8802264878");
		getParameterValues("8802264867");
		getParameterValues("8802256187");
		getParameterValues("8801422400");
		getParameterValues("8802255470");
		getParameterValues("8802265339");
		getParameterValues("8802263641");
		getParameterValues("8800307474");
		getParameterValues("8802254928");
		getParameterValues("8802261370");
		getParameterValues("8800621044");
		getParameterValues("8800184123");
		getParameterValues("8800371665");
		getParameterValues("8800554623");
		getParameterValues("8802265277");
		getParameterValues("8802271612");
		getParameterValues("8802257745");
		getParameterValues("8801468708");
		getParameterValues("8800546619");
		getParameterValues("8800362000");
		getParameterValues("8802288482");
		getParameterValues("8802223586");
		getParameterValues("8800477004");
		getParameterValues("8800249558");
		getParameterValues("8800616402");
		getParameterValues("8800539719");
		getParameterValues("8800611100");
		getParameterValues("8800069784");
		getParameterValues("8800578617");
		getParameterValues("8800380798");
		getParameterValues("8800181199");
		getParameterValues("8800587724");
		getParameterValues("8800581039");
		getParameterValues("8800306958");
		getParameterValues("8800331124");
		getParameterValues("8802030570");
		getParameterValues("8802282891");
		getParameterValues("8800246180");
		getParameterValues("8802280961");
		getParameterValues("8800337449");
		getParameterValues("8802290092");
		getParameterValues("8800367201");
		getParameterValues("8802284242");
		getParameterValues("8801665027");
		getParameterValues("8800224703");
		getParameterValues("8800471054");
		getParameterValues("8802292443");
		getParameterValues("8800853849");
		getParameterValues("8801671408");
		getParameterValues("8802279650");
		getParameterValues("8801086933");
		getParameterValues("8802309247");
		getParameterValues("8802299603");
		getParameterValues("8800359393");
		getParameterValues("8802303539");
		getParameterValues("8800677585");
		getParameterValues("8802301405");
		getParameterValues("8801185408");
		getParameterValues("8802314387");
		getParameterValues("8802294731");
		getParameterValues("8802315896");
		getParameterValues("8802016228");
		getParameterValues("8802311187");
		getParameterValues("8800489145");
		getParameterValues("8800712301");
		getParameterValues("8800563884");
		getParameterValues("8800656154");
		getParameterValues("8802302221");
		getParameterValues("8800884323");
		getParameterValues("8800631941");
		getParameterValues("8802294971");
		getParameterValues("8802291005");
		getParameterValues("8800454128");
		getParameterValues("8801258361");
		getParameterValues("8800517593");
		getParameterValues("8802308193");
		getParameterValues("8801947411");
		getParameterValues("8800908406");
		getParameterValues("8802292526");
		getParameterValues("8802303310");
		getParameterValues("8800270019");
		getParameterValues("8802293937");
		getParameterValues("8800887278");
		getParameterValues("8802290258");
		getParameterValues("8802334355");
		getParameterValues("8802320389");
		getParameterValues("8802283922");
		getParameterValues("8802317501");
		getParameterValues("8802327254");
		getParameterValues("8800162917");
		getParameterValues("8802331305");
		getParameterValues("8802320011");
		getParameterValues("8802321260");
		getParameterValues("8802332120");
		getParameterValues("8802342002");
		getParameterValues("8801652548");
		getParameterValues("8801046544");
		getParameterValues("8800773803");
		getParameterValues("8802318284");
		getParameterValues("8802334515");
		getParameterValues("8802346124");
		getParameterValues("8802321346");
		getParameterValues("8800227700");
		getParameterValues("8800617580");
		getParameterValues("8802253964");
		getParameterValues("8802289508");
		getParameterValues("8802294788");
		getParameterValues("8800856500");
		getParameterValues("8802325084");
		getParameterValues("8802330948");
		getParameterValues("8802318924");
		getParameterValues("8802314215");
		getParameterValues("8802315641");
		getParameterValues("8802316714");
		getParameterValues("8802326984");
		getParameterValues("8802343527");
		getParameterValues("8802328719");
		getParameterValues("8802339902");
		getParameterValues("8802324725");
		getParameterValues("8802362151");
		getParameterValues("8801739102");
		getParameterValues("8802356804");
		getParameterValues("8802372875");
		getParameterValues("8802550416");
		getParameterValues("8803346811");
		getParameterValues("8802629483");
		getParameterValues("8801606008");
		getParameterValues("8801212518");
		getParameterValues("8802706969");
		getParameterValues("8801395003");
		getParameterValues("8802820214");
		getParameterValues("8802806249");
		getParameterValues("8802872866");
		getParameterValues("8803490440");
		getParameterValues("8803496332");



		
	}

	public static void getParameterValues( String fid ) {
		ArrayList<ResponseDataKeyValue> getParameterValuesResponse = new ArrayList<ResponseDataKeyValue>();
		long start = System.currentTimeMillis();
		String resultx = fid;
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL("http://10.197.19.38:9094/axis2/services/Cpe112DiagnosisWebServices?wsdl"), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(500);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
//			if(requestMessage.getActivationId() != null) {
//				bindAccount = requestMessage.getActivationId();
//			}
//			if(requestMessage.getFibreId() != null) {
				bindAccount = "PPPoEUser="+fid;
//			}
			
			List<String> item_ = new ArrayList<>();
//			for (RequestItem i: requestMessage.getParamNameVec()) {
			item_.add("InternetGatewayDevice.DeviceInfo.SoftwareVersion");
			item_.add("InternetGatewayDevice.LANDevice.1.X-AIS_Mesh.DownloadURL");
			
//			}
			
			String[] item = item_.stream().toArray(String[]::new);
			
			GetParameterValuesRequestEntry baseRequestEntry = new GetParameterValuesRequestEntry(bindAccount, null, item);
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getParameterValues(baseRequestEntry);
			
			for (ResponseMapEntry res: responseMapEntry) {
				ResponseDataKeyValue responseDataKeyValue = new ResponseDataKeyValue();
				responseDataKeyValue.setKey(res.getKey());
				if(res.getKey().endsWith("SoftwareVersion")) {
					resultx += ",SoftwareVersion=" + res.getValue();
				} 
				if(res.getKey().endsWith("DownloadURL")) {
					resultx += ",DownloadURL=" + res.getValue();
				}
			}
			
			if(resultx.endsWith("V5R019C20S120")) {
				System.out.println(resultx + " | " +setParameterValues(fid));
			
			} else {
				System.out.println(resultx);
			}
			
			
			
//			System.out.print(resultx);
		}  catch( AxisFault axisFault) {

			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} 
		

	}
	
	
	public static String  setParameterValues( String fid ) {
		long start = System.currentTimeMillis();
		String result1;
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL("http://10.197.19.38:9094/axis2/services/Cpe112DiagnosisWebServices?wsdl"), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(500);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
//			if(requestMessage.getActivationId() != null) {
//				bindAccount = requestMessage.getActivationId();
//			}
//			if(requestMessage.getFibreId() != null) {
				bindAccount = "PPPoEUser="+fid;
//			}
		
			List<String> paramNames_ = new ArrayList<>();
			List<String> paramValue_ = new ArrayList<>();
			
				paramNames_.add("InternetGatewayDevice.LANDevice.1.X-AIS_Mesh.DownloadURL");
				paramValue_.add("");
				//               http://acs.ais.co.th:8084/webfs/download?filename=/versions/HG8245W5V500R020C10SPC151_365_1_unite4.4_all_pack.bin
			
			
			String[] paramNames = paramNames_.stream().toArray(String[]::new);
			String[] paramValue = paramValue_.stream().toArray(String[]::new);
			
			SetParameterValuesRequestEntry setParameterValuesRequestEntry = new SetParameterValuesRequestEntry();
			setParameterValuesRequestEntry.setParamNames(paramNames);
			setParameterValuesRequestEntry.setParamValues(paramValue);
			setParameterValuesRequestEntry.setBindAccount(bindAccount);
			int response = cpe112DiagnosisWebServicesPortType.setParameterValues(setParameterValuesRequestEntry);
			
			if(response == 0) {
				result1 = "ChangeURL_DownloadURL=SUCCESS";
			} else {
				result1 = "FAIL";
			}
			
		} catch( AxisFault axisFault) {
		
			result1 = "FAIL";
		
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result1 = "FAIL";
		} 
		
		return result1;
	}
	
}



