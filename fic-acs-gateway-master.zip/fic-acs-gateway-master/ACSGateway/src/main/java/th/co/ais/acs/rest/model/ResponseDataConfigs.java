package th.co.ais.acs.rest.model;

import java.util.ArrayList;
import java.util.Arrays;

public class ResponseDataConfigs {
	
	private String fileName = null;
	private String fileSize = null;
	private String time = null;
	private String backupType = null;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getBackupType() {
		return backupType;
	}
	public void setBackupType(String backupType) {
		this.backupType = backupType;
	}
	@Override
	public String toString() {
		return "ResponseDataConfigs [fileName=" + fileName + ", fileSize=" + fileSize + ", time=" + time
				+ ", backupType=" + backupType + "]";
	}
	
	
	
	
}
