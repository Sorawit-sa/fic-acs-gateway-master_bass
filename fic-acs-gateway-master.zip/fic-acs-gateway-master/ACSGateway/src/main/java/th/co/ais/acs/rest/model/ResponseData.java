package th.co.ais.acs.rest.model;

import java.util.ArrayList;
import java.util.Arrays;

public class ResponseData {
	
	private String role = null;
	private String expires_in = null;
	private String access_token = null;
	
	private String acsSystem = null;
	private String acsURL = null;
	
	private ResponseDataBasicInfo basicInfo = null;
	private ResponseDataAdvanceInfo advanceInfo = null;
	ArrayList<ResponseDataHostInfo> hostInfo = null;
	private String onlineStatus = null;
	
	ArrayList<ResponseDataWiFiInfo> wifiInfo = null;
	
	ArrayList<ResponseDataKeyValue> getParameterValuesResponse = null;
	
	ArrayList<ResponseDataKeyValue> uploadCFGInfo = null;
	ArrayList<ResponseDataKeyValue> CFGListInfo = null;
	ArrayList<ResponseDataConfigs> configs = null;
	private ResponseDataCFGList CFGList = null;
	
	private String deviceId = null;
	private String voipProfile = null;
	
	private String username = null;
	
	public boolean isEmpty() {
        return (this.role == null 
        		&& this.expires_in == null  
        		&& this.access_token == null  
        		&& this.acsSystem == null
        		&& this.acsURL == null
        		&& this.basicInfo == null
        		&& this.advanceInfo == null
        		&& this.hostInfo == null
        		&& this.onlineStatus == null
        		&& this.wifiInfo == null
        		&& this.getParameterValuesResponse == null
        		&& this.uploadCFGInfo == null
        		&& this.CFGListInfo == null
        		&& this.configs == null
        		&& this.CFGList == null
        		&& this.deviceId == null
        		&& this.voipProfile == null);
    }

	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getExpires_in() {
		return expires_in;
	}
	public void setExpires_in(String expires_in) {
		this.expires_in = expires_in;
	}
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public ArrayList<ResponseDataHostInfo> getHostInfo() {
		return hostInfo;
	}
	public void setHostInfo(ArrayList<ResponseDataHostInfo> hostInfo) {
		this.hostInfo = hostInfo;
	}
	public String getOnlineStatus() {
		return onlineStatus;
	}
	public void setOnlineStatus(String onlineStatus) {
		this.onlineStatus = onlineStatus;
	}
	public ResponseDataBasicInfo getBasicInfo() {
		return basicInfo;
	}
	public void setBasicInfo(ResponseDataBasicInfo basicInfo) {
		this.basicInfo = basicInfo;
	}
	public ResponseDataAdvanceInfo getAdvanceInfo() {
		return advanceInfo;
	}
	public void setAdvanceInfo(ResponseDataAdvanceInfo advanceInfo) {
		this.advanceInfo = advanceInfo;
	}
	public String getAcsSystem() {
		return acsSystem;
	}
	public void setAcsSystem(String acsSystem) {
		this.acsSystem = acsSystem;
	}
	public String getAcsURL() {
		return acsURL;
	}
	public void setAcsURL(String acsURL) {
		this.acsURL = acsURL;
	}
	public ArrayList<ResponseDataKeyValue> getUploadCFGInfo() {
		return uploadCFGInfo;
	}
	public void setUploadCFGInfo(ArrayList<ResponseDataKeyValue> uploadCFGInfo) {
		this.uploadCFGInfo = uploadCFGInfo;
	}
	public ArrayList<ResponseDataKeyValue> getCFGListInfo() {
		return CFGListInfo;
	}
	public void setCFGListInfo(ArrayList<ResponseDataKeyValue> CFGListInfo) {
		this.CFGListInfo = CFGListInfo;
	}
	public ResponseDataCFGList getCFGList() {
		return CFGList;
	}
	public void setCFGList(ResponseDataCFGList CFGList) {
		this.CFGList = CFGList;
	}
	public ArrayList<ResponseDataWiFiInfo> getWiFiInfo() {
		return wifiInfo;
	}
	public void setWiFiInfo(ArrayList<ResponseDataWiFiInfo> wiFiInfo) {
		wifiInfo = wiFiInfo;
	}
	public ArrayList<ResponseDataKeyValue> getGetParameterValuesResponse() {
		return getParameterValuesResponse;
	}
	public void setGetParameterValuesResponse(ArrayList<ResponseDataKeyValue> getParameterValuesResponse) {
		this.getParameterValuesResponse = getParameterValuesResponse;
	}
	@Override
	public String toString() {
		return "ResponseData [" + (role != null ? "role=" + role + ", " : "")
				+ (deviceId != null ? "deviceId=" + deviceId + ", " : "")
				+ (voipProfile != null ? "voipProfile=" + voipProfile + ", " : "")
				+ (expires_in != null ? "expires_in=" + expires_in + ", " : "")
				+ (access_token != null ? "access_token=" + access_token + ", " : "")
				+ (acsSystem != null ? "acsSystem=" + acsSystem + ", " : "")
				+ (acsURL != null ? "acsURL=" + acsURL + ", " : "")
				+ (basicInfo != null ? "basicInfo=" + basicInfo + ", " : "")
				+ (advanceInfo != null ? "advanceInfo=" + advanceInfo + ", " : "")
				+ (hostInfo != null ? "hostInfo=" + Arrays.toString(hostInfo.toArray())  + ", " : "")
				+ (onlineStatus != null ? "onlineStatus=" + onlineStatus + ", " : "")
				+ (wifiInfo != null ? "WiFiInfo=" + Arrays.toString(wifiInfo.toArray()) + ", " : "")
				+ (getParameterValuesResponse != null
						? "getParameterValuesResponse=" + Arrays.toString(getParameterValuesResponse.toArray()) + ", "
						: "")
				+ (uploadCFGInfo != null ? "uploadCFGInfo=" + Arrays.toString(uploadCFGInfo.toArray()) + ", " : "")
				+ (uploadCFGInfo != null ? "configs=" + Arrays.toString(configs.toArray()) + ", " : "")
				+ (CFGListInfo != null ? "CFGListInfo=" + Arrays.toString(CFGListInfo.toArray()) + ", " : "")
				+ (CFGList != null ? "CFGList=" + CFGList : "") + "]";
	}

	public ArrayList<ResponseDataConfigs> getConfigs() {
		return configs;
	}

	public void setConfigs(ArrayList<ResponseDataConfigs> configs) {
		this.configs = configs;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getVoipProfile() {
		return voipProfile;
	}

	public void setVoipProfile(String voipProfile) {
		this.voipProfile = voipProfile;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}
