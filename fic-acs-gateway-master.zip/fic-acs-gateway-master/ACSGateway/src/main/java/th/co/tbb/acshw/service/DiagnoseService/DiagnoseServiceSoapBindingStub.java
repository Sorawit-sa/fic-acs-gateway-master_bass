/**
 * DiagnoseServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.service.DiagnoseService;

public class DiagnoseServiceSoapBindingStub extends org.apache.axis.client.Stub implements th.co.tbb.acshw.service.DiagnoseService.DiagnoseService {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[16];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeOnlineInfoForDsl");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "getCpeOnlineRst"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.GetCpeOnlineRst.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getCpeOnlineInfoForDslReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "interfaceType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "CpeInfoRst"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.CpeInfoRst.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getCpeInfoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("startPing");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "ping"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "pingInfo"), th.co.tbb.acshw.model.DiagnoseService.PingInfo.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "startPingReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("diagnoseTest");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "procName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "paraList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "ArrayOf_tns1_Para"), th.co.tbb.acshw.model.DiagnoseService.Para[].class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "diagnoseTestReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("cpeReboot");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "cpeRebootReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getPingResult");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "pingResult"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.PingResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getPingResultReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("resetService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "resetServiceReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeParameterByNodePath");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "nodePath"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "GetParameterResult"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.GetParameterResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getCpeParameterByNodePathReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeParameterByNodeName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "parameterNames"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "ArrayOf_soapenc_string"), java.lang.String[].class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "GetParameterResult"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.GetParameterResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getCpeParameterByNodeNameReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCpeOnlineInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "CpeOnlineInfo"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.CpeOnlineInfo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getCpeOnlineInfoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("cpeFactoryReset");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "type"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "cpeFactoryResetReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getVoipPwdInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "strInput"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "strEncryptInput"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "VoipPwdInfo"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.VoipPwdInfo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getVoipPwdInfoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setCpeParameterValues");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "parameterValues"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "ArrayOf_tns1_ParaWithType"), th.co.tbb.acshw.model.DiagnoseService.ParaWithType[].class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "SetParameterResult"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.SetParameterResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "setCpeParameterValuesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getDiagnoseResult");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "procName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "DiagnoseResult"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.DiagnoseResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getDiagnoseResultReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("startCPEMission");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "fileName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "iOperType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "CPEMission"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.CPEMission.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "startCPEMissionReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCPEMissionResult");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "iMissionID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("DiagnoseService", "UserIndex"), th.co.tbb.acshw.model.DiagnoseService.UserIndex.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("DiagnoseService", "CPEMissionResult"));
        oper.setReturnClass(th.co.tbb.acshw.model.DiagnoseService.CPEMissionResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getCPEMissionResultReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[15] = oper;

    }

    public DiagnoseServiceSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public DiagnoseServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public DiagnoseServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("DiagnoseService", "CpeBasicInfo");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.CpeBasicInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "CpeInfo");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.CpeInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "CpeInfoRst");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.CpeInfoRst.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "CPEMission");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.CPEMission.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "CPEMissionResult");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.CPEMissionResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "CpeOnlineInfo");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.CpeOnlineInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "DiagnoseResult");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.DiagnoseResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "getCpeOnlineRst");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.GetCpeOnlineRst.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "GetParameterResult");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.GetParameterResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "Para");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.Para.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "ParaWithType");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.ParaWithType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "pingInfo");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.PingInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "pingResult");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.PingResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "result");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.Result.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "ServiceInfo");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.ServiceInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "SetParameterResult");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.SetParameterResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "UserIndex");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.UserIndex.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "UserInfo");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.UserInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("DiagnoseService", "VoipPwdInfo");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.VoipPwdInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "ArrayOf_soapenc_string");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "ArrayOf_tns1_Para");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.Para[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("DiagnoseService", "Para");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "ArrayOf_tns1_ParaWithType");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.ParaWithType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("DiagnoseService", "ParaWithType");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "ArrayOf_tns1_ServiceInfo");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.DiagnoseService.ServiceInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("DiagnoseService", "ServiceInfo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://model.base.huawei.com", "ParameterResultBase");
            cachedSerQNames.add(qName);
            cls = th.co.tbb.acshw.model.ParameterResultBase.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
                    _call.setEncodingStyle(org.apache.axis.Constants.URI_SOAP11_ENC);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public th.co.tbb.acshw.model.DiagnoseService.GetCpeOnlineRst getCpeOnlineInfoForDsl(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getCpeOnlineInfoForDsl"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.GetCpeOnlineRst) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.GetCpeOnlineRst) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.GetCpeOnlineRst.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.CpeInfoRst getCpeInfo(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String interfaceType) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getCpeInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, interfaceType});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.CpeInfoRst) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.CpeInfoRst) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.CpeInfoRst.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public int startPing(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, th.co.tbb.acshw.model.DiagnoseService.PingInfo ping) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "startPing"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, ping});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public int diagnoseTest(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String procName, th.co.tbb.acshw.model.DiagnoseService.Para[] paraList) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "diagnoseTest"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, procName, paraList});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public int cpeReboot(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "cpeReboot"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.PingResult getPingResult(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getPingResult"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.PingResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.PingResult) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.PingResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public int resetService(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "resetService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.GetParameterResult getCpeParameterByNodePath(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String nodePath) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getCpeParameterByNodePath"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, nodePath});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.GetParameterResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.GetParameterResult) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.GetParameterResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.GetParameterResult getCpeParameterByNodeName(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String[] parameterNames) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getCpeParameterByNodeName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, parameterNames});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.GetParameterResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.GetParameterResult) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.GetParameterResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.CpeOnlineInfo getCpeOnlineInfo(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getCpeOnlineInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.CpeOnlineInfo) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.CpeOnlineInfo) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.CpeOnlineInfo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public int cpeFactoryReset(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, int type) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "cpeFactoryReset"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, new java.lang.Integer(type)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.VoipPwdInfo getVoipPwdInfo(java.lang.String strInput, java.lang.String strEncryptInput) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getVoipPwdInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {strInput, strEncryptInput});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.VoipPwdInfo) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.VoipPwdInfo) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.VoipPwdInfo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.SetParameterResult setCpeParameterValues(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, th.co.tbb.acshw.model.DiagnoseService.ParaWithType[] parameterValues) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "setCpeParameterValues"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, parameterValues});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.SetParameterResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.SetParameterResult) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.SetParameterResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.DiagnoseResult getDiagnoseResult(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String procName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getDiagnoseResult"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, procName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.DiagnoseResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.DiagnoseResult) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.DiagnoseResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.CPEMission startCPEMission(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String fileName, int iOperType) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "startCPEMission"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user, fileName, new java.lang.Integer(iOperType)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.CPEMission) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.CPEMission) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.CPEMission.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public th.co.tbb.acshw.model.DiagnoseService.CPEMissionResult getCPEMissionResult(int iMissionID, th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://service.operation.northinterface.huawei.com", "getCPEMissionResult"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(iMissionID), user});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (th.co.tbb.acshw.model.DiagnoseService.CPEMissionResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (th.co.tbb.acshw.model.DiagnoseService.CPEMissionResult) org.apache.axis.utils.JavaUtils.convert(_resp, th.co.tbb.acshw.model.DiagnoseService.CPEMissionResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
