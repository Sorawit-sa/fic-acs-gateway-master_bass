/**
 * DelCpeInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.OperationDistributeService;

public class DelCpeInfo  implements java.io.Serializable {
    private java.lang.String SIM;

    private java.lang.String antennaNum;

    private java.lang.String cpeClass;

    private java.lang.String[] cpeList;

    private java.lang.String etherNum;

    private java.lang.String etherSpeed;

    private java.lang.String hsrdware;

    private java.lang.String manageProtocol;

    private java.lang.String oui;

    private java.lang.String software;

    private java.lang.String ssidNum;

    private java.lang.String type;

    private java.lang.String ver;

    private java.lang.String voipNum;

    private java.lang.String voipProtocol;

    private java.lang.String wanType;

    private java.lang.String wirelessStandard;

    private java.lang.String wirelessThruput;

    private java.lang.String wirelessType;

    public DelCpeInfo() {
    }

    public DelCpeInfo(
           java.lang.String SIM,
           java.lang.String antennaNum,
           java.lang.String cpeClass,
           java.lang.String[] cpeList,
           java.lang.String etherNum,
           java.lang.String etherSpeed,
           java.lang.String hsrdware,
           java.lang.String manageProtocol,
           java.lang.String oui,
           java.lang.String software,
           java.lang.String ssidNum,
           java.lang.String type,
           java.lang.String ver,
           java.lang.String voipNum,
           java.lang.String voipProtocol,
           java.lang.String wanType,
           java.lang.String wirelessStandard,
           java.lang.String wirelessThruput,
           java.lang.String wirelessType) {
           this.SIM = SIM;
           this.antennaNum = antennaNum;
           this.cpeClass = cpeClass;
           this.cpeList = cpeList;
           this.etherNum = etherNum;
           this.etherSpeed = etherSpeed;
           this.hsrdware = hsrdware;
           this.manageProtocol = manageProtocol;
           this.oui = oui;
           this.software = software;
           this.ssidNum = ssidNum;
           this.type = type;
           this.ver = ver;
           this.voipNum = voipNum;
           this.voipProtocol = voipProtocol;
           this.wanType = wanType;
           this.wirelessStandard = wirelessStandard;
           this.wirelessThruput = wirelessThruput;
           this.wirelessType = wirelessType;
    }


    /**
     * Gets the SIM value for this DelCpeInfo.
     * 
     * @return SIM
     */
    public java.lang.String getSIM() {
        return SIM;
    }


    /**
     * Sets the SIM value for this DelCpeInfo.
     * 
     * @param SIM
     */
    public void setSIM(java.lang.String SIM) {
        this.SIM = SIM;
    }


    /**
     * Gets the antennaNum value for this DelCpeInfo.
     * 
     * @return antennaNum
     */
    public java.lang.String getAntennaNum() {
        return antennaNum;
    }


    /**
     * Sets the antennaNum value for this DelCpeInfo.
     * 
     * @param antennaNum
     */
    public void setAntennaNum(java.lang.String antennaNum) {
        this.antennaNum = antennaNum;
    }


    /**
     * Gets the cpeClass value for this DelCpeInfo.
     * 
     * @return cpeClass
     */
    public java.lang.String getCpeClass() {
        return cpeClass;
    }


    /**
     * Sets the cpeClass value for this DelCpeInfo.
     * 
     * @param cpeClass
     */
    public void setCpeClass(java.lang.String cpeClass) {
        this.cpeClass = cpeClass;
    }


    /**
     * Gets the cpeList value for this DelCpeInfo.
     * 
     * @return cpeList
     */
    public java.lang.String[] getCpeList() {
        return cpeList;
    }


    /**
     * Sets the cpeList value for this DelCpeInfo.
     * 
     * @param cpeList
     */
    public void setCpeList(java.lang.String[] cpeList) {
        this.cpeList = cpeList;
    }


    /**
     * Gets the etherNum value for this DelCpeInfo.
     * 
     * @return etherNum
     */
    public java.lang.String getEtherNum() {
        return etherNum;
    }


    /**
     * Sets the etherNum value for this DelCpeInfo.
     * 
     * @param etherNum
     */
    public void setEtherNum(java.lang.String etherNum) {
        this.etherNum = etherNum;
    }


    /**
     * Gets the etherSpeed value for this DelCpeInfo.
     * 
     * @return etherSpeed
     */
    public java.lang.String getEtherSpeed() {
        return etherSpeed;
    }


    /**
     * Sets the etherSpeed value for this DelCpeInfo.
     * 
     * @param etherSpeed
     */
    public void setEtherSpeed(java.lang.String etherSpeed) {
        this.etherSpeed = etherSpeed;
    }


    /**
     * Gets the hsrdware value for this DelCpeInfo.
     * 
     * @return hsrdware
     */
    public java.lang.String getHsrdware() {
        return hsrdware;
    }


    /**
     * Sets the hsrdware value for this DelCpeInfo.
     * 
     * @param hsrdware
     */
    public void setHsrdware(java.lang.String hsrdware) {
        this.hsrdware = hsrdware;
    }


    /**
     * Gets the manageProtocol value for this DelCpeInfo.
     * 
     * @return manageProtocol
     */
    public java.lang.String getManageProtocol() {
        return manageProtocol;
    }


    /**
     * Sets the manageProtocol value for this DelCpeInfo.
     * 
     * @param manageProtocol
     */
    public void setManageProtocol(java.lang.String manageProtocol) {
        this.manageProtocol = manageProtocol;
    }


    /**
     * Gets the oui value for this DelCpeInfo.
     * 
     * @return oui
     */
    public java.lang.String getOui() {
        return oui;
    }


    /**
     * Sets the oui value for this DelCpeInfo.
     * 
     * @param oui
     */
    public void setOui(java.lang.String oui) {
        this.oui = oui;
    }


    /**
     * Gets the software value for this DelCpeInfo.
     * 
     * @return software
     */
    public java.lang.String getSoftware() {
        return software;
    }


    /**
     * Sets the software value for this DelCpeInfo.
     * 
     * @param software
     */
    public void setSoftware(java.lang.String software) {
        this.software = software;
    }


    /**
     * Gets the ssidNum value for this DelCpeInfo.
     * 
     * @return ssidNum
     */
    public java.lang.String getSsidNum() {
        return ssidNum;
    }


    /**
     * Sets the ssidNum value for this DelCpeInfo.
     * 
     * @param ssidNum
     */
    public void setSsidNum(java.lang.String ssidNum) {
        this.ssidNum = ssidNum;
    }


    /**
     * Gets the type value for this DelCpeInfo.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this DelCpeInfo.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }


    /**
     * Gets the ver value for this DelCpeInfo.
     * 
     * @return ver
     */
    public java.lang.String getVer() {
        return ver;
    }


    /**
     * Sets the ver value for this DelCpeInfo.
     * 
     * @param ver
     */
    public void setVer(java.lang.String ver) {
        this.ver = ver;
    }


    /**
     * Gets the voipNum value for this DelCpeInfo.
     * 
     * @return voipNum
     */
    public java.lang.String getVoipNum() {
        return voipNum;
    }


    /**
     * Sets the voipNum value for this DelCpeInfo.
     * 
     * @param voipNum
     */
    public void setVoipNum(java.lang.String voipNum) {
        this.voipNum = voipNum;
    }


    /**
     * Gets the voipProtocol value for this DelCpeInfo.
     * 
     * @return voipProtocol
     */
    public java.lang.String getVoipProtocol() {
        return voipProtocol;
    }


    /**
     * Sets the voipProtocol value for this DelCpeInfo.
     * 
     * @param voipProtocol
     */
    public void setVoipProtocol(java.lang.String voipProtocol) {
        this.voipProtocol = voipProtocol;
    }


    /**
     * Gets the wanType value for this DelCpeInfo.
     * 
     * @return wanType
     */
    public java.lang.String getWanType() {
        return wanType;
    }


    /**
     * Sets the wanType value for this DelCpeInfo.
     * 
     * @param wanType
     */
    public void setWanType(java.lang.String wanType) {
        this.wanType = wanType;
    }


    /**
     * Gets the wirelessStandard value for this DelCpeInfo.
     * 
     * @return wirelessStandard
     */
    public java.lang.String getWirelessStandard() {
        return wirelessStandard;
    }


    /**
     * Sets the wirelessStandard value for this DelCpeInfo.
     * 
     * @param wirelessStandard
     */
    public void setWirelessStandard(java.lang.String wirelessStandard) {
        this.wirelessStandard = wirelessStandard;
    }


    /**
     * Gets the wirelessThruput value for this DelCpeInfo.
     * 
     * @return wirelessThruput
     */
    public java.lang.String getWirelessThruput() {
        return wirelessThruput;
    }


    /**
     * Sets the wirelessThruput value for this DelCpeInfo.
     * 
     * @param wirelessThruput
     */
    public void setWirelessThruput(java.lang.String wirelessThruput) {
        this.wirelessThruput = wirelessThruput;
    }


    /**
     * Gets the wirelessType value for this DelCpeInfo.
     * 
     * @return wirelessType
     */
    public java.lang.String getWirelessType() {
        return wirelessType;
    }


    /**
     * Sets the wirelessType value for this DelCpeInfo.
     * 
     * @param wirelessType
     */
    public void setWirelessType(java.lang.String wirelessType) {
        this.wirelessType = wirelessType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DelCpeInfo)) return false;
        DelCpeInfo other = (DelCpeInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.SIM==null && other.getSIM()==null) || 
             (this.SIM!=null &&
              this.SIM.equals(other.getSIM()))) &&
            ((this.antennaNum==null && other.getAntennaNum()==null) || 
             (this.antennaNum!=null &&
              this.antennaNum.equals(other.getAntennaNum()))) &&
            ((this.cpeClass==null && other.getCpeClass()==null) || 
             (this.cpeClass!=null &&
              this.cpeClass.equals(other.getCpeClass()))) &&
            ((this.cpeList==null && other.getCpeList()==null) || 
             (this.cpeList!=null &&
              java.util.Arrays.equals(this.cpeList, other.getCpeList()))) &&
            ((this.etherNum==null && other.getEtherNum()==null) || 
             (this.etherNum!=null &&
              this.etherNum.equals(other.getEtherNum()))) &&
            ((this.etherSpeed==null && other.getEtherSpeed()==null) || 
             (this.etherSpeed!=null &&
              this.etherSpeed.equals(other.getEtherSpeed()))) &&
            ((this.hsrdware==null && other.getHsrdware()==null) || 
             (this.hsrdware!=null &&
              this.hsrdware.equals(other.getHsrdware()))) &&
            ((this.manageProtocol==null && other.getManageProtocol()==null) || 
             (this.manageProtocol!=null &&
              this.manageProtocol.equals(other.getManageProtocol()))) &&
            ((this.oui==null && other.getOui()==null) || 
             (this.oui!=null &&
              this.oui.equals(other.getOui()))) &&
            ((this.software==null && other.getSoftware()==null) || 
             (this.software!=null &&
              this.software.equals(other.getSoftware()))) &&
            ((this.ssidNum==null && other.getSsidNum()==null) || 
             (this.ssidNum!=null &&
              this.ssidNum.equals(other.getSsidNum()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.ver==null && other.getVer()==null) || 
             (this.ver!=null &&
              this.ver.equals(other.getVer()))) &&
            ((this.voipNum==null && other.getVoipNum()==null) || 
             (this.voipNum!=null &&
              this.voipNum.equals(other.getVoipNum()))) &&
            ((this.voipProtocol==null && other.getVoipProtocol()==null) || 
             (this.voipProtocol!=null &&
              this.voipProtocol.equals(other.getVoipProtocol()))) &&
            ((this.wanType==null && other.getWanType()==null) || 
             (this.wanType!=null &&
              this.wanType.equals(other.getWanType()))) &&
            ((this.wirelessStandard==null && other.getWirelessStandard()==null) || 
             (this.wirelessStandard!=null &&
              this.wirelessStandard.equals(other.getWirelessStandard()))) &&
            ((this.wirelessThruput==null && other.getWirelessThruput()==null) || 
             (this.wirelessThruput!=null &&
              this.wirelessThruput.equals(other.getWirelessThruput()))) &&
            ((this.wirelessType==null && other.getWirelessType()==null) || 
             (this.wirelessType!=null &&
              this.wirelessType.equals(other.getWirelessType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSIM() != null) {
            _hashCode += getSIM().hashCode();
        }
        if (getAntennaNum() != null) {
            _hashCode += getAntennaNum().hashCode();
        }
        if (getCpeClass() != null) {
            _hashCode += getCpeClass().hashCode();
        }
        if (getCpeList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCpeList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCpeList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEtherNum() != null) {
            _hashCode += getEtherNum().hashCode();
        }
        if (getEtherSpeed() != null) {
            _hashCode += getEtherSpeed().hashCode();
        }
        if (getHsrdware() != null) {
            _hashCode += getHsrdware().hashCode();
        }
        if (getManageProtocol() != null) {
            _hashCode += getManageProtocol().hashCode();
        }
        if (getOui() != null) {
            _hashCode += getOui().hashCode();
        }
        if (getSoftware() != null) {
            _hashCode += getSoftware().hashCode();
        }
        if (getSsidNum() != null) {
            _hashCode += getSsidNum().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getVer() != null) {
            _hashCode += getVer().hashCode();
        }
        if (getVoipNum() != null) {
            _hashCode += getVoipNum().hashCode();
        }
        if (getVoipProtocol() != null) {
            _hashCode += getVoipProtocol().hashCode();
        }
        if (getWanType() != null) {
            _hashCode += getWanType().hashCode();
        }
        if (getWirelessStandard() != null) {
            _hashCode += getWirelessStandard().hashCode();
        }
        if (getWirelessThruput() != null) {
            _hashCode += getWirelessThruput().hashCode();
        }
        if (getWirelessType() != null) {
            _hashCode += getWirelessType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DelCpeInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("OperationDistributeService", "DelCpeInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SIM");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SIM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("antennaNum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "antennaNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpeClass");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpeClass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpeList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpeList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("etherNum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "etherNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("etherSpeed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "etherSpeed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hsrdware");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hsrdware"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manageProtocol");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manageProtocol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oui");
        elemField.setXmlName(new javax.xml.namespace.QName("", "oui"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("software");
        elemField.setXmlName(new javax.xml.namespace.QName("", "software"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ssidNum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ssidNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ver");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ver"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voipNum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "voipNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voipProtocol");
        elemField.setXmlName(new javax.xml.namespace.QName("", "voipProtocol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wanType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wanType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wirelessStandard");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wirelessStandard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wirelessThruput");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wirelessThruput"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wirelessType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wirelessType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
