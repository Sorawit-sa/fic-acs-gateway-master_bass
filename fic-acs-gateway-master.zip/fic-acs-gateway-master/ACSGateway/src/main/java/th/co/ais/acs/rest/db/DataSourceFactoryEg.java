/**
 * @project Fixed Broadband Radius Provisioning
 * 
 * @author FBCO
 * @copyright Copyright (C) 2014 FBCO
 * @email fc-fbco@ais.co.th
 * @version $Revision: 1.0.0 $Date: Sep 08, 2014
 */
package th.co.ais.acs.rest.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.log.LogInfo;

public class DataSourceFactoryEg {
	
	//private static final Logger logger = LoggerFactory.getLogger( DataSourceFactory.class );
	
	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	private static final LogInfo LOGGER_INFO = new LogInfo();
	
	private String dsEnv = "jdbc/EG";
	Connection conn = null;
	
	Context initContext = null;
	Context envContext = null;
	DataSource ds = null;
	
	public DataSourceFactoryEg() {

		try {
			initContext = new InitialContext();
			envContext = (Context) initContext.lookup("java:comp/env");
			ds = (DataSource) envContext.lookup(this.dsEnv);
		
			conn = ds.getConnection();					
			
			LOGGER_DEBUG.log(" - Inittial DB Connection Complete: " + conn.hashCode());
			
		} catch (NamingException e) {
			LOGGER_DEBUG.log("NameingException : " + e);
		} catch (SQLException e) {
			LOGGER_DEBUG.log("SQLException: " + e);
		}
	}

	public void setDataSource(String ds) {
		this.dsEnv = ds;
	}

	public Connection getJNDIConnection() {
		if (conn == null) {
			conn = getConnection();
		}
		return conn;
	}

	public synchronized Connection getConnection() {
		try {
			conn = ds.getConnection();
			conn.setAutoCommit(true);
//			LOGGER_DEBUG.log("Get Connection Pool: " + conn.hashCode());
			
		} catch (SQLException e) {
			//e.printStackTrace();
			LOGGER_DEBUG.log("SQLException: " + e);
		}

		return conn;
	}
} 