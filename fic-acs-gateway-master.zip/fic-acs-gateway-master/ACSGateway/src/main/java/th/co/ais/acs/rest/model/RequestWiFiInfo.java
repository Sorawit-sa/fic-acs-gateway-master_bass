package th.co.ais.acs.rest.model;

public class RequestWiFiInfo {

	private String index = null;
	private String ssid = null;
	private String channel = null;
	private String enable = null;
	private String autoChannelEnable = null;
	private String key = null;
	
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getSsid() {
		return ssid;
	}
	public void setSsid(String ssid) {
		this.ssid = ssid;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getEnable() {
		return enable;
	}
	public void setEnable(String enable) {
		this.enable = enable;
	}
	public String getAutoChannelEnable() {
		return autoChannelEnable;
	}
	public void setAutoChannelEnable(String autoChannelEnable) {
		this.autoChannelEnable = autoChannelEnable;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	@Override
	public String toString() {
		return "RequestWiFiInfo [index=" + index + ", ssid=" + ssid + ", channel=" + channel + ", enable=" + enable
				+ ", autoChannelEnable=" + autoChannelEnable + ", key=" + key + "]";
	}

	
}
