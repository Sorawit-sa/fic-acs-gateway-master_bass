/**
 * @project Fixed Broadband SMPP Services
 * 
 * @author FCPO
 * @copyright Copyright (C) 2017 FCPO
 * @email fc-fcnpo@ais.co.th
 * @version $Revision: 1.0.0 $Date: Feb 09, 2017
 */
package th.co.ais.acs.rest.init;

import java.io.File;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import th.co.ais.acs.rest.dao.AcsService;
import th.co.ais.acs.rest.db.DBEgOperation;
import th.co.ais.acs.rest.db.DBFibreOperation;
import th.co.ais.acs.rest.db.DBStreamOperation;
import th.co.ais.acs.rest.db.DataSourceFactoryEg;
import th.co.ais.acs.rest.db.DataSourceFactoryFibre;
import th.co.ais.acs.rest.db.DataSourceFactoryStream;
import th.co.ais.acs.rest.impl.EgOperation;
import th.co.ais.acs.rest.impl.AvsOperation;
import th.co.ais.acs.rest.impl.HwOperation;
import th.co.ais.acs.rest.impl.KiddoOperation;
import th.co.ais.acs.rest.impl.EgServiceImpl;
import th.co.ais.acs.rest.impl.AvsServiceImpl;
import th.co.ais.acs.rest.impl.HwServiceImpl;
import th.co.ais.acs.rest.impl.KiddoServiceImpl;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.log.LogEG;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InitialParameter extends HttpServlet {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(InitialParameter.class);
	private static LogDebug LOGGER_DEBUG = new LogDebug();	
	private static LogEG Log_EG = new LogEG();	
	
	public static DataSourceFactoryFibre dataSourceFactoryFibre = null;
	public static DataSourceFactoryStream dataSourceFactoryStream = null;
	public static DataSourceFactoryEg dataSourceFactoryEg = null;
	
	public static DBStreamOperation dbStreamOperation = null;
	public static DBFibreOperation dbFibreOperation = null;
	public static DBEgOperation dbEgOperation = null;
	
	public static AcsService egServiceDao = null;
	public static AcsService avsServiceDao = null;
	public static AcsService hwServiceDao = null;
	public static AcsService kiddoServiceDao = null;
	public static EgOperation egOperation = null;
	public static AvsOperation avsOperation = null;
	public static HwOperation hwOperation = null;
	public static KiddoOperation kiddoOperation = null;
	
	public static String url_cpediagnosis112_avs = null;
	public static String url_cpediagnosis_avs = null;
	public static String url_binding_avs = null;
	public static String url_ump_avs = null;
	public static String username_avs = null;
	public static String password_avs = null;
	public static String username_ump_avs = null;
	public static String password_ump_avs = null;
	public static String url_cpediagnosis112_eg = null;
	public static String url_cpediagnosis_eg = null;
	public static String url_binding_eg = null;
	public static String url_worklist_eg = null;
	public static String url_kiddo = null;
	
	public static int connection_timeout = 2000;
			
	public static int MODE = 1;
	public static final String ACS_API = "ACSGateway";
	
	
    @Override
    public void init(ServletConfig config) throws ServletException {
    	
    	ServletContext context = config.getServletContext();
		String logConfig = context.getRealPath( "/WEB-INF/etc/log4j2.xml" );
		
		LoggerContext contextLog = (LoggerContext) LogManager.getContext(false);
		File file = new File(logConfig);
		contextLog.setConfigLocation(file.toURI());
		logger.debug("ACSGateway");
		Log_EG.log("ACSGateway");
		LOGGER_DEBUG.log("");
		LOGGER_DEBUG.log("#--- ACSGateway Web Service V1.0.0 Initializing ---#");			
		
		//<!-- production = 0, staging = 1-->		
		MODE = Integer.valueOf(context.getInitParameter("deployed.mode"));		
		if( MODE == 1 ) {
			url_cpediagnosis112_avs	  = context.getInitParameter("url.cpediagnosis112.avs.staging");
			url_cpediagnosis_avs      = context.getInitParameter("url.cpediagnosis.avs.staging");
			url_binding_avs           = context.getInitParameter("url.binding.avs.staging");
			username_avs              = context.getInitParameter("username.avs.staging");
			password_avs              = context.getInitParameter("password.avs.staging");
			url_cpediagnosis112_eg    = context.getInitParameter("url.cpediagnosis112.eg.staging");
			url_cpediagnosis_eg       = context.getInitParameter("url.cpediagnosis.eg.staging");
			url_binding_eg            = context.getInitParameter("url.binding.eg.staging");
			url_worklist_eg            = context.getInitParameter("url.worklist.eg.staging");
			
			url_ump_avs 		      = context.getInitParameter("url.ump.avs.staging");
			username_ump_avs 		  = context.getInitParameter("username.ump.avs.staging");
			password_ump_avs 		  = context.getInitParameter("password.ump.avs.staging");

			url_kiddo 				  = context.getInitParameter("url.kiddo.prod");
			
			dataSourceFactoryEg = new DataSourceFactoryEg();
			
		} else {
			url_cpediagnosis112_avs	  = context.getInitParameter("url.cpediagnosis112.avs.prod");
			url_cpediagnosis_avs      = context.getInitParameter("url.cpediagnosis.avs.prod");
			url_binding_avs           = context.getInitParameter("url.binding.avs.prod");
			username_avs              = context.getInitParameter("username.avs.prod");
			password_avs              = context.getInitParameter("password.avs.prod");
			url_cpediagnosis112_eg    = context.getInitParameter("url.cpediagnosis112.eg.prod");
			url_cpediagnosis_eg       = context.getInitParameter("url.cpediagnosis.eg.prod");
			url_binding_eg            = context.getInitParameter("url.binding.eg.prod");
			url_worklist_eg            = context.getInitParameter("url.worklist.eg.prod");
			
			url_ump_avs 		  = context.getInitParameter("url.ump.avs.prod");
			username_ump_avs 		  = context.getInitParameter("username.ump.avs.prod");
			password_ump_avs 		  = context.getInitParameter("password.ump.avs.prod");

			url_kiddo 				  = context.getInitParameter("url.kiddo.prod");
			
		}

		// Connection Timeout
		connection_timeout = Integer.valueOf(context.getInitParameter("connection.timeout"));	
		
		// Initial Database Connection Pool
		dataSourceFactoryFibre = new DataSourceFactoryFibre();
		dataSourceFactoryStream = new DataSourceFactoryStream();
		
		// Initial Database Operation
		dbStreamOperation = new DBStreamOperation();
		dbFibreOperation = new DBFibreOperation();
		dbEgOperation = new DBEgOperation();
		
		// Initial acs operation
		egOperation = new EgOperation();
		avsOperation = new AvsOperation();
		hwOperation = new HwOperation();
		kiddoOperation = new KiddoOperation();
				
		// Initial Service Impl
		egServiceDao = new EgServiceImpl();
		avsServiceDao = new AvsServiceImpl();
		hwServiceDao = new HwServiceImpl();
		kiddoServiceDao = new KiddoServiceImpl();
		
		LOGGER_DEBUG.log(" MODE = " + MODE);
		LOGGER_DEBUG.log(" url_cpediagnosis112_avs = " + url_cpediagnosis112_avs);
		LOGGER_DEBUG.log(" url_cpediagnosis_avs = " + url_cpediagnosis_avs);
		LOGGER_DEBUG.log(" url_binding_avs = " + url_binding_avs);
		LOGGER_DEBUG.log(" username_avs = " + username_avs);
		LOGGER_DEBUG.log(" password_avs = " + password_avs);
		LOGGER_DEBUG.log(" url_cpediagnosis112_eg = " + url_cpediagnosis112_eg);
		LOGGER_DEBUG.log(" url_cpediagnosis_eg = " + url_binding_eg);
		LOGGER_DEBUG.log(" url_ump_avs = " + url_ump_avs);
		LOGGER_DEBUG.log(" username_ump_avs = " + username_ump_avs);
		LOGGER_DEBUG.log(" password_ump_avs = " + password_ump_avs);
		
		if(dataSourceFactoryFibre != null && dbFibreOperation != null) {
			LOGGER_DEBUG.log("   (1/3)... init dataSourceFactoryFibre() completed");
			LOGGER_DEBUG.log("   (1/3)... init dbFibreOperation() completed");
		}
			
		if(dataSourceFactoryStream != null && dbStreamOperation != null) {
			LOGGER_DEBUG.log("   (2/3)... init dataSourceFactoryStream() completed");
			LOGGER_DEBUG.log("   (2/3)... init dbStreamOperation() completed");
		}
		
		if(dataSourceFactoryEg != null && dbEgOperation != null) {
			LOGGER_DEBUG.log("   (3/3)... init dataSourceFactoryEg() completed");
			LOGGER_DEBUG.log("   (3/3)... init dbEgOperation() completed");
		}

			
    }

    public void destory() {
    	LOGGER_DEBUG.log(" destory ACSGateway ");

    }

	public static DataSourceFactoryStream getDataSourceFactoryStream() {
		return dataSourceFactoryStream;
	}
	
	public static DataSourceFactoryFibre getDataSourceFactoryFibre() {
		return dataSourceFactoryFibre;
	}
	
	public static DataSourceFactoryEg getDataSourceFactoryEg() {
		return dataSourceFactoryEg;
	}

	public static DBStreamOperation getDbStreamOperation() {
		return dbStreamOperation;
	}
	
	public static DBFibreOperation getDbFibreOperation() {
		return dbFibreOperation;
	}

	public static DBEgOperation getDbEgOperation() {
		return dbEgOperation;
	}

	public static AcsService getEgServiceDao() {
		return egServiceDao;
	}
	
	public static AcsService getAvsServiceDao() {
		return avsServiceDao;
	}
	
	public static AcsService getHwServiceDao() {
		return hwServiceDao;
	}

	public static AcsService getKiddoServiceDao() {
		return kiddoServiceDao;
	}	

	public static EgOperation getEgOperation() {
		return egOperation;
	}

	public static AvsOperation getAvsOperation() {
		return avsOperation;
	}

	public static HwOperation getHwOperation() {
		return hwOperation;
	}

	public static KiddoOperation getKiddoOperation() {
		return kiddoOperation;
	}
	
}