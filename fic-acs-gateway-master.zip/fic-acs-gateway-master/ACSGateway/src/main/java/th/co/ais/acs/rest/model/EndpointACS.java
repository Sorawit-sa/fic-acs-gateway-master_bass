package th.co.ais.acs.rest.model;

public enum EndpointACS {

	
	param1("EG",""),
	param2("AVS","Forbidden"),
	param3("KIDDO","Forbidden");
	
	
    private String id;
	private String name;
	
    EndpointACS(String id, String name) {
    	this.id = id;
		this.name = name;
    }
    
    public String getId() { return this.id; }
	public String getName() { return this.name; }

	public static String fromId(String id) {
		for (EndpointACS e : EndpointACS.values()) {
			if (id.equals(e.id)) {
				return e.name;
			}
		}
		return null;
	}
}