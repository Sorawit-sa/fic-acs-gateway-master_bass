/**
 * GetParameterResult.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class GetParameterResult  extends th.co.tbb.acshw.model.ParameterResultBase  implements java.io.Serializable {
    private th.co.tbb.acshw.model.DiagnoseService.Para[] paras;

    public GetParameterResult() {
    }

    public GetParameterResult(
           int errorCode,
           java.lang.String errorInfo,
           th.co.tbb.acshw.model.DiagnoseService.Para[] paras) {
        super(
            errorCode,
            errorInfo);
        this.paras = paras;
    }


    /**
     * Gets the paras value for this GetParameterResult.
     * 
     * @return paras
     */
    public th.co.tbb.acshw.model.DiagnoseService.Para[] getParas() {
        return paras;
    }


    /**
     * Sets the paras value for this GetParameterResult.
     * 
     * @param paras
     */
    public void setParas(th.co.tbb.acshw.model.DiagnoseService.Para[] paras) {
        this.paras = paras;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetParameterResult)) return false;
        GetParameterResult other = (GetParameterResult) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.paras==null && other.getParas()==null) || 
             (this.paras!=null &&
              java.util.Arrays.equals(this.paras, other.getParas())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getParas() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParas());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParas(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetParameterResult.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "GetParameterResult"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paras");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paras"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "Para"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
