package th.co.ais.acs.rest.model;

public class UMPUnbinding {

	private String [] removeProperties = null;	
	
	public String[] getRemoveProperties() {
		return removeProperties;
	}
	public void setRemoveProperties(String[] remove) {
		this.removeProperties = remove;
	}	
	
}
