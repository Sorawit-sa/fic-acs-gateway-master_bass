/**
 * CpeInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class CpeInfo  implements java.io.Serializable {
    private java.lang.String accessNo;

    private java.lang.String deviceID;

    private java.lang.String deviceIP;

    private th.co.tbb.acshw.model.DiagnoseService.Para[] paraList;

    private java.lang.String userId;

    public CpeInfo() {
    }

    public CpeInfo(
           java.lang.String accessNo,
           java.lang.String deviceID,
           java.lang.String deviceIP,
           th.co.tbb.acshw.model.DiagnoseService.Para[] paraList,
           java.lang.String userId) {
           this.accessNo = accessNo;
           this.deviceID = deviceID;
           this.deviceIP = deviceIP;
           this.paraList = paraList;
           this.userId = userId;
    }


    /**
     * Gets the accessNo value for this CpeInfo.
     * 
     * @return accessNo
     */
    public java.lang.String getAccessNo() {
        return accessNo;
    }


    /**
     * Sets the accessNo value for this CpeInfo.
     * 
     * @param accessNo
     */
    public void setAccessNo(java.lang.String accessNo) {
        this.accessNo = accessNo;
    }


    /**
     * Gets the deviceID value for this CpeInfo.
     * 
     * @return deviceID
     */
    public java.lang.String getDeviceID() {
        return deviceID;
    }


    /**
     * Sets the deviceID value for this CpeInfo.
     * 
     * @param deviceID
     */
    public void setDeviceID(java.lang.String deviceID) {
        this.deviceID = deviceID;
    }


    /**
     * Gets the deviceIP value for this CpeInfo.
     * 
     * @return deviceIP
     */
    public java.lang.String getDeviceIP() {
        return deviceIP;
    }


    /**
     * Sets the deviceIP value for this CpeInfo.
     * 
     * @param deviceIP
     */
    public void setDeviceIP(java.lang.String deviceIP) {
        this.deviceIP = deviceIP;
    }


    /**
     * Gets the paraList value for this CpeInfo.
     * 
     * @return paraList
     */
    public th.co.tbb.acshw.model.DiagnoseService.Para[] getParaList() {
        return paraList;
    }


    /**
     * Sets the paraList value for this CpeInfo.
     * 
     * @param paraList
     */
    public void setParaList(th.co.tbb.acshw.model.DiagnoseService.Para[] paraList) {
        this.paraList = paraList;
    }


    /**
     * Gets the userId value for this CpeInfo.
     * 
     * @return userId
     */
    public java.lang.String getUserId() {
        return userId;
    }


    /**
     * Sets the userId value for this CpeInfo.
     * 
     * @param userId
     */
    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CpeInfo)) return false;
        CpeInfo other = (CpeInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.accessNo==null && other.getAccessNo()==null) || 
             (this.accessNo!=null &&
              this.accessNo.equals(other.getAccessNo()))) &&
            ((this.deviceID==null && other.getDeviceID()==null) || 
             (this.deviceID!=null &&
              this.deviceID.equals(other.getDeviceID()))) &&
            ((this.deviceIP==null && other.getDeviceIP()==null) || 
             (this.deviceIP!=null &&
              this.deviceIP.equals(other.getDeviceIP()))) &&
            ((this.paraList==null && other.getParaList()==null) || 
             (this.paraList!=null &&
              java.util.Arrays.equals(this.paraList, other.getParaList()))) &&
            ((this.userId==null && other.getUserId()==null) || 
             (this.userId!=null &&
              this.userId.equals(other.getUserId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccessNo() != null) {
            _hashCode += getAccessNo().hashCode();
        }
        if (getDeviceID() != null) {
            _hashCode += getDeviceID().hashCode();
        }
        if (getDeviceIP() != null) {
            _hashCode += getDeviceIP().hashCode();
        }
        if (getParaList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParaList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParaList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getUserId() != null) {
            _hashCode += getUserId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CpeInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "CpeInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accessNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "accessNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deviceID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceIP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deviceIP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paraList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paraList"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "Para"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
