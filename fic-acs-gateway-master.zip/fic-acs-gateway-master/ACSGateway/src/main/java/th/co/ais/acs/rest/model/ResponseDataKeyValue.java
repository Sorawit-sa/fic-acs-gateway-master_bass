package th.co.ais.acs.rest.model;

public class ResponseDataKeyValue {

	 String key           = null;
	 String value         = null;
	 
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return "ResponseDataKeyValue [key=" + key + ", value=" + value + "]";
	}
	 
	 
}
