package th.co.ais.acs.rest.restapi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.dao.AcsService;
import th.co.ais.acs.rest.db.DBFibreOperation;
import th.co.ais.acs.rest.db.DBStreamOperation;

import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.Credentials;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.ReponseDetail;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseMessage;



@DeclareRoles({"admin", "user", "guest"})
@Path("/acs/v1/main")
public class ACSRestServiceMain {
	
	DBFibreOperation dbFibreOperation = InitialParameter.getDbFibreOperation();
	AcsService avsServiceDao = InitialParameter.getAvsServiceDao();
	AcsService egServiceDao = InitialParameter.getEgServiceDao();
	
	private static final String OPTION_1 = "1";
	private static final String OPTION_2 = "2";
	private static final String OPTION_0 = "0";
	
	private static final String EG = "EG";
	private static final String AVS = "AVS";
	private static final String KIDDO = "KIDDO";

	@POST
	@Path("/binding")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response binding( String requestMassage ) {
		String acsSystem = "EG";
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_2);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		
		if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
			if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
				responseMessage = avsServiceDao.binding(requestMassage_);
				acsSystem = "AVS";
			} else {
				responseMessage = egServiceDao.binding(requestMassage_);
				
			}
			
		} else {
			responseMessage = egServiceDao.binding(requestMassage_);
			
		}
		
		// ResponseCode = 03201
		if(acsSystem.equals("EG") && responseMessage.getResponseCode().equals(Code.THE_DEVICE_HAS_NOT_REGISTER) ) {
			responseMessage = avsServiceDao.binding(requestMassage_);
			acsSystem = "AVS";
		}
		
		if(responseMessage.getResponseCode().equals(Code.SUCCESS) || 
		   responseMessage.getResponseCode().equals(Code.SUCCESS_SWAPPED) || 
		   responseMessage.getResponseCode().equals(Code.SUCCESS_CPE_ALREADY_BOUND)) {
			
			dbFibreOperation.updateACSsystem(requestMassage_.getFibreId(), acsSystem);
		}

			
			
		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
	@POST
	@Path("/unbinding")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response unbinding( String requestMassage ) {
		String acsSystem = "AVS";
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_2);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		
		responseMessage = avsServiceDao.unbinding(requestMassage_);
		
		if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
			dbFibreOperation.updateACSsystem(requestMassage_.getFibreId(), acsSystem);
		}

		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
	@POST
	@Path("/provisioning")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response provisioning( String requestMassage ) {

		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		
		if(requestMassage_.getBridgeVlan() != null ) {
		
			if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
				if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
					responseMessage = egServiceDao.provisioning(requestMassage_);
					responseMessage = avsServiceDao.provisioning(requestMassage_);
					
				} else {
					responseMessage = avsServiceDao.provisioning(requestMassage_);
					responseMessage = egServiceDao.provisioning(requestMassage_);
					
				}
				
			} else {
				responseMessage = egServiceDao.provisioning(requestMassage_);
				responseMessage = avsServiceDao.provisioning(requestMassage_);
				
			}
		} else {
			responseMessage = avsServiceDao.provisioning(requestMassage_);;
		}

		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
	@POST
	@Path("/wifiprovisioning")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response wifiProvisioning( String requestMassage ) {

		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);		
		ResponseMessage responseMessage = avsServiceDao.wifiProvisioning(requestMassage_);

		return ResponseBuilder.createResponseGson( responseMessage );
	}

	
}