package th.co.ais.acs.rest.model;

public class UserSecurity {
	
	private String userId = null;
	private String email = null;
	private String firstname = null;
	private String lastname = null;
	private String password = null;
	private String token = null;
	private String role = null;
	private String expires_in = "3600";
	
	public UserSecurity() {}
	
	public UserSecurity( String password, String token ) {
		this.password = password;
		this.token = token;
	}
	
	public UserSecurity( String password, String token, String role ) {
		this.password = password;
		this.token = token;
		this.role = role;
	}
	
	public UserSecurity( String email, String password, String token, String role ) {
		this.password =  email ;
		this.password = password;
		this.token = token;
		this.role = role;
	}
	
	
	
	public UserSecurity(String userId) {
		super();
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("userId=");
		builder.append(userId);
		builder.append(", email=");
		builder.append(email);
		builder.append(", firstname=");
		builder.append(firstname);
		builder.append(", lastname=");
		builder.append(lastname);
		builder.append(", password=");
		builder.append(password);
		builder.append(", token=");
		builder.append(token);
		builder.append(", role=");
		builder.append(role);
		return builder.toString();
	}

	public String getExpires_in() {
		return expires_in;
	}

	public void setExpires_in(String expires_in) {
		this.expires_in = expires_in;
	}

	
}
