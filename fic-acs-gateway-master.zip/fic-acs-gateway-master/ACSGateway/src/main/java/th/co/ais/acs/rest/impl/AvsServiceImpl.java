package th.co.ais.acs.rest.impl;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.dao.AcsService;
import th.co.ais.acs.rest.db.DBStreamOperation;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseMessage;

public class AvsServiceImpl implements AcsService {
	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	
	AcsService AvsServiceDao;
	AvsOperation avsOperation = InitialParameter.getAvsOperation();
	
	static final String basicInfoOption = "basicinfo";
	static final String advanceInfoOption = "advanceinfo";
	static final String hostInfoOption = "hostinfo";
	static final String onlineStatusOption = "onlinestatus";
	static final String lastSessiontimeOption = "lastsessiontime";
	
	static final String backupOption = "backup";
	static final String listBackupOption = "listbackup";
	static final String restoreOption = "restore";
	
	static final String addOption = "add";
	static final String updateOption = "update";
	static final String removeOption = "remove";
	static final String removeAllCustomerOption = "removeAll";
	
	static final String executionEnable = "1";
	
	static final String mainOption = "main";
	static final String EG = "EG";
	static final String AVS = "AVS";

	@Override
	public ResponseMessage provisioning(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		
		try {		
			if (!( checkMandatory(requestMessage.getActivationId())
					&& checkMandatory(requestMessage.getOption())
					)) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId, activationId, option}");
				return responseMessage;
			} else {
				if(!(requestMessage.getExecution() != null) || requestMessage.getExecution().equals("") ) {
					requestMessage.setExecution(executionEnable);					
				} 				
			}
			
			if( requestMessage.getOption().equals(removeAllCustomerOption) ) {
				responseMessage = avsOperation.provisioning(requestMessage, responseMessage);	
			}else if (!( 
					(checkMandatory(requestMessage.getInternetUsername()) && checkMandatory(requestMessage.getInternetPassword()))
					|| (checkMandatory(requestMessage.getSipUsername1()) && checkMandatory(requestMessage.getSipPassword1()))
					|| (checkMandatory(requestMessage.getSipUsername2()) && checkMandatory(requestMessage.getSipPassword2()))
					|| (checkMandatory(requestMessage.getSipUsername1()) && requestMessage.getOption().equals(removeOption) )
					|| (checkMandatory(requestMessage.getSipUsername2()) && requestMessage.getOption().equals(removeOption) )
					|| checkMandatory(requestMessage.getBridgeVlan())
				 )
			   ) {
				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{internetUsername, internetPassword, sipUsername1, sipPassword1, sipUsername2, sipPassword2}");
				return responseMessage;
			} else {
				responseMessage = avsOperation.provisioning(requestMessage, responseMessage);	
			}
		
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("binding("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}
	
	@Override
	public ResponseMessage wifiProvisioning(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getWifiInfo() != null && checkMandatory(requestMessage.getWifiInfo().get(0).getIndex()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, wifiInfo [], refId}");
				return responseMessage;
			} 
			
			responseMessage = avsOperation.wifiProvisioning(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wifiprovisioning("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage binding(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		
		try {		
			if (!( checkMandatory(requestMessage.getFibreId())
					&& checkMandatory(requestMessage.getActivationId())
					&& checkMandatory(requestMessage.getMacAddress())
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId, activationId, macAddress, refId}");
				return responseMessage;
			}
			
			responseMessage = avsOperation.binding(requestMessage, responseMessage);	
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("binding("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage unbinding(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		
		try {		
			if (!( checkMandatory(requestMessage.getFibreId())
					&& checkMandatory(requestMessage.getActivationId())
					&& checkMandatory(requestMessage.getMacAddress())
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId, activationId, macAddress, refId}");
				return responseMessage;
			}
			
			responseMessage = avsOperation.unbinding(requestMessage, responseMessage);	
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("unbinding("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage getCpeinfo(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		List<String> optionList = null;
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()) || checkMandatory(requestMessage.getIpAddress()) || checkMandatory(requestMessage.getMacAddress()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, option, refId}");
				return responseMessage;
			} else {
				if(!(requestMessage.getOption() != null) || requestMessage.getOption().equals("") ) {
					requestMessage.setOption(basicInfoOption);					
				} 
				if(requestMessage.getOption().contains(lastSessiontimeOption) && !((requestMessage.getIpAddress() != null) || (requestMessage.getMacAddress() != null))) {					
					responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
					responseMessage.setDetail("{ipAddress or macAddress is null}");
					return responseMessage;
				}

				optionList = Arrays.asList(requestMessage.getOption().toLowerCase().split("\\s*,\\s*"));
			}
			
			// 0 = fail, 1 = success, 2 = success_with_condition
			int compareResponse = 0;
			for(String option : optionList ) {				
				if(option.equals(basicInfoOption)) {
					responseMessage = avsOperation.getBasicInfo(requestMessage, responseMessage);				
					if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
						compareResponse = 1;
					}
				}
			}
			for(String option : optionList ) {				
				if(option.equals(advanceInfoOption)) {
					responseMessage = avsOperation.getAdvanceInfo(requestMessage, responseMessage);	
					if(responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 0) {
						compareResponse = 1;
					}
					if(!responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 1) {
						compareResponse = 2;
					}
				}
			}
			for(String option : optionList ) {				
				if(option.equals(hostInfoOption)) {
					responseMessage = avsOperation.getHostInfo(requestMessage, responseMessage);
					if(responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 0) {
						compareResponse = 1;
					}
					if(!responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 1) {
						compareResponse = 2;
					}
				}
			}
			for(String option : optionList ) {				
				if(option.equals(onlineStatusOption)) {
					responseMessage = avsOperation.getOnlineStatus(requestMessage, responseMessage);
					if(responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 0) {
						compareResponse = 1;
					}
					if(!responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 1) {
						compareResponse = 2;
					}
				}
				
			}
			for(String option : optionList ) {				
				if(option.equals(lastSessiontimeOption)) {
					responseMessage = avsOperation.getLastSessionTime(requestMessage, responseMessage);	
					if(responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 0) {
						compareResponse = 1;
					}
					if(!responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 1) {
						compareResponse = 2;
					}
				}
			}
			
			if(compareResponse == 2) {
				responseMessage.setResponseCode(Code.SUCCESS_WITH_CONDITION);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS_WITH_CONDITION));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getcpeinfo("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage wanSetup(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getInternetUsername())
					&& checkMandatory(requestMessage.getInternetPassword())
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, internetUsername, internetPassword, refId}");
				return responseMessage;
			} else {
				if(!(requestMessage.getOption() != null) || requestMessage.getOption().equals("") ) {
					requestMessage.setOption(mainOption);					
				} 				
			}
			
			responseMessage = avsOperation.wanSetup(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wansetup("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage getWifiInfo(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		List<String> optionList = null;
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			}
			
			responseMessage = avsOperation.getWifiInfo(requestMessage, responseMessage);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getwifiinfo("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage wifiSetup(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getWifiInfo() != null && checkMandatory(requestMessage.getWifiInfo().get(0).getIndex()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, wifiInfo [], refId}");
				return responseMessage;
			} 
			
			responseMessage = avsOperation.wifiSetup(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wansetup("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
				
		return responseMessage;
	}

	@Override
	public ResponseMessage getParameterValues(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		List<String> optionList = null;
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getParamNameVec()!= null && checkMandatory(requestMessage.getParamNameVec().get(0).getItem()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, paramNameVec [], refId}");
				return responseMessage;
			}
			
			responseMessage = avsOperation.getParameterValues(requestMessage, responseMessage);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getparameterValues("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage setParameterValues(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getParameterValues() != null && checkMandatory(requestMessage.getParameterValues().get(0).getKey()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, parameterValues [], refId}");
				return responseMessage;
			} 
			
			responseMessage = avsOperation.setParameterValues(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("setParameterValues("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
				
		return responseMessage;
	}

	@Override
	public ResponseMessage upgradeFirmware(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()) && checkMandatory(requestMessage.getFirmwareVersion()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId, version}");
				return responseMessage;
			} 
			
			responseMessage = avsOperation.upgradeFirmware(requestMessage, responseMessage);					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("upgradefirmware("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		return responseMessage;
	}
	
	@Override
	public ResponseMessage reboot(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			}
			
			responseMessage = avsOperation.reboot(requestMessage, responseMessage);					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("reboot("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		return responseMessage;
	}

	@Override
	public ResponseMessage factoryReset(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			}
			
			responseMessage = avsOperation.factoryReset(requestMessage, responseMessage);					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("factoryreset("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		return responseMessage;
	}

	@Override
	public ResponseMessage configFile(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		long start = System.currentTimeMillis();
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()) && checkMandatory(requestMessage.getOption()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId, option}");
				return responseMessage;
			} else {
				// if option = restore then check missing configFileName
				if(requestMessage.getOption().equals(restoreOption)) {
					if(!checkMandatory(requestMessage.getConfigFileName())) {
						
						responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
						responseMessage.setDetail("{configFileName}");
						return responseMessage;						
					}
				}
			}
			
			responseMessage = avsOperation.getBasicInfo(requestMessage, responseMessage);
			if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				if(responseMessage.getResponseData() != null && responseMessage.getResponseData().getBasicInfo() != null ) {
					responseMessage.setDeviceId(responseMessage.getResponseData().getBasicInfo().getDeviceId());
					
					String option = requestMessage.getOption();
					if(option.equals(listBackupOption)) {
						responseMessage = avsOperation.getCFGList(requestMessage, responseMessage);					
					} else if(option.equals(restoreOption)) {
						responseMessage = avsOperation.downloadCFGToDevice(requestMessage, responseMessage);	
					} else if (option.equals(backupOption)) {
						responseMessage = avsOperation.uploadCFG(requestMessage, responseMessage);
					} else {
						responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
						responseMessage.setDetail("{options does not match}");
					}
				} else {
					responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
					responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				}
				
				
			} else {
				responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
			}
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("configfile("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		} finally {
			if(responseMessage.getResponseData() != null && responseMessage.getResponseData().getBasicInfo() != null) {
				responseMessage.getResponseData().setBasicInfo(null);
			}
		}
		
		
		return responseMessage;
	}
	
	@Override
	public ResponseMessage checkVoIPProfile(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(AVS);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			} 
			
			responseMessage = avsOperation.getBasicInfo(requestMessage, responseMessage);
			if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
				if(responseMessage.getResponseData() != null && responseMessage.getResponseData().getBasicInfo() != null ) {
					responseMessage.setDeviceId(responseMessage.getResponseData().getBasicInfo().getDeviceId());
					
					responseMessage = avsOperation.checkVoIPProfile(requestMessage, responseMessage);
					
				} else {
					responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
					responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				}
				
				
			} else {
				responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
			}
			
			
			
			
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("checkVoIPProfile("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
				
		return responseMessage;
	}
	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}
	
}
