package th.co.ais.acs.rest.model;

public enum ReponseCode {

	param1("00000","SUCCESS"),
	param2("00001","USER_OR_PASSWORD_INVALID"),
	param3("00002","MISSING_OR_INVALID_PARAMETER"),
	param4("00003","NO_TOKEN_PROVIDED"),
	param5("00004","INVALID_TOKEN_PROVIDED"),
	param6("00005","TOKEN_MISSMATCH"),
	param7("00006","TOKEN_EXPIRED"),
	param8("00007","USER_DOES_NOT_HAVE_PERMISSION_TO_THIS_RESOURCE"),
	param9("01002","DATA_NOT_FOUND"),
	param10("03001","The cpe successfully swapped with the old."),
	param11("03200","The cpe has already been bound with this activation id."),
	param12("03201","The device has not registered to the ACS server."),
	param13("03202","ActivationID does not exist."),
	param14("03299","UNKNOW return from ACS"),
	param15("99001","MISSING_MADATORY_FIELD"),
	param16("99200","User does not exist or CPE does not exist or CPE has not been bind to the Logic ID."),
	param17("99201","Multiple devices found for given Customer ID"),

	param22("99202","The parameter is invalid."),
	param23("99203","Device is offline."),
	param24("99204","Method not supported."),
	param25("99205","Internal error."),
	param26("99206","Invalid arguments."),
	param27("99207","Invalid parameter name (associated with Set/GetParameterValues,GetParameterNames, Set/GetParameterAttributes, AddObject, and DeleteObject)."),
	param28("99208","Attempt to set a non-writable parameter."),

	param18("99001","MISSING_MADATORY_FIELD"),
	param19("99999","OPERATIONS_FAIL"),
	param20("00010","SUCCESS_WITH_CONDITION"),
	param21("99000","FAILURE");
	
    private String id;
	private String name;
	
    ReponseCode(String id, String name) {
    	this.id = id;
		this.name = name;
    }
    
    public String getId() { return this.id; }
	public String getName() { return this.name; }

	public static String fromId(String id) {
		for (ReponseCode e : ReponseCode.values()) {
			if (id.equals(e.id)) {
				return e.name;
			}
		}
		return null;
	}
}