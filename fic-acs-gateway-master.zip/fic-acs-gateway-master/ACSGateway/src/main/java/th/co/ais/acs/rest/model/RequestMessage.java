package th.co.ais.acs.rest.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

public class RequestMessage {
	// queryacsendpoint
	private String bindAccount = null;
	
	// provisioning
	private String internetUsername = null;
	private String internetPassword = null;
	private String fibreId = null;
	private String sipUsername1 = null;
	private String sipPassword1 = null;
	private String sipuri1 = null;
	private String sipUsername2 = null;
	private String sipPassword2 = null;
	private String sipuri2 = null;
	private String execution = null;
	private String bridgeVlan = null;
	private String productOwner = null;
	
	// binding
	//private String fibreId = null;
	private String activationId = null;
	private String macAddress = null;
	
	// getcpeinfo
	//private String fibreId = null;
	//private String activationId = null;
	private String option = null;
	private String ipAddress = null;
	
	// wansetup
	//private String fibreId = null;
	//private String activationId = null;
	//private String option = null;
	//private String internetUsername = null;
	//private String internetPassword = null;
	private String primaryDns = null;
	private String secondDns = null;
	
	// getwifiinfo
	//private String fibreId = null;
	//private String activationId = null;
		
	// wifisetup
	//private String fibreId = null;
	//private String activationId = null;
	ArrayList<RequestWiFiInfo> wifiInfo = null;
	
	// getparametervalues
	//private String fibreId = null;
	//private String activationId = null;
	ArrayList<RequestItem>  paramNameVec = null;
	
	// setparametervalues
	//private String fibreId = null;
	//private String activationId = null;
	ArrayList<RequestDataKeyValue> parameterValues = null;
	
	// upgradefirmware
	//private String fibreId = null;
	//private String activationId = null;
	private String  firmwareVersion = null;
	
	// reboot
	//private String fibreId = null;
	//private String activationId = null;

	// factoryreset
	//private String fibreId = null;
	//private String activationId = null;
	
	// configfile
	private String configFileName = null;
		
	// RefId
	private String refId = null;

	
	public String getBindAccount() {
		return bindAccount;
	}

	public void setBindAccount(String bindAccount) {
		this.bindAccount = bindAccount;
	}

	public String getInternetUsername() {
		return internetUsername;
	}

	public void setInternetUsername(String internetUsername) {
		this.internetUsername = internetUsername;
	}

	public String getInternetPassword() {
		return internetPassword;
	}

	public void setInternetPassword(String internetPassword) {
		this.internetPassword = internetPassword;
	}

	public String getFibreId() {
		return fibreId;
	}

	public void setFibreId(String fibreId) {
		this.fibreId = fibreId;
	}

	public String getSipUsername1() {
		return sipUsername1;
	}

	public void setSipUsername1(String sipUsername1) {
		this.sipUsername1 = sipUsername1;
	}

	public String getSipPassword1() {
		return sipPassword1;
	}

	public void setSipPassword1(String sipPassword1) {
		this.sipPassword1 = sipPassword1;
	}

	public String getSipuri1() {
		return sipuri1;
	}

	public void setSipuri1(String sipuri1) {
		this.sipuri1 = sipuri1;
	}

	public String getSipUsername2() {
		return sipUsername2;
	}

	public void setSipUsername2(String sipUsername2) {
		this.sipUsername2 = sipUsername2;
	}

	public String getSipPassword2() {
		return sipPassword2;
	}

	public void setSipPassword2(String sipPassword2) {
		this.sipPassword2 = sipPassword2;
	}

	public String getSipuri2() {
		return sipuri2;
	}

	public void setSipuri2(String sipuri2) {
		this.sipuri2 = sipuri2;
	}

	public String getActivationId() {
		return activationId;
	}

	public void setActivationId(String activationId) {
		this.activationId = activationId;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setSn(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public String getPrimaryDns() {
		return primaryDns;
	}

	public void setPrimaryDns(String primaryDns) {
		this.primaryDns = primaryDns;
	}

	public String getSecondDns() {
		return secondDns;
	}

	public void setSecondDns(String secondDns) {
		this.secondDns = secondDns;
	}

	public ArrayList<RequestWiFiInfo> getWifiInfo() {
		return wifiInfo;
	}

	public void setWifiInfo(ArrayList<RequestWiFiInfo> wifiInfo) {
		this.wifiInfo = wifiInfo;
	}

	public String getFirmwareVersion() {
		return firmwareVersion;
	}

	public void setFirmwareVersion(String firmwareVersion) {
		this.firmwareVersion = firmwareVersion;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getConfigFileName() {
		return configFileName;
	}

	public ArrayList<RequestItem> getParamNameVec() {
		return paramNameVec;
	}

	public void setParamNameVec(ArrayList<RequestItem> paramNameVec) {
		this.paramNameVec = paramNameVec;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public void setConfigFileName(String configFileName) {
		this.configFileName = configFileName;
	}

	@Override
	public String toString() {
		return "RequestMessage [" + (bindAccount != null ? "bindAccount=" + bindAccount + ", " : "")
				+ (internetUsername != null ? "internetUsername=" + internetUsername + ", " : "")
				+ (internetPassword != null ? "internetPassword=" + internetPassword + ", " : "")
				+ (fibreId != null ? "fibreId=" + fibreId + ", " : "")
				+ (sipUsername1 != null ? "sipUsername1=" + sipUsername1 + ", " : "")
				+ (sipPassword1 != null ? "sipPassword1=" + sipPassword1 + ", " : "")
				+ (sipuri1 != null ? "sipuri1=" + sipuri1 + ", " : "")
				+ (sipUsername2 != null ? "sipUsername2=" + sipUsername2 + ", " : "")
				+ (sipPassword2 != null ? "sipPassword2=" + sipPassword2 + ", " : "")
				+ (sipuri2 != null ? "sipuri2=" + sipuri2 + ", " : "")
				+ (activationId != null ? "activationId=" + activationId + ", " : "")
				+ (macAddress != null ? "macAddress=" + macAddress + ", " : "")
				+ (execution != null ? "execution=" + execution + ", " : "")
				+ (bridgeVlan != null ? "bridgeVlan=" + bridgeVlan + ", " : "")
				+ (productOwner != null ? "productOwner=" + productOwner + ", " : "")
				+ (option != null ? "option=" + option + ", " : "")
				+ (ipAddress != null ? "ipAddress=" + ipAddress + ", " : "")
				+ (primaryDns != null ? "primaryDns=" + primaryDns + ", " : "")
				+ (secondDns != null ? "secondDns=" + secondDns + ", " : "")
				+ (wifiInfo != null ? "wifiInfo=" + Arrays.toString(wifiInfo.toArray()) + ", " : "")
				+ (paramNameVec != null ? "paramNameVec=" + Arrays.toString(paramNameVec.toArray()) + ", " : "")
				+ (parameterValues != null ? "parameterValues=" + Arrays.toString(parameterValues.toArray()) + ", " : "")
				+ (firmwareVersion != null ? "firmwareVersion=" + firmwareVersion + ", " : "")
				+ (configFileName != null ? "configFileName=" + configFileName + ", " : "")
				+ (refId != null ? "refId=" + refId : "") + "]";
	}

	public ArrayList<RequestDataKeyValue> getParameterValues() {
		return parameterValues;
	}

	public void setParameterValues(ArrayList<RequestDataKeyValue> parameterValues) {
		this.parameterValues = parameterValues;
	}

	public String getExecution() {
		return execution;
	}

	public void setExecution(String execution) {
		this.execution = execution;
	}

	public String getBridgeVlan() {
		return bridgeVlan;
	}

	public void setBridgeVlan(String bridgeVlan) {
		this.bridgeVlan = bridgeVlan;
	}

	public String getProductOwner() {
		return productOwner;
	}

	public void setProductOwner(String productOwner) {
		this.productOwner = productOwner;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
}
