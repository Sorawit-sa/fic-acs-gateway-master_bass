/**
 * NorthQueryParaResult.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.OperationDistributeService;

public class NorthQueryParaResult  implements java.io.Serializable {
    private int IOpRst;

    private java.lang.Object[] paraList;

    public NorthQueryParaResult() {
    }

    public NorthQueryParaResult(
           int IOpRst,
           java.lang.Object[] paraList) {
           this.IOpRst = IOpRst;
           this.paraList = paraList;
    }


    /**
     * Gets the IOpRst value for this NorthQueryParaResult.
     * 
     * @return IOpRst
     */
    public int getIOpRst() {
        return IOpRst;
    }


    /**
     * Sets the IOpRst value for this NorthQueryParaResult.
     * 
     * @param IOpRst
     */
    public void setIOpRst(int IOpRst) {
        this.IOpRst = IOpRst;
    }


    /**
     * Gets the paraList value for this NorthQueryParaResult.
     * 
     * @return paraList
     */
    public java.lang.Object[] getParaList() {
        return paraList;
    }


    /**
     * Sets the paraList value for this NorthQueryParaResult.
     * 
     * @param paraList
     */
    public void setParaList(java.lang.Object[] paraList) {
        this.paraList = paraList;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NorthQueryParaResult)) return false;
        NorthQueryParaResult other = (NorthQueryParaResult) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.IOpRst == other.getIOpRst() &&
            ((this.paraList==null && other.getParaList()==null) || 
             (this.paraList!=null &&
              java.util.Arrays.equals(this.paraList, other.getParaList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIOpRst();
        if (getParaList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParaList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParaList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NorthQueryParaResult.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("OperationDistributeService", "NorthQueryParaResult"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IOpRst");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IOpRst"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paraList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paraList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
