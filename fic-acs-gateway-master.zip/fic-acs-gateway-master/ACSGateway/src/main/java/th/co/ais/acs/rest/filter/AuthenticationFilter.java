package th.co.ais.acs.rest.filter;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Priority;
import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import org.jose4j.jwt.consumer.InvalidJwtException;

import com.google.gson.Gson;

import th.co.ais.acs.rest.db.DBStreamOperation;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.ReponseDetail;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UserSecurity;
import th.co.ais.acs.rest.restapi.ResponseBuilder;
import th.co.ais.acs.rest.security.TokenSecurity;

/**
 * The AuthenticationFilter verifies the access permissions for a user based on the provided jwt token 
 * and role annotations
 **/
@Provider
@Priority( Priorities.AUTHENTICATION )
public class AuthenticationFilter implements javax.ws.rs.container.ContainerRequestFilter
{	

	static DBStreamOperation dbStreamOperation = InitialParameter.getDbStreamOperation();
	
	@Context
    private ResourceInfo resourceInfo;
	
    public static final String HEADER_PROPERTY_ID = "userId";
    public static final String AUTHORIZATION_PROPERTY = "access_token";
    
    // Do not use static responses, rebuild reponses every time
    private static final String ACCESS_REFRESH = "Token expired. Please authenticate again!";
    private static final String ACCESS_INVALID_TOKEN = "Token invalid. Please authenticate again!";
    private static final String ACCESS_DENIED = "Not allowed to access this resource!";
    private static final String ACCESS_FORBIDDEN = "Access forbidden!";
    
    @Override
    public void filter( ContainerRequestContext requestContext )
    {
    	ResponseMessage responseMessage = new ResponseMessage(null);
    	
        Method method = resourceInfo.getResourceMethod();
        // everybody can access (e.g. user/create or user/authenticate)
        if( !method.isAnnotationPresent( PermitAll.class ) )
        {
            // nobody can access
            if( method.isAnnotationPresent( DenyAll.class ) ) 
            {
                requestContext.abortWith( ResponseBuilder.createResponse( Response.Status.FORBIDDEN, ACCESS_FORBIDDEN ));
                return;
            }
              
            // get request headers to extract jwt token
            final MultivaluedMap<String, String> headers = requestContext.getHeaders();
            final List<String> authProperty = headers.get( AUTHORIZATION_PROPERTY );
              
            // block access if no authorization information is provided
            if( authProperty == null || authProperty.isEmpty() )
            {
            	//logger.warn("No token provided!");
                //requestContext.abortWith( ResponseBuilder.createResponse( Response.Status.UNAUTHORIZED, ACCESS_DENIED ));
                
                responseMessage.setResponseCode(Code.NO_TOKEN_PROVIDED);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.NO_TOKEN_PROVIDED));
				responseMessage.setDetail(ReponseDetail.fromId(Code.NO_TOKEN_PROVIDED));				
				requestContext.abortWith( ResponseBuilder.createResponseGson( Response.Status.UNAUTHORIZED, new Gson().toJson(responseMessage) ));
                return;
            }
              
            String userId = null ;
            String jwt = authProperty.get(0);
            
			// try to decode the jwt - deny access if no valid token provided
			try {
				userId = TokenSecurity.validateJwtToken( jwt );
			} catch ( InvalidJwtException e ) {
				//logger.warn("Invalid token provided!");
                //requestContext.abortWith( ResponseBuilder.createResponse( Response.Status.UNAUTHORIZED, ACCESS_INVALID_TOKEN ));
                
                responseMessage.setResponseCode(Code.INVALID_TOKEN_PROVIDED);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.INVALID_TOKEN_PROVIDED));
				responseMessage.setDetail(ReponseDetail.fromId(Code.INVALID_TOKEN_PROVIDED));				
				requestContext.abortWith( ResponseBuilder.createResponseGson( Response.Status.UNAUTHORIZED, new Gson().toJson(responseMessage) ));
                return;
			}
            
            // check if token matches an user token (set in user/authenticate)
			UserSecurity userSecurity = new UserSecurity();
            userSecurity = dbStreamOperation.queryUserSecurityByUserName(userId);
            
            if(!(userSecurity.getPassword() != null)) {
            	//logger.warn("Token missmatch!");
                ///requestContext.abortWith( ResponseBuilder.createResponse( Response.Status.UNAUTHORIZED, ACCESS_DENIED ) );
                
                responseMessage.setResponseCode(Code.TOKEN_MISSMATCH);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.TOKEN_MISSMATCH));
				responseMessage.setDetail(ReponseDetail.fromId(Code.TOKEN_MISSMATCH));				
				requestContext.abortWith( ResponseBuilder.createResponseGson( Response.Status.UNAUTHORIZED, new Gson().toJson(responseMessage) ));
            	return;
            }

            // token does not match with token stored in database - enforce re authentication
//            if( !userSecurity.getToken().equals( jwt ) ) {
//            	//logger.warn("Token expired!");
//               // requestContext.abortWith( ResponseBuilder.createResponse( Response.Status.UNAUTHORIZED, ACCESS_REFRESH ) );
//                
//                responseMessage.setResponseCode(Code.TOKEN_EXPIRED);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.TOKEN_EXPIRED));
//				responseMessage.setDetail(ReponseDetail.fromId(Code.TOKEN_EXPIRED));				
//				requestContext.abortWith( ResponseBuilder.createResponseGson( Response.Status.UNAUTHORIZED, new Gson().toJson(responseMessage) ));
//                return;
//            }
            
            // verify user access from provided roles ("admin", "user", "guest")
            if( method.isAnnotationPresent( RolesAllowed.class ) )
            {
            	// get annotated roles
                RolesAllowed rolesAnnotation = method.getAnnotation( RolesAllowed.class );
                Set<String> rolesSet = new HashSet<String>( Arrays.asList( rolesAnnotation.value() ) );
                  
                // user valid?
                if( !isUserAllowed( userSecurity.getRole(), rolesSet ) )
                {
                	//logger.warn("User does not have the rights to acces this resource!");
                   // requestContext.abortWith( ResponseBuilder.createResponse( Response.Status.UNAUTHORIZED, ACCESS_DENIED ));
                    
                    responseMessage.setResponseCode(Code.USER_DOES_NOT_HAVE_PERMISSION_TO_THIS_RESOURCE);
    				responseMessage.setResponseMessage(ReponseCode.fromId(Code.USER_DOES_NOT_HAVE_PERMISSION_TO_THIS_RESOURCE));
    				responseMessage.setDetail(ReponseDetail.fromId(Code.USER_DOES_NOT_HAVE_PERMISSION_TO_THIS_RESOURCE));				
    				requestContext.abortWith( ResponseBuilder.createResponseGson( Response.Status.UNAUTHORIZED, new Gson().toJson(responseMessage) ));
                    return;
                }
            }
            
            // set header param email for user identification in rest service - do not decode jwt twice in rest services
            List<String> idList = new ArrayList<String>();
            idList.add( userId );
            headers.put( HEADER_PROPERTY_ID, idList );
        }
    }
    
    private boolean isUserAllowed( final String userRole, final Set<String> rolesSet )
    {
        boolean isAllowed = false;
          
        if( rolesSet.contains( userRole ) )
        {
            isAllowed = true;
        }
        
        return isAllowed;
    }
}
