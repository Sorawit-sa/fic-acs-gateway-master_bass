
package th.co.ais.acs.rest.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import th.co.ais.acs.rest.impl.AvsServiceImpl;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogDB;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseDataBasicInfo;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UserSecurity;


public class DBEgOperation {

	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	private static final LogDB LOGGER_INFO = new LogDB();
	
	DataSourceFactoryEg dbPoolEg = InitialParameter.getDataSourceFactoryEg();
	
	static final String lastSessiontimeOption = "lastsessiontime";
	private static final String ACS_API = InitialParameter.ACS_API;
	
	public ResponseMessage queryLastSessionTimeByMac(RequestMessage requestMessage, ResponseMessage responseMessage) {
			Connection conn = null;
			NamedParameterStatement pStmt0 = null;
			ResultSet rs = null;
			int result = 0;
			String newMac = "";
			try {
					long start = System.currentTimeMillis();	
					
					String macLower = requestMessage.getMacAddress().toLowerCase().trim();
					newMac = macLower;
					newMac = newMac.replace(":", "");
					newMac = newMac.replace("-", "");
					newMac = newMac.replace(".", "");
	
					if(newMac.length() == 12) {
						 String mac1 = newMac.substring(0, 2);
						 String mac2 = newMac.substring(2, 4);
						 String mac3 = newMac.substring(4, 6);
						 String mac4 = newMac.substring(6, 8);
						 String mac5 = newMac.substring(8, 10);
						 String mac6 = newMac.substring(10, 12);
						 newMac = mac1 + ":" + mac2 + ":" + mac3 + ":" + mac4 + ":" + mac5 + ":" + mac6;
					} else {
						 newMac = macLower;
					}
				
					
					if( InitialParameter.MODE == 0 ) {
						try {
							Class.forName("oracle.jdbc.driver.OracleDriver");
						} catch (ClassNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    	 	String url = "jdbc:oracle:thin:@" + "10.197.19.48" + ":" + "1521" + ":" + "uep";
			    	    conn = DriverManager.getConnection(url, "fic", "Fbbfcp0");
					} else {
						conn = dbPoolEg.getConnection();
					}
					String sqlStr0 = Sql.QUERY_FIBREID_BY_MAC_EG.getMessage();					
					pStmt0 = new NamedParameterStatement(conn, sqlStr0);
					pStmt0.setString("macAddress", newMac.toUpperCase().replace(":", ""));	
					
					rs = pStmt0.executeQuery();
					
//					SELECT ONLINE_CPE.DEVICEID,
//					 ONLINE_CPE.PUBLICIP,
//					 ONLINE_CPE.MAC,
//					 TYPE.OUI,
//					 TYPE.PRODUCTCLASS,
//					 ONLINE_CPE.SOFTVER,
//					 ONLINE_CPE.HARDVER,
//					 TYPE.MANUFACTURER,
//					 TO_CHAR(ONLINE_CPE.LASTMODIFYTIME,'DD-MM-YYYY HH24:MI:SS') AS LASTMODIFYTIME
//					 FROM
//					 (SELECT DEVICEID,
//					 TYPEID,
//					 PUBLICIP,
//					 MAC,
//					 LASTMODIFYTIME,
//					 HARDVER,
//					 SOFTVER,
					
					if (rs.next()) {
						ResponseDataBasicInfo responseDataBasicInfo = new ResponseDataBasicInfo();
						responseDataBasicInfo.setDeviceId(rs.getString("DEVICEID"));
						if(rs.getString("HARDVER") != null) {
							responseDataBasicInfo.setHardwareVersion(rs.getString("HARDVER"));
						}
						if(rs.getString("MAC") != null) {
							responseDataBasicInfo.setMacAddress(rs.getString("MAC"));
						}
						if(rs.getString("MANUFACTURER") != null) {
							responseDataBasicInfo.setManufacturer(rs.getString("MANUFACTURER"));
						}
						if(rs.getString("OUI") != null) {
							responseDataBasicInfo.setOui(rs.getString("OUI"));
						}
						if(rs.getString("PRODUCTCLASS") != null) {
							responseDataBasicInfo.setProductClass(rs.getString("PRODUCTCLASS"));
						}
						if(rs.getString("PUBLICIP") != null) {
							responseDataBasicInfo.setIpAddress(rs.getString("PUBLICIP"));
						}
						if(rs.getString("LASTMODIFYTIME") != null) {
							responseDataBasicInfo.setLastSessionTime(rs.getString("LASTMODIFYTIME"));
						}
						if(rs.getString("SOFTVER") != null) {
							responseDataBasicInfo.setSoftwareVersion(rs.getString("SOFTVER"));
						}

						responseMessage.getResponseData().setBasicInfo(responseDataBasicInfo);
						responseMessage.setResponseCode(Code.SUCCESS);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					} else {
						responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
						responseMessage.setDetail("Data on database EG not found");
					}
					
					long elapsedTimeMillis = System.currentTimeMillis()-start;
		  			//LOGGER_INFO.log("method=queryUserSecurityByUserName, " + userSecurity.toString() + ", elapsed=" + elapsedTimeMillis);
		  			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(responseMessage.getDetail() + lastSessiontimeOption + " response=" + e.getMessage() + ", ");
			} finally {

				try {
					if (conn != null) conn.close();
					if (pStmt0 != null) pStmt0.close();
					if (rs != null) rs.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return responseMessage;
	}
	
	public ResponseMessage queryLastSessionTimeByIP(RequestMessage requestMessage, ResponseMessage responseMessage) {
		Connection conn = null;
		NamedParameterStatement pStmt0 = null;
		ResultSet rs = null;
		int result = 0;
		String ip = "";
		try {
				if(requestMessage.getIpAddress() != null) {
					String ip1 = requestMessage.getIpAddress().trim().split("\\.")[0];
					String ip2 = requestMessage.getIpAddress().trim().split("\\.")[1];
					String ip3 = requestMessage.getIpAddress().trim().split("\\.")[2];
					String ip4 = requestMessage.getIpAddress().trim().split("\\.")[3];
					
					if(ip1.length() == 1)
						ip1 = "00" + ip1;
					if(ip1.length() == 2)
						ip1 = "0" + ip1;
					
					if(ip2.length() == 1)
						ip2 = "00" + ip2;
					if(ip2.length() == 2)
						ip2 = "0" + ip2;
					
					if(ip3.length() == 1)
						ip3 = "00" + ip3;
					if(ip1.length() == 2)
						ip3 = "0" + ip3;
					
					if(ip4.length() == 1)
						ip4 = "00" + ip4;
					if(ip4.length() == 2)
						ip4 = "0" + ip4;
					ip = ip1 + "." + ip2 + "."  + ip3 + "."  + ip4;
				}
				
				long start = System.currentTimeMillis();	
				if( InitialParameter.MODE == 0 ) {
					try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    	 	String url = "jdbc:oracle:thin:@" + "10.197.19.48" + ":" + "1521" + ":" + "uep";
		    	    conn = DriverManager.getConnection(url, "fic", "Fbbfcp0");
				} else {
					conn = dbPoolEg.getConnection();
				}
				
				String sqlStr0 = Sql.QUERY_FIBREID_BY_IP_EG.getMessage();					
				pStmt0 = new NamedParameterStatement(conn, sqlStr0);
				pStmt0.setString("ipAddress", ip);	
				
				rs = pStmt0.executeQuery();
				
//				SELECT ONLINE_CPE.DEVICEID,
//				 ONLINE_CPE.PUBLICIP,
//				 ONLINE_CPE.MAC,
//				 TYPE.OUI,
//				 TYPE.PRODUCTCLASS,
//				 ONLINE_CPE.SOFTVER,
//				 ONLINE_CPE.HARDVER,
//				 TYPE.MANUFACTURER,
//				 TO_CHAR(ONLINE_CPE.LASTMODIFYTIME,'DD-MM-YYYY HH24:MI:SS') AS LASTMODIFYTIME
//				 FROM
//				 (SELECT DEVICEID,
//				 TYPEID,
//				 PUBLICIP,
//				 MAC,
//				 LASTMODIFYTIME,
//				 HARDVER,
//				 SOFTVER,
				
				if (rs.next()) {
					ResponseDataBasicInfo responseDataBasicInfo = new ResponseDataBasicInfo();
					responseDataBasicInfo.setDeviceId(rs.getString("DEVICEID"));
					if(rs.getString("HARDVER") != null) {
						responseDataBasicInfo.setHardwareVersion(rs.getString("HARDVER"));
					}
					if(rs.getString("MAC") != null) {
						responseDataBasicInfo.setMacAddress(rs.getString("MAC"));
					}
					if(rs.getString("MANUFACTURER") != null) {
						responseDataBasicInfo.setManufacturer(rs.getString("MANUFACTURER"));
					}
					if(rs.getString("OUI") != null) {
						responseDataBasicInfo.setOui(rs.getString("OUI"));
					}
					if(rs.getString("PRODUCTCLASS") != null) {
						responseDataBasicInfo.setProductClass(rs.getString("PRODUCTCLASS"));
					}
					if(rs.getString("PUBLICIP") != null) {
						responseDataBasicInfo.setIpAddress(rs.getString("PUBLICIP"));
					}
					if(rs.getString("LASTMODIFYTIME") != null) {
						responseDataBasicInfo.setLastSessionTime(rs.getString("LASTMODIFYTIME"));
					}
					if(rs.getString("SOFTVER") != null) {
						responseDataBasicInfo.setSoftwareVersion(rs.getString("SOFTVER"));
					}

					responseMessage.getResponseData().setBasicInfo(responseDataBasicInfo);
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
				} else {
					responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
					responseMessage.setDetail("Data on database EG not found");
				}
				
				long elapsedTimeMillis = System.currentTimeMillis()-start;
	  			//LOGGER_INFO.log("method=queryUserSecurityByUserName, " + userSecurity.toString() + ", elapsed=" + elapsedTimeMillis);
	  			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(responseMessage.getDetail() + lastSessiontimeOption + " response=" + e.getMessage() + ", ");
		} finally {

			try {
				if (conn != null) conn.close();
				if (pStmt0 != null) pStmt0.close();
				if (rs != null) rs.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return responseMessage;
	}
	
	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}
}
