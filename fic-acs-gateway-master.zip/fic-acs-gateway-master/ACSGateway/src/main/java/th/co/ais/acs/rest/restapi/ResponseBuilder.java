package th.co.ais.acs.rest.restapi;

import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.google.gson.Gson;

import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.JsonSerializable;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.ReponseDetail;
import th.co.ais.acs.rest.model.ResponseMessage;

public class ResponseBuilder {
	
	public static Response createResponse( Response.Status status  ) {
		JSONObject jsonObject = new JSONObject();
		
		try {
			jsonObject.put( "message", status.toString() );
		}
		catch( JSONException e ) {
			return Response.status( Response.Status.INTERNAL_SERVER_ERROR ).entity( Response.Status.INTERNAL_SERVER_ERROR ).build();
		}
		
		return Response.status( status ).entity( jsonObject.toString() ).build();
	}
	
	public static Response createResponse( Response.Status status, String message ) {
		JSONObject jsonObject = new JSONObject();
		
		try {
			jsonObject.put( "message", message );
		}
		catch( JSONException e ) {
			return Response.status( Response.Status.INTERNAL_SERVER_ERROR ).entity( Response.Status.INTERNAL_SERVER_ERROR ).build();
		}
		
		return Response.status( status ).entity( jsonObject.toString() ).build();
	}
	
	public static Response createResponse( Response.Status status, JsonSerializable json ) throws JSONException {
		return Response.status( status ).entity( json.toJson().toString() ).build();
	}
	
	public static Response createResponse( Response.Status status, List<JsonSerializable> json ) throws JSONException {
		JSONArray jsonArray = new JSONArray();
		
		for( int i = 0; i < json.size(); i++ ) {
			jsonArray.put( json.get(i).toJson() );
		}
		
		return Response.status( status ).entity( jsonArray.toString() ).build();
	}
	
	public static Response createResponse( Response.Status status, Map<String,Object> map ) {
		JSONObject jsonObject = new JSONObject();
		
		try {
			for( Map.Entry<String,Object> entry : map.entrySet() ) {
				jsonObject.put( entry.getKey(), entry.getValue() );
			}
		}
		catch( JSONException e ) {
			return Response.status( Response.Status.INTERNAL_SERVER_ERROR ).entity( Response.Status.INTERNAL_SERVER_ERROR ).build();
		}
		
		return Response.status( status ).entity( jsonObject.toString() ).build();
	}
	
	public static Response createResponse( Response.Status status, ResponseMessage responseMessage) {
		JSONObject jsonObject = new JSONObject();
		
//		try {
//	
//		}
//		catch( JSONException e ) {
//			return Response.status( Response.Status.INTERNAL_SERVER_ERROR ).entity( Response.Status.INTERNAL_SERVER_ERROR ).build();
//		}
		
		return Response.status( status ).entity( responseMessage ).build();
	}
	
	public static Response createResponseGson( Response.Status status, String message ) {
		
		return Response.status( status ).entity( message ).build();
	}
	
	public static Response createResponseGson( ResponseMessage responseMessage) {
		
		try {
			if(responseMessage.getResponseData() != null && responseMessage.getResponseData().isEmpty()) {
				responseMessage.setResponseData(null);
			}
			
			if(responseMessage.getDetail() != null && responseMessage.getDetail().toLowerCase().equals("multiple devices found for given customer id")) {
				responseMessage.setResponseCode(Code.MULTIPLE_DEVICE);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MULTIPLE_DEVICE));
				responseMessage.setResponseMessage(ReponseDetail.fromId(Code.MULTIPLE_DEVICE));
			}
			
			
			if(responseMessage.getResponseCode() != null && (responseMessage.getResponseCode().startsWith("9") || responseMessage.getResponseCode().startsWith("03") || responseMessage.getResponseCode().startsWith("00010"))) {
				return Response.status( Response.Status.OK ).entity( new Gson().toJson(responseMessage) ).build();
				
			} else if(responseMessage.getResponseMessage() != null && !responseMessage.getResponseMessage().contains("SUCCESS")) {
				return Response.status( Response.Status.BAD_REQUEST ).entity( new Gson().toJson(responseMessage) ).build();
			} else {
				return Response.status( Response.Status.OK ).entity( new Gson().toJson(responseMessage) ).build();
			}
		}
		catch( Exception e ) {
			return Response.status( Response.Status.INTERNAL_SERVER_ERROR ).entity( Response.Status.INTERNAL_SERVER_ERROR ).build();
		}

	}
}
