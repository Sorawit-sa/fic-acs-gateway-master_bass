package th.co.ais.acs.rest.impl;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.dao.AcsService;
import th.co.ais.acs.rest.db.DBStreamOperation;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseMessage;

public class EgServiceImpl implements AcsService {
	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	
	AcsService EgServiceDao;
	EgOperation egOperation = InitialParameter.getEgOperation();
	
	static final String basicInfoOption = "basicinfo";
	static final String advanceInfoOption = "advanceinfo";
	static final String hostInfoOption = "hostinfo";
	static final String onlineStatusOption = "onlinestatus";
	static final String lastSessiontimeOption = "lastsessiontime";
	
	static final String backupOption = "backup";
	static final String listBackupOption = "listbackup";
	static final String restoreOption = "restore";
	
	static final String mainOption = "main";
	
	static final String executionEnable = "1";
	static final String EG = "EG";
	static final String AVS = "AVS";

	@Override
	public ResponseMessage provisioning(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		
		try {		
			if (!( checkMandatory(requestMessage.getActivationId())
					&& checkMandatory(requestMessage.getOption())
					&& checkMandatory(requestMessage.getBridgeVlan())
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId, activationId, option, refId, bridgeVlan} EG only support setting bridgeVlan");
				return responseMessage;
			} else {
				if(!(requestMessage.getExecution() != null) || requestMessage.getExecution().equals("") ) {
					requestMessage.setExecution(executionEnable);				
				} 				
			}
			
			responseMessage = egOperation.provisioning(requestMessage, responseMessage);
		
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("binding("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}
	
	@Override
	public ResponseMessage wifiProvisioning(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);	
		
		responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
		responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
		responseMessage.setDetail("");
		
		return responseMessage;
	}

	@Override
	public ResponseMessage binding(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		
		try {		
			if (!( checkMandatory(requestMessage.getFibreId())
					&& checkMandatory(requestMessage.getActivationId())
					&& checkMandatory(requestMessage.getMacAddress())
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId, activationId, macAddress, refId}");
				return responseMessage;
			}
			
			responseMessage = egOperation.binding(requestMessage, responseMessage);	
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("binding("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage unbinding(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		
		try {		
			if (!( checkMandatory(requestMessage.getFibreId())
					&& checkMandatory(requestMessage.getActivationId())
					&& checkMandatory(requestMessage.getMacAddress())
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId, activationId, macAddress, refId}");
				return responseMessage;
			}
			
//			responseMessage = egOperation.unbinding(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("unbinding("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage getCpeinfo(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		List<String> optionList = null;
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()) || checkMandatory(requestMessage.getIpAddress()) || checkMandatory(requestMessage.getMacAddress()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, option, refId}");
				return responseMessage;
			} else {
				if(!(requestMessage.getOption() != null) || requestMessage.getOption().equals("") ) {
					requestMessage.setOption(basicInfoOption);					
				} 		
				if(requestMessage.getOption().contains(lastSessiontimeOption) && !((requestMessage.getIpAddress() != null) || (requestMessage.getMacAddress() != null))) {					
					responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
					responseMessage.setDetail("{ipAddress or macAddress is null}");
					return responseMessage;
				}
				optionList = Arrays.asList(requestMessage.getOption().toLowerCase().split("\\s*,\\s*"));
			}
			
			// 0 = fail, 1 = success, 2 = success_with_condition
			int compareResponse = 0;
			for(String option : optionList ) {				
				if(option.equals(basicInfoOption)) {
					responseMessage = egOperation.getBasicInfo(requestMessage, responseMessage);				
					if(responseMessage.getResponseCode().equals(Code.SUCCESS)) {
						compareResponse = 1;
					}
				}
			}
			for(String option : optionList ) {				
				if(option.equals(advanceInfoOption)) {
					responseMessage = egOperation.getAdvanceInfo(requestMessage, responseMessage);	
					if(responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 0) {
						compareResponse = 1;
					}
					if(!responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 1) {
						compareResponse = 2;
					}
				}
			}
			for(String option : optionList ) {				
				if(option.equals(hostInfoOption)) {
					responseMessage = egOperation.getHostInfo(requestMessage, responseMessage);			
					if(responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 0) {
						compareResponse = 1;
					}
					if(!responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 1) {
						compareResponse = 2;
					}
				}
				
			}
			for(String option : optionList ) {				
				if(option.equals(onlineStatusOption)) {
					responseMessage = egOperation.getOnlineStatus(requestMessage, responseMessage);		
					if(responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 0) {
						compareResponse = 1;
					}
					if(!responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 1) {
						compareResponse = 2;
					}
				}
				
			}
			for(String option : optionList ) {				
				if(option.equals(lastSessiontimeOption)) {
					responseMessage = egOperation.getLastSessionTime(requestMessage, responseMessage);	
					if(responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 0) {
						compareResponse = 1;
					}
					if(!responseMessage.getResponseCode().equals(Code.SUCCESS) && compareResponse == 1) {
						compareResponse = 2;
					}
				}
			}
			
			if(compareResponse == 2) {
				responseMessage.setResponseCode(Code.SUCCESS_WITH_CONDITION);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS_WITH_CONDITION));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getcpeinfo("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage wanSetup(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getInternetUsername())
					&& checkMandatory(requestMessage.getInternetPassword())
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, internetUsername, internetPassword, refId}");
				return responseMessage;
			} else {
				if(!(requestMessage.getOption() != null) || requestMessage.getOption().equals("") ) {
					requestMessage.setOption(mainOption);					
				} 				
			}
			
			responseMessage = egOperation.wanSetup(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wansetup("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage getWifiInfo(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		List<String> optionList = null;
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			}
			
			responseMessage = egOperation.getWifiInfo(requestMessage, responseMessage);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getwifiinfo("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage wifiSetup(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getWifiInfo() != null && checkMandatory(requestMessage.getWifiInfo().get(0).getIndex()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, wifiInfo [], refId}");
				return responseMessage;
			} 
			
			responseMessage = egOperation.wifiSetup(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wansetup("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
				
		return responseMessage;
	}

	@Override
	public ResponseMessage getParameterValues(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		List<String> optionList = null;
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getParamNameVec()!= null && checkMandatory(requestMessage.getParamNameVec().get(0).getItem()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, paramNameVec [], refId}");
				return responseMessage;
			}
			
			responseMessage = egOperation.getParameterValues(requestMessage, responseMessage);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getparameterValues("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}

	@Override
	public ResponseMessage setParameterValues(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& (requestMessage.getParameterValues() != null && checkMandatory(requestMessage.getParameterValues().get(0).getKey()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, parameterValues [], refId}");
				return responseMessage;
			} 
			
			responseMessage = egOperation.setParameterValues(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("setParameterValues("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
				
		return responseMessage;
	}

	@Override
	public ResponseMessage upgradeFirmware(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()) && checkMandatory(requestMessage.getFirmwareVersion()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId, version}");
				return responseMessage;
			} 
			
			responseMessage = egOperation.upgradeFirmware(requestMessage, responseMessage);					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("upgradefirmware("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		return responseMessage;
	}
	
	@Override
	public ResponseMessage reboot(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			}
			
			responseMessage = egOperation.reboot(requestMessage, responseMessage);					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("reboot("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		return responseMessage;
	}

	@Override
	public ResponseMessage factoryReset(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			}
			
			responseMessage = egOperation.factoryReset(requestMessage, responseMessage);					
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("factoryreset("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		return responseMessage;
	}

	@Override
	public ResponseMessage configFile(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		long start = System.currentTimeMillis();
		try {
			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()) && checkMandatory(requestMessage.getOption()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId, option}");
				return responseMessage;
			} else {
				// if option = restore then check missing configFileName
				if(requestMessage.getOption().equals(restoreOption)) {
					if(!checkMandatory(requestMessage.getConfigFileName())) {
						
						responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
						responseMessage.setDetail("{configFileName}");
						return responseMessage;						
					}
				}
			}
			
			String option = requestMessage.getOption();
			if(option.equals(listBackupOption)) {
				responseMessage = egOperation.getCFGList(requestMessage, responseMessage);					
			} else if(option.equals(restoreOption)) {
				responseMessage = egOperation.downloadCFGToDevice(requestMessage, responseMessage);	
			} else if(option.equals(backupOption)){
				responseMessage = egOperation.uploadCFG(requestMessage, responseMessage);
			} else {
				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{options does not match}");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("configfile("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		
		return responseMessage;
	}
	
	@Override
	public ResponseMessage checkVoIPProfile(RequestMessage requestMessage) {
		// TODO Auto-generated method stub
		ResponseMessage responseMessage = new ResponseMessage(EG);
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {			
			if (!( (checkMandatory(requestMessage.getFibreId()) || checkMandatory(requestMessage.getActivationId()))
					&& checkMandatory(requestMessage.getRefId()))) {

				responseMessage.setResponseCode(Code.MISSING_MADATORY_FIELD);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.MISSING_MADATORY_FIELD));
				responseMessage.setDetail("{fibreId|activationId, refId}");
				return responseMessage;
			} 
			
			responseMessage = egOperation.checkVoIPProfile(requestMessage, responseMessage);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("checkVoIPProfile("+requestMessage.getFibreId()+"): exception", e);
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
				
		return responseMessage;
	}
	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}
	
}
