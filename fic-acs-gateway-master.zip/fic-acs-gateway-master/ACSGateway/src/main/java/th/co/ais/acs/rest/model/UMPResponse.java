package th.co.ais.acs.rest.model;

public class UMPResponse {
	String lastSessionTime        = null;
	String lastEmptySessionTime   = null;
	String lastBootstrapTime      = null;
	String lastRebootTime         = null;
	String creationTime           = null;
	String ipAddress              = null;
	String serialNumber           = null;
	String oui                    = null;
	String modelName              = null;
	String hardwareVersion        = null;
	String softwareVersion        = null;
	String productClass           = null;
	String manufacturer           = null;
	String description            = null;
	String id                     = null;
	private UMPResponseProperties properties = null;
	
	public String getLastSessionTime() {
		return lastSessionTime;
	}
	public void setLastSessionTime(String lastSessionTime) {
		this.lastSessionTime = lastSessionTime;
	}
	public String getLastEmptySessionTime() {
		return lastEmptySessionTime;
	}
	public void setLastEmptySessionTime(String lastEmptySessionTime) {
		this.lastEmptySessionTime = lastEmptySessionTime;
	}
	public String getLastBootstrapTime() {
		return lastBootstrapTime;
	}
	public void setLastBootstrapTime(String lastBootstrapTime) {
		this.lastBootstrapTime = lastBootstrapTime;
	}
	public String getLastRebootTime() {
		return lastRebootTime;
	}
	public void setLastRebootTime(String lastRebootTime) {
		this.lastRebootTime = lastRebootTime;
	}
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getOui() {
		return oui;
	}
	public void setOui(String oui) {
		this.oui = oui;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getHardwareVersion() {
		return hardwareVersion;
	}
	public void setHardwareVersion(String hardwareVersion) {
		this.hardwareVersion = hardwareVersion;
	}
	public String getSoftwareVersion() {
		return softwareVersion;
	}
	public void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}
	public String getProductClass() {
		return productClass;
	}
	public void setProductClass(String productClass) {
		this.productClass = productClass;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public UMPResponseProperties getProperties() {
		return properties;
	}
	public void setProperties(UMPResponseProperties properties) {
		this.properties = properties;
	}
	
	
}
