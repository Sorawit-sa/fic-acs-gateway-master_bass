package th.co.ais.acs.rest.model;

public class ResponseDataHostInfo {
	
	String portNumber       = null;
	String active           = null;
	String hostName         = null;
	String interfaceType    = null;
	String ipAddress        = null;
	String layer2Interface   = null;
	String macAddress       = null;
	
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getInterfaceType() {
		return interfaceType;
	}
	public void setInterfaceType(String interfaceType) {
		this.interfaceType = interfaceType;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getLayer2Interface() {
		return layer2Interface;
	}
	public void setLayer2Interface(String layer2Interface) {
		this.layer2Interface = layer2Interface;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getPortNumber() {
		return portNumber;
	}
	public void setPortNumber(String portNumber) {
		this.portNumber = portNumber;
	}
	@Override
	public String toString() {
		return "ResponseDataHostInfo [portNumber=" + portNumber + ", active=" + active + ", hostName=" + hostName
				+ ", interfaceType=" + interfaceType + ", ipAddress=" + ipAddress + ", layer2Interface=" + layer2Interface
				+ ", macAddress=" + macAddress + "]";
	}

	

	
}
