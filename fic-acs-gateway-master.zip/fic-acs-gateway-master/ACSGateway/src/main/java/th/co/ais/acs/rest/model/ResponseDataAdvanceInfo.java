package th.co.ais.acs.rest.model;

public class ResponseDataAdvanceInfo {
	
	String  deviceId          = null;
	String  deviceType        = null;
	String  hardwareVersion   = null;
	String  macAddress        = null;
	String  manufacturer      = null;
	String  oui               = null;
	String  productClass      = null;
	String  ipAddress         = null;
	String  registerStatus    = null;
	String  softwareVersion   = null;
	String  onlineStatus      = null;
	String  ssidStatus        = null;
	String  ssidName          = null;
	String  lanStatus         = null;
	String  sipUsername1      = null;
	String  sipPassword1      = null;
	String  sipUsername2      = null;
	String  sipPassword2      = null;
	String  onuConnectionType = null;
	String  onuVoipIp    	  = null;
	String  onuSoftwareVersion    = null;
	String  cpeStatus    = null;
	
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getHardwareVersion() {
		return hardwareVersion;
	}
	public void setHardwareVersion(String hardwareVersion) {
		this.hardwareVersion = hardwareVersion;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getOui() {
		return oui;
	}
	public void setOui(String oui) {
		this.oui = oui;
	}
	public String getProductClass() {
		return productClass;
	}
	public void setProductClass(String productClass) {
		this.productClass = productClass;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getRegisterStatus() {
		return registerStatus;
	}
	public void setRegisterStatus(String registerStatus) {
		this.registerStatus = registerStatus;
	}
	public String getSoftwareVersion() {
		return softwareVersion;
	}
	public void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}
	public String getOnlineStatus() {
		return onlineStatus;
	}
	public void setOnlineStatus(String onlineStatus) {
		this.onlineStatus = onlineStatus;
	}
	public String getSsidStatus() {
		return ssidStatus;
	}
	public void setSsidStatus(String ssidStatus) {
		this.ssidStatus = ssidStatus;
	}
	public String getSsidName() {
		return ssidName;
	}
	public void setSsidName(String ssidName) {
		this.ssidName = ssidName;
	}
	public String getLanStatus() {
		return lanStatus;
	}
	public void setLanStatus(String lanStatus) {
		this.lanStatus = lanStatus;
	}
	public String getSipUsername1() {
		return sipUsername1;
	}
	public void setSipUsername1(String sipUsername1) {
		this.sipUsername1 = sipUsername1;
	}
	public String getSipPassword1() {
		return sipPassword1;
	}
	public void setSipPassword1(String sipPassword1) {
		this.sipPassword1 = sipPassword1;
	}
	public String getSipUsername2() {
		return sipUsername2;
	}
	public void setSipUsername2(String sipUsername2) {
		this.sipUsername2 = sipUsername2;
	}
	public String getSipPassword2() {
		return sipPassword2;
	}
	public void setSipPassword2(String sipPassword2) {
		this.sipPassword2 = sipPassword2;
	}
	public String getOnuConnectionType() {
		return onuConnectionType;
	}
	public void setOnuConnectionType(String onuConnectionType) {
		this.onuConnectionType = onuConnectionType;
	}
	public String getOnuVoipIp() {
		return onuVoipIp;
	}
	public void setOnuVoipIp(String onuVoipIp) {
		this.onuVoipIp = onuVoipIp;
	}
	public String getOnuSoftwareVersion() {
		return onuSoftwareVersion;
	}
	public void setOnuSoftwareVersion(String onuSoftwareVersion) {
		this.onuSoftwareVersion = onuSoftwareVersion;
	}
	public String getCpeStatus() {
		return cpeStatus;
	}
	public void setCpeStatus(String cpeStatus) {
		this.cpeStatus = cpeStatus;
	}
	@Override
	public String toString() {
		return "ResponseDataAdvanceInfo [deviceId=" + deviceId + ", deviceType=" + deviceType + ", hardwareVersion="
				+ hardwareVersion + ", macAddress=" + macAddress + ", manufacturer=" + manufacturer + ", oui=" + oui
				+ ", productClass=" + productClass + ", ipAddress=" + ipAddress + ", registerStatus=" + registerStatus
				+ ", softwareVersion=" + softwareVersion + ", onlineStatus=" + onlineStatus + ", ssidStatus="
				+ ssidStatus + ", ssidName=" + ssidName + ", lanStatus=" + lanStatus + ", sipUsername1=" + sipUsername1
				+ ", sipPassword1=" + sipPassword1 + ", sipUsername2=" + sipUsername2 + ", sipPassword2=" + sipPassword2
				+ ", onuConnectionType=" + onuConnectionType + ", onuVoipIp=" + onuVoipIp + ", onuSoftwareVersion="
				+ onuSoftwareVersion + ", cpeStatus=" + cpeStatus + "]";
	}


	

	
}
