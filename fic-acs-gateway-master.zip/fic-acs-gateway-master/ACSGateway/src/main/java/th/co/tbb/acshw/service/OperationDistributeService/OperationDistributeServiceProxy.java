package th.co.tbb.acshw.service.OperationDistributeService;

import th.co.tbb.acshw.model.OperationDistributeService.DelCpeInfo;
import th.co.tbb.acshw.model.OperationDistributeService.NorthQueryParaResult;
import th.co.tbb.acshw.model.OperationDistributeService.Order;
import th.co.tbb.acshw.model.OperationDistributeService.UserDetail;
import th.co.tbb.acshw.model.OperationDistributeService.UserIndex;

public class OperationDistributeServiceProxy implements OperationDistributeService {
  private String _endpoint = null;
  private OperationDistributeService operationDistributeService = null;
  
  public OperationDistributeServiceProxy() {
    _initOperationDistributeServiceProxy();
  }
  
  public OperationDistributeServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initOperationDistributeServiceProxy();
  }
  
  private void _initOperationDistributeServiceProxy() {
    try {
      operationDistributeService = (new OperationDistributeServiceServiceLocator()).getOperationDistributeService();
      if (operationDistributeService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)operationDistributeService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)operationDistributeService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (operationDistributeService != null)
      ((javax.xml.rpc.Stub)operationDistributeService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public OperationDistributeService getOperationDistributeService() {
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return operationDistributeService;
  }
  
  public int serviceInterface(int command, java.lang.String serviceCode, java.lang.String cpeMac, java.lang.String oltManufacturer, java.lang.String oltType, java.lang.String oltIP, int slotNo, int ponNo, java.lang.String onuId, java.lang.String areaCode, java.lang.String parameter) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return serviceInterface(command, serviceCode, cpeMac, oltManufacturer, oltType, oltIP, slotNo, ponNo, onuId, areaCode, parameter);
  }
  
  public int serviceChange(java.lang.String adAcount, java.lang.String LSHNo, java.lang.String orderType, java.lang.String newPassWord) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return serviceChange(adAcount, LSHNo, orderType, newPassWord);
  }
  
  public int dealOrder(Order order) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return dealOrder(order);
  }
  
  public java.lang.String sendOrder(java.lang.String theRequest) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return sendOrder(theRequest);
  }
  
  public int bindInterface(int command, java.lang.String cpeId, java.lang.String adAccounts, java.lang.String nasPortId, java.lang.String nasIP, java.lang.String areaNum, java.lang.String vlanId) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return bindInterface(command, cpeId, adAccounts, nasPortId, nasIP, areaNum, vlanId);
  }
  
  public int delCPE(DelCpeInfo delCpeInfo) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return delCPE(delCpeInfo);
  }
  
  public int delSingelCPE(java.lang.String strCPEID) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return delSingelCPE(strCPEID);
  }
  
  public int dealOrderWithReply(Order order, java.lang.String replyURL) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return dealOrderWithReply(order, replyURL);
  }
  
  public UserDetail[] queryUserDetail(int iParaType, java.lang.String value) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return queryUserDetail(iParaType, value);
  }
  
  public int bindInterface_pon(int command, java.lang.String cpeMac, java.lang.String adAccounts, java.lang.String nasPortId, java.lang.String nasIP, java.lang.String areaNum, java.lang.String userPhone) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return bindInterface_pon(command, cpeMac, adAccounts, nasPortId, nasIP, areaNum, userPhone);
  }
  
  public NorthQueryParaResult northQueryCPEPara(UserIndex user) throws java.rmi.RemoteException{
    if (operationDistributeService == null)
      _initOperationDistributeServiceProxy();
    return northQueryCPEPara(user);
  }  
  
}