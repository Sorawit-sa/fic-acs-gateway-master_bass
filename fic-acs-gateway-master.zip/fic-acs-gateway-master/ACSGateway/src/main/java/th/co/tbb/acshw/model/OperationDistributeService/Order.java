/**
 * Order.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.OperationDistributeService;

public class Order  implements java.io.Serializable {
    private java.lang.String DSLMPort;

    private java.lang.String accessNo;

    private java.lang.String ad_account;

    private java.lang.String ad_password;

    private java.lang.String ad_userid;

    private java.lang.String ad_userpass;

    private java.lang.String area_code;

    private java.lang.String cardKey;

    private java.lang.String cardNo;

    private java.lang.String contact_person;

    private java.lang.String deviceMac;

    private java.lang.String deviceType;

    private java.lang.String device_ID;

    private java.lang.String device_WAN;

    private java.lang.String device_wan;

    private java.lang.String downstreamMaxRate;

    private java.lang.String dslmport;

    private java.lang.String executeNo;

    private java.lang.String finalorderDocument;

    private java.lang.String home_assist;

    private java.lang.String oltIP;

    private java.lang.String oltManufacturer;

    private java.lang.String oltType;

    private java.lang.String onuId;

    private java.lang.String onu_Port;

    private java.lang.String orderDocument;

    private java.lang.String order_LSH;

    private java.lang.String order_No;

    private java.lang.String order_Remark;

    private java.lang.String order_Time;

    private java.lang.String order_Type;

    private java.lang.String order_kind;

    private java.lang.String order_status;

    private java.lang.String ponNo;

    private java.lang.String privatePara;

    private java.lang.String protocolType;

    private java.lang.String pvc;

    private java.lang.String replyFlag;

    private java.lang.String replyOrderFlag;

    private java.lang.String replyURL;

    private java.lang.String serviceType;

    private java.lang.String service_code;

    private java.lang.String slotNo;

    private java.lang.String strIptvAccount;

    private java.lang.String strReplyOrderFlag;

    private java.lang.String strReplyUrlFlag;

    private java.lang.String subAreaNum;

    private java.lang.String subArea_code;

    private java.lang.String time_limit;

    private java.lang.String uplink_type;

    private java.lang.String upstreamMaxRate;

    private java.lang.String userBrasIP;

    private java.lang.String userCard;

    private java.lang.String userCustom;

    private java.lang.String userEmail;

    private java.lang.String userPhone;

    private java.lang.String userPort;

    private java.lang.String user_Type;

    private java.lang.String user_address;

    private java.lang.String user_name;

    private java.lang.String vector_argues;

    private java.lang.String ver;

    private java.lang.String vlanID;

    public Order() {
    }

    public Order(
           java.lang.String DSLMPort,
           java.lang.String accessNo,
           java.lang.String ad_account,
           java.lang.String ad_password,
           java.lang.String ad_userid,
           java.lang.String ad_userpass,
           java.lang.String area_code,
           java.lang.String cardKey,
           java.lang.String cardNo,
           java.lang.String contact_person,
           java.lang.String deviceMac,
           java.lang.String deviceType,
           java.lang.String device_ID,
           java.lang.String device_WAN,
           java.lang.String device_wan,
           java.lang.String downstreamMaxRate,
           java.lang.String dslmport,
           java.lang.String executeNo,
           java.lang.String finalorderDocument,
           java.lang.String home_assist,
           java.lang.String oltIP,
           java.lang.String oltManufacturer,
           java.lang.String oltType,
           java.lang.String onuId,
           java.lang.String onu_Port,
           java.lang.String orderDocument,
           java.lang.String order_LSH,
           java.lang.String order_No,
           java.lang.String order_Remark,
           java.lang.String order_Time,
           java.lang.String order_Type,
           java.lang.String order_kind,
           java.lang.String order_status,
           java.lang.String ponNo,
           java.lang.String privatePara,
           java.lang.String protocolType,
           java.lang.String pvc,
           java.lang.String replyFlag,
           java.lang.String replyOrderFlag,
           java.lang.String replyURL,
           java.lang.String serviceType,
           java.lang.String service_code,
           java.lang.String slotNo,
           java.lang.String strIptvAccount,
           java.lang.String strReplyOrderFlag,
           java.lang.String strReplyUrlFlag,
           java.lang.String subAreaNum,
           java.lang.String subArea_code,
           java.lang.String time_limit,
           java.lang.String uplink_type,
           java.lang.String upstreamMaxRate,
           java.lang.String userBrasIP,
           java.lang.String userCard,
           java.lang.String userCustom,
           java.lang.String userEmail,
           java.lang.String userPhone,
           java.lang.String userPort,
           java.lang.String user_Type,
           java.lang.String user_address,
           java.lang.String user_name,
           java.lang.String vector_argues,
           java.lang.String ver,
           java.lang.String vlanID) {
           this.DSLMPort = DSLMPort;
           this.accessNo = accessNo;
           this.ad_account = ad_account;
           this.ad_password = ad_password;
           this.ad_userid = ad_userid;
           this.ad_userpass = ad_userpass;
           this.area_code = area_code;
           this.cardKey = cardKey;
           this.cardNo = cardNo;
           this.contact_person = contact_person;
           this.deviceMac = deviceMac;
           this.deviceType = deviceType;
           this.device_ID = device_ID;
           this.device_WAN = device_WAN;
           this.device_wan = device_wan;
           this.downstreamMaxRate = downstreamMaxRate;
           this.dslmport = dslmport;
           this.executeNo = executeNo;
           this.finalorderDocument = finalorderDocument;
           this.home_assist = home_assist;
           this.oltIP = oltIP;
           this.oltManufacturer = oltManufacturer;
           this.oltType = oltType;
           this.onuId = onuId;
           this.onu_Port = onu_Port;
           this.orderDocument = orderDocument;
           this.order_LSH = order_LSH;
           this.order_No = order_No;
           this.order_Remark = order_Remark;
           this.order_Time = order_Time;
           this.order_Type = order_Type;
           this.order_kind = order_kind;
           this.order_status = order_status;
           this.ponNo = ponNo;
           this.privatePara = privatePara;
           this.protocolType = protocolType;
           this.pvc = pvc;
           this.replyFlag = replyFlag;
           this.replyOrderFlag = replyOrderFlag;
           this.replyURL = replyURL;
           this.serviceType = serviceType;
           this.service_code = service_code;
           this.slotNo = slotNo;
           this.strIptvAccount = strIptvAccount;
           this.strReplyOrderFlag = strReplyOrderFlag;
           this.strReplyUrlFlag = strReplyUrlFlag;
           this.subAreaNum = subAreaNum;
           this.subArea_code = subArea_code;
           this.time_limit = time_limit;
           this.uplink_type = uplink_type;
           this.upstreamMaxRate = upstreamMaxRate;
           this.userBrasIP = userBrasIP;
           this.userCard = userCard;
           this.userCustom = userCustom;
           this.userEmail = userEmail;
           this.userPhone = userPhone;
           this.userPort = userPort;
           this.user_Type = user_Type;
           this.user_address = user_address;
           this.user_name = user_name;
           this.vector_argues = vector_argues;
           this.ver = ver;
           this.vlanID = vlanID;
    }


    /**
     * Gets the DSLMPort value for this Order.
     * 
     * @return DSLMPort
     */
    public java.lang.String getDSLMPort() {
        return DSLMPort;
    }


    /**
     * Sets the DSLMPort value for this Order.
     * 
     * @param DSLMPort
     */
    public void setDSLMPort(java.lang.String DSLMPort) {
        this.DSLMPort = DSLMPort;
    }


    /**
     * Gets the accessNo value for this Order.
     * 
     * @return accessNo
     */
    public java.lang.String getAccessNo() {
        return accessNo;
    }


    /**
     * Sets the accessNo value for this Order.
     * 
     * @param accessNo
     */
    public void setAccessNo(java.lang.String accessNo) {
        this.accessNo = accessNo;
    }


    /**
     * Gets the ad_account value for this Order.
     * 
     * @return ad_account
     */
    public java.lang.String getAd_account() {
        return ad_account;
    }


    /**
     * Sets the ad_account value for this Order.
     * 
     * @param ad_account
     */
    public void setAd_account(java.lang.String ad_account) {
        this.ad_account = ad_account;
    }


    /**
     * Gets the ad_password value for this Order.
     * 
     * @return ad_password
     */
    public java.lang.String getAd_password() {
        return ad_password;
    }


    /**
     * Sets the ad_password value for this Order.
     * 
     * @param ad_password
     */
    public void setAd_password(java.lang.String ad_password) {
        this.ad_password = ad_password;
    }


    /**
     * Gets the ad_userid value for this Order.
     * 
     * @return ad_userid
     */
    public java.lang.String getAd_userid() {
        return ad_userid;
    }


    /**
     * Sets the ad_userid value for this Order.
     * 
     * @param ad_userid
     */
    public void setAd_userid(java.lang.String ad_userid) {
        this.ad_userid = ad_userid;
    }


    /**
     * Gets the ad_userpass value for this Order.
     * 
     * @return ad_userpass
     */
    public java.lang.String getAd_userpass() {
        return ad_userpass;
    }


    /**
     * Sets the ad_userpass value for this Order.
     * 
     * @param ad_userpass
     */
    public void setAd_userpass(java.lang.String ad_userpass) {
        this.ad_userpass = ad_userpass;
    }


    /**
     * Gets the area_code value for this Order.
     * 
     * @return area_code
     */
    public java.lang.String getArea_code() {
        return area_code;
    }


    /**
     * Sets the area_code value for this Order.
     * 
     * @param area_code
     */
    public void setArea_code(java.lang.String area_code) {
        this.area_code = area_code;
    }


    /**
     * Gets the cardKey value for this Order.
     * 
     * @return cardKey
     */
    public java.lang.String getCardKey() {
        return cardKey;
    }


    /**
     * Sets the cardKey value for this Order.
     * 
     * @param cardKey
     */
    public void setCardKey(java.lang.String cardKey) {
        this.cardKey = cardKey;
    }


    /**
     * Gets the cardNo value for this Order.
     * 
     * @return cardNo
     */
    public java.lang.String getCardNo() {
        return cardNo;
    }


    /**
     * Sets the cardNo value for this Order.
     * 
     * @param cardNo
     */
    public void setCardNo(java.lang.String cardNo) {
        this.cardNo = cardNo;
    }


    /**
     * Gets the contact_person value for this Order.
     * 
     * @return contact_person
     */
    public java.lang.String getContact_person() {
        return contact_person;
    }


    /**
     * Sets the contact_person value for this Order.
     * 
     * @param contact_person
     */
    public void setContact_person(java.lang.String contact_person) {
        this.contact_person = contact_person;
    }


    /**
     * Gets the deviceMac value for this Order.
     * 
     * @return deviceMac
     */
    public java.lang.String getDeviceMac() {
        return deviceMac;
    }


    /**
     * Sets the deviceMac value for this Order.
     * 
     * @param deviceMac
     */
    public void setDeviceMac(java.lang.String deviceMac) {
        this.deviceMac = deviceMac;
    }


    /**
     * Gets the deviceType value for this Order.
     * 
     * @return deviceType
     */
    public java.lang.String getDeviceType() {
        return deviceType;
    }


    /**
     * Sets the deviceType value for this Order.
     * 
     * @param deviceType
     */
    public void setDeviceType(java.lang.String deviceType) {
        this.deviceType = deviceType;
    }


    /**
     * Gets the device_ID value for this Order.
     * 
     * @return device_ID
     */
    public java.lang.String getDevice_ID() {
        return device_ID;
    }


    /**
     * Sets the device_ID value for this Order.
     * 
     * @param device_ID
     */
    public void setDevice_ID(java.lang.String device_ID) {
        this.device_ID = device_ID;
    }


    /**
     * Gets the device_WAN value for this Order.
     * 
     * @return device_WAN
     */
    public java.lang.String getDevice_WAN() {
        return device_WAN;
    }


    /**
     * Sets the device_WAN value for this Order.
     * 
     * @param device_WAN
     */
    public void setDevice_WAN(java.lang.String device_WAN) {
        this.device_WAN = device_WAN;
    }


    /**
     * Gets the device_wan value for this Order.
     * 
     * @return device_wan
     */
    public java.lang.String getDevice_wan() {
        return device_wan;
    }


    /**
     * Sets the device_wan value for this Order.
     * 
     * @param device_wan
     */
    public void setDevice_wan(java.lang.String device_wan) {
        this.device_wan = device_wan;
    }


    /**
     * Gets the downstreamMaxRate value for this Order.
     * 
     * @return downstreamMaxRate
     */
    public java.lang.String getDownstreamMaxRate() {
        return downstreamMaxRate;
    }


    /**
     * Sets the downstreamMaxRate value for this Order.
     * 
     * @param downstreamMaxRate
     */
    public void setDownstreamMaxRate(java.lang.String downstreamMaxRate) {
        this.downstreamMaxRate = downstreamMaxRate;
    }


    /**
     * Gets the dslmport value for this Order.
     * 
     * @return dslmport
     */
    public java.lang.String getDslmport() {
        return dslmport;
    }


    /**
     * Sets the dslmport value for this Order.
     * 
     * @param dslmport
     */
    public void setDslmport(java.lang.String dslmport) {
        this.dslmport = dslmport;
    }


    /**
     * Gets the executeNo value for this Order.
     * 
     * @return executeNo
     */
    public java.lang.String getExecuteNo() {
        return executeNo;
    }


    /**
     * Sets the executeNo value for this Order.
     * 
     * @param executeNo
     */
    public void setExecuteNo(java.lang.String executeNo) {
        this.executeNo = executeNo;
    }


    /**
     * Gets the finalorderDocument value for this Order.
     * 
     * @return finalorderDocument
     */
    public java.lang.String getFinalorderDocument() {
        return finalorderDocument;
    }


    /**
     * Sets the finalorderDocument value for this Order.
     * 
     * @param finalorderDocument
     */
    public void setFinalorderDocument(java.lang.String finalorderDocument) {
        this.finalorderDocument = finalorderDocument;
    }


    /**
     * Gets the home_assist value for this Order.
     * 
     * @return home_assist
     */
    public java.lang.String getHome_assist() {
        return home_assist;
    }


    /**
     * Sets the home_assist value for this Order.
     * 
     * @param home_assist
     */
    public void setHome_assist(java.lang.String home_assist) {
        this.home_assist = home_assist;
    }


    /**
     * Gets the oltIP value for this Order.
     * 
     * @return oltIP
     */
    public java.lang.String getOltIP() {
        return oltIP;
    }


    /**
     * Sets the oltIP value for this Order.
     * 
     * @param oltIP
     */
    public void setOltIP(java.lang.String oltIP) {
        this.oltIP = oltIP;
    }


    /**
     * Gets the oltManufacturer value for this Order.
     * 
     * @return oltManufacturer
     */
    public java.lang.String getOltManufacturer() {
        return oltManufacturer;
    }


    /**
     * Sets the oltManufacturer value for this Order.
     * 
     * @param oltManufacturer
     */
    public void setOltManufacturer(java.lang.String oltManufacturer) {
        this.oltManufacturer = oltManufacturer;
    }


    /**
     * Gets the oltType value for this Order.
     * 
     * @return oltType
     */
    public java.lang.String getOltType() {
        return oltType;
    }


    /**
     * Sets the oltType value for this Order.
     * 
     * @param oltType
     */
    public void setOltType(java.lang.String oltType) {
        this.oltType = oltType;
    }


    /**
     * Gets the onuId value for this Order.
     * 
     * @return onuId
     */
    public java.lang.String getOnuId() {
        return onuId;
    }


    /**
     * Sets the onuId value for this Order.
     * 
     * @param onuId
     */
    public void setOnuId(java.lang.String onuId) {
        this.onuId = onuId;
    }


    /**
     * Gets the onu_Port value for this Order.
     * 
     * @return onu_Port
     */
    public java.lang.String getOnu_Port() {
        return onu_Port;
    }


    /**
     * Sets the onu_Port value for this Order.
     * 
     * @param onu_Port
     */
    public void setOnu_Port(java.lang.String onu_Port) {
        this.onu_Port = onu_Port;
    }


    /**
     * Gets the orderDocument value for this Order.
     * 
     * @return orderDocument
     */
    public java.lang.String getOrderDocument() {
        return orderDocument;
    }


    /**
     * Sets the orderDocument value for this Order.
     * 
     * @param orderDocument
     */
    public void setOrderDocument(java.lang.String orderDocument) {
        this.orderDocument = orderDocument;
    }


    /**
     * Gets the order_LSH value for this Order.
     * 
     * @return order_LSH
     */
    public java.lang.String getOrder_LSH() {
        return order_LSH;
    }


    /**
     * Sets the order_LSH value for this Order.
     * 
     * @param order_LSH
     */
    public void setOrder_LSH(java.lang.String order_LSH) {
        this.order_LSH = order_LSH;
    }


    /**
     * Gets the order_No value for this Order.
     * 
     * @return order_No
     */
    public java.lang.String getOrder_No() {
        return order_No;
    }


    /**
     * Sets the order_No value for this Order.
     * 
     * @param order_No
     */
    public void setOrder_No(java.lang.String order_No) {
        this.order_No = order_No;
    }


    /**
     * Gets the order_Remark value for this Order.
     * 
     * @return order_Remark
     */
    public java.lang.String getOrder_Remark() {
        return order_Remark;
    }


    /**
     * Sets the order_Remark value for this Order.
     * 
     * @param order_Remark
     */
    public void setOrder_Remark(java.lang.String order_Remark) {
        this.order_Remark = order_Remark;
    }


    /**
     * Gets the order_Time value for this Order.
     * 
     * @return order_Time
     */
    public java.lang.String getOrder_Time() {
        return order_Time;
    }


    /**
     * Sets the order_Time value for this Order.
     * 
     * @param order_Time
     */
    public void setOrder_Time(java.lang.String order_Time) {
        this.order_Time = order_Time;
    }


    /**
     * Gets the order_Type value for this Order.
     * 
     * @return order_Type
     */
    public java.lang.String getOrder_Type() {
        return order_Type;
    }


    /**
     * Sets the order_Type value for this Order.
     * 
     * @param order_Type
     */
    public void setOrder_Type(java.lang.String order_Type) {
        this.order_Type = order_Type;
    }


    /**
     * Gets the order_kind value for this Order.
     * 
     * @return order_kind
     */
    public java.lang.String getOrder_kind() {
        return order_kind;
    }


    /**
     * Sets the order_kind value for this Order.
     * 
     * @param order_kind
     */
    public void setOrder_kind(java.lang.String order_kind) {
        this.order_kind = order_kind;
    }


    /**
     * Gets the order_status value for this Order.
     * 
     * @return order_status
     */
    public java.lang.String getOrder_status() {
        return order_status;
    }


    /**
     * Sets the order_status value for this Order.
     * 
     * @param order_status
     */
    public void setOrder_status(java.lang.String order_status) {
        this.order_status = order_status;
    }


    /**
     * Gets the ponNo value for this Order.
     * 
     * @return ponNo
     */
    public java.lang.String getPonNo() {
        return ponNo;
    }


    /**
     * Sets the ponNo value for this Order.
     * 
     * @param ponNo
     */
    public void setPonNo(java.lang.String ponNo) {
        this.ponNo = ponNo;
    }


    /**
     * Gets the privatePara value for this Order.
     * 
     * @return privatePara
     */
    public java.lang.String getPrivatePara() {
        return privatePara;
    }


    /**
     * Sets the privatePara value for this Order.
     * 
     * @param privatePara
     */
    public void setPrivatePara(java.lang.String privatePara) {
        this.privatePara = privatePara;
    }


    /**
     * Gets the protocolType value for this Order.
     * 
     * @return protocolType
     */
    public java.lang.String getProtocolType() {
        return protocolType;
    }


    /**
     * Sets the protocolType value for this Order.
     * 
     * @param protocolType
     */
    public void setProtocolType(java.lang.String protocolType) {
        this.protocolType = protocolType;
    }


    /**
     * Gets the pvc value for this Order.
     * 
     * @return pvc
     */
    public java.lang.String getPvc() {
        return pvc;
    }


    /**
     * Sets the pvc value for this Order.
     * 
     * @param pvc
     */
    public void setPvc(java.lang.String pvc) {
        this.pvc = pvc;
    }


    /**
     * Gets the replyFlag value for this Order.
     * 
     * @return replyFlag
     */
    public java.lang.String getReplyFlag() {
        return replyFlag;
    }


    /**
     * Sets the replyFlag value for this Order.
     * 
     * @param replyFlag
     */
    public void setReplyFlag(java.lang.String replyFlag) {
        this.replyFlag = replyFlag;
    }


    /**
     * Gets the replyOrderFlag value for this Order.
     * 
     * @return replyOrderFlag
     */
    public java.lang.String getReplyOrderFlag() {
        return replyOrderFlag;
    }


    /**
     * Sets the replyOrderFlag value for this Order.
     * 
     * @param replyOrderFlag
     */
    public void setReplyOrderFlag(java.lang.String replyOrderFlag) {
        this.replyOrderFlag = replyOrderFlag;
    }


    /**
     * Gets the replyURL value for this Order.
     * 
     * @return replyURL
     */
    public java.lang.String getReplyURL() {
        return replyURL;
    }


    /**
     * Sets the replyURL value for this Order.
     * 
     * @param replyURL
     */
    public void setReplyURL(java.lang.String replyURL) {
        this.replyURL = replyURL;
    }


    /**
     * Gets the serviceType value for this Order.
     * 
     * @return serviceType
     */
    public java.lang.String getServiceType() {
        return serviceType;
    }


    /**
     * Sets the serviceType value for this Order.
     * 
     * @param serviceType
     */
    public void setServiceType(java.lang.String serviceType) {
        this.serviceType = serviceType;
    }


    /**
     * Gets the service_code value for this Order.
     * 
     * @return service_code
     */
    public java.lang.String getService_code() {
        return service_code;
    }


    /**
     * Sets the service_code value for this Order.
     * 
     * @param service_code
     */
    public void setService_code(java.lang.String service_code) {
        this.service_code = service_code;
    }


    /**
     * Gets the slotNo value for this Order.
     * 
     * @return slotNo
     */
    public java.lang.String getSlotNo() {
        return slotNo;
    }


    /**
     * Sets the slotNo value for this Order.
     * 
     * @param slotNo
     */
    public void setSlotNo(java.lang.String slotNo) {
        this.slotNo = slotNo;
    }


    /**
     * Gets the strIptvAccount value for this Order.
     * 
     * @return strIptvAccount
     */
    public java.lang.String getStrIptvAccount() {
        return strIptvAccount;
    }


    /**
     * Sets the strIptvAccount value for this Order.
     * 
     * @param strIptvAccount
     */
    public void setStrIptvAccount(java.lang.String strIptvAccount) {
        this.strIptvAccount = strIptvAccount;
    }


    /**
     * Gets the strReplyOrderFlag value for this Order.
     * 
     * @return strReplyOrderFlag
     */
    public java.lang.String getStrReplyOrderFlag() {
        return strReplyOrderFlag;
    }


    /**
     * Sets the strReplyOrderFlag value for this Order.
     * 
     * @param strReplyOrderFlag
     */
    public void setStrReplyOrderFlag(java.lang.String strReplyOrderFlag) {
        this.strReplyOrderFlag = strReplyOrderFlag;
    }


    /**
     * Gets the strReplyUrlFlag value for this Order.
     * 
     * @return strReplyUrlFlag
     */
    public java.lang.String getStrReplyUrlFlag() {
        return strReplyUrlFlag;
    }


    /**
     * Sets the strReplyUrlFlag value for this Order.
     * 
     * @param strReplyUrlFlag
     */
    public void setStrReplyUrlFlag(java.lang.String strReplyUrlFlag) {
        this.strReplyUrlFlag = strReplyUrlFlag;
    }


    /**
     * Gets the subAreaNum value for this Order.
     * 
     * @return subAreaNum
     */
    public java.lang.String getSubAreaNum() {
        return subAreaNum;
    }


    /**
     * Sets the subAreaNum value for this Order.
     * 
     * @param subAreaNum
     */
    public void setSubAreaNum(java.lang.String subAreaNum) {
        this.subAreaNum = subAreaNum;
    }


    /**
     * Gets the subArea_code value for this Order.
     * 
     * @return subArea_code
     */
    public java.lang.String getSubArea_code() {
        return subArea_code;
    }


    /**
     * Sets the subArea_code value for this Order.
     * 
     * @param subArea_code
     */
    public void setSubArea_code(java.lang.String subArea_code) {
        this.subArea_code = subArea_code;
    }


    /**
     * Gets the time_limit value for this Order.
     * 
     * @return time_limit
     */
    public java.lang.String getTime_limit() {
        return time_limit;
    }


    /**
     * Sets the time_limit value for this Order.
     * 
     * @param time_limit
     */
    public void setTime_limit(java.lang.String time_limit) {
        this.time_limit = time_limit;
    }


    /**
     * Gets the uplink_type value for this Order.
     * 
     * @return uplink_type
     */
    public java.lang.String getUplink_type() {
        return uplink_type;
    }


    /**
     * Sets the uplink_type value for this Order.
     * 
     * @param uplink_type
     */
    public void setUplink_type(java.lang.String uplink_type) {
        this.uplink_type = uplink_type;
    }


    /**
     * Gets the upstreamMaxRate value for this Order.
     * 
     * @return upstreamMaxRate
     */
    public java.lang.String getUpstreamMaxRate() {
        return upstreamMaxRate;
    }


    /**
     * Sets the upstreamMaxRate value for this Order.
     * 
     * @param upstreamMaxRate
     */
    public void setUpstreamMaxRate(java.lang.String upstreamMaxRate) {
        this.upstreamMaxRate = upstreamMaxRate;
    }


    /**
     * Gets the userBrasIP value for this Order.
     * 
     * @return userBrasIP
     */
    public java.lang.String getUserBrasIP() {
        return userBrasIP;
    }


    /**
     * Sets the userBrasIP value for this Order.
     * 
     * @param userBrasIP
     */
    public void setUserBrasIP(java.lang.String userBrasIP) {
        this.userBrasIP = userBrasIP;
    }


    /**
     * Gets the userCard value for this Order.
     * 
     * @return userCard
     */
    public java.lang.String getUserCard() {
        return userCard;
    }


    /**
     * Sets the userCard value for this Order.
     * 
     * @param userCard
     */
    public void setUserCard(java.lang.String userCard) {
        this.userCard = userCard;
    }


    /**
     * Gets the userCustom value for this Order.
     * 
     * @return userCustom
     */
    public java.lang.String getUserCustom() {
        return userCustom;
    }


    /**
     * Sets the userCustom value for this Order.
     * 
     * @param userCustom
     */
    public void setUserCustom(java.lang.String userCustom) {
        this.userCustom = userCustom;
    }


    /**
     * Gets the userEmail value for this Order.
     * 
     * @return userEmail
     */
    public java.lang.String getUserEmail() {
        return userEmail;
    }


    /**
     * Sets the userEmail value for this Order.
     * 
     * @param userEmail
     */
    public void setUserEmail(java.lang.String userEmail) {
        this.userEmail = userEmail;
    }


    /**
     * Gets the userPhone value for this Order.
     * 
     * @return userPhone
     */
    public java.lang.String getUserPhone() {
        return userPhone;
    }


    /**
     * Sets the userPhone value for this Order.
     * 
     * @param userPhone
     */
    public void setUserPhone(java.lang.String userPhone) {
        this.userPhone = userPhone;
    }


    /**
     * Gets the userPort value for this Order.
     * 
     * @return userPort
     */
    public java.lang.String getUserPort() {
        return userPort;
    }


    /**
     * Sets the userPort value for this Order.
     * 
     * @param userPort
     */
    public void setUserPort(java.lang.String userPort) {
        this.userPort = userPort;
    }


    /**
     * Gets the user_Type value for this Order.
     * 
     * @return user_Type
     */
    public java.lang.String getUser_Type() {
        return user_Type;
    }


    /**
     * Sets the user_Type value for this Order.
     * 
     * @param user_Type
     */
    public void setUser_Type(java.lang.String user_Type) {
        this.user_Type = user_Type;
    }


    /**
     * Gets the user_address value for this Order.
     * 
     * @return user_address
     */
    public java.lang.String getUser_address() {
        return user_address;
    }


    /**
     * Sets the user_address value for this Order.
     * 
     * @param user_address
     */
    public void setUser_address(java.lang.String user_address) {
        this.user_address = user_address;
    }


    /**
     * Gets the user_name value for this Order.
     * 
     * @return user_name
     */
    public java.lang.String getUser_name() {
        return user_name;
    }


    /**
     * Sets the user_name value for this Order.
     * 
     * @param user_name
     */
    public void setUser_name(java.lang.String user_name) {
        this.user_name = user_name;
    }


    /**
     * Gets the vector_argues value for this Order.
     * 
     * @return vector_argues
     */
    public java.lang.String getVector_argues() {
        return vector_argues;
    }


    /**
     * Sets the vector_argues value for this Order.
     * 
     * @param vector_argues
     */
    public void setVector_argues(java.lang.String vector_argues) {
        this.vector_argues = vector_argues;
    }


    /**
     * Gets the ver value for this Order.
     * 
     * @return ver
     */
    public java.lang.String getVer() {
        return ver;
    }


    /**
     * Sets the ver value for this Order.
     * 
     * @param ver
     */
    public void setVer(java.lang.String ver) {
        this.ver = ver;
    }


    /**
     * Gets the vlanID value for this Order.
     * 
     * @return vlanID
     */
    public java.lang.String getVlanID() {
        return vlanID;
    }


    /**
     * Sets the vlanID value for this Order.
     * 
     * @param vlanID
     */
    public void setVlanID(java.lang.String vlanID) {
        this.vlanID = vlanID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Order)) return false;
        Order other = (Order) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.DSLMPort==null && other.getDSLMPort()==null) || 
             (this.DSLMPort!=null &&
              this.DSLMPort.equals(other.getDSLMPort()))) &&
            ((this.accessNo==null && other.getAccessNo()==null) || 
             (this.accessNo!=null &&
              this.accessNo.equals(other.getAccessNo()))) &&
            ((this.ad_account==null && other.getAd_account()==null) || 
             (this.ad_account!=null &&
              this.ad_account.equals(other.getAd_account()))) &&
            ((this.ad_password==null && other.getAd_password()==null) || 
             (this.ad_password!=null &&
              this.ad_password.equals(other.getAd_password()))) &&
            ((this.ad_userid==null && other.getAd_userid()==null) || 
             (this.ad_userid!=null &&
              this.ad_userid.equals(other.getAd_userid()))) &&
            ((this.ad_userpass==null && other.getAd_userpass()==null) || 
             (this.ad_userpass!=null &&
              this.ad_userpass.equals(other.getAd_userpass()))) &&
            ((this.area_code==null && other.getArea_code()==null) || 
             (this.area_code!=null &&
              this.area_code.equals(other.getArea_code()))) &&
            ((this.cardKey==null && other.getCardKey()==null) || 
             (this.cardKey!=null &&
              this.cardKey.equals(other.getCardKey()))) &&
            ((this.cardNo==null && other.getCardNo()==null) || 
             (this.cardNo!=null &&
              this.cardNo.equals(other.getCardNo()))) &&
            ((this.contact_person==null && other.getContact_person()==null) || 
             (this.contact_person!=null &&
              this.contact_person.equals(other.getContact_person()))) &&
            ((this.deviceMac==null && other.getDeviceMac()==null) || 
             (this.deviceMac!=null &&
              this.deviceMac.equals(other.getDeviceMac()))) &&
            ((this.deviceType==null && other.getDeviceType()==null) || 
             (this.deviceType!=null &&
              this.deviceType.equals(other.getDeviceType()))) &&
            ((this.device_ID==null && other.getDevice_ID()==null) || 
             (this.device_ID!=null &&
              this.device_ID.equals(other.getDevice_ID()))) &&
            ((this.device_WAN==null && other.getDevice_WAN()==null) || 
             (this.device_WAN!=null &&
              this.device_WAN.equals(other.getDevice_WAN()))) &&
            ((this.device_wan==null && other.getDevice_wan()==null) || 
             (this.device_wan!=null &&
              this.device_wan.equals(other.getDevice_wan()))) &&
            ((this.downstreamMaxRate==null && other.getDownstreamMaxRate()==null) || 
             (this.downstreamMaxRate!=null &&
              this.downstreamMaxRate.equals(other.getDownstreamMaxRate()))) &&
            ((this.dslmport==null && other.getDslmport()==null) || 
             (this.dslmport!=null &&
              this.dslmport.equals(other.getDslmport()))) &&
            ((this.executeNo==null && other.getExecuteNo()==null) || 
             (this.executeNo!=null &&
              this.executeNo.equals(other.getExecuteNo()))) &&
            ((this.finalorderDocument==null && other.getFinalorderDocument()==null) || 
             (this.finalorderDocument!=null &&
              this.finalorderDocument.equals(other.getFinalorderDocument()))) &&
            ((this.home_assist==null && other.getHome_assist()==null) || 
             (this.home_assist!=null &&
              this.home_assist.equals(other.getHome_assist()))) &&
            ((this.oltIP==null && other.getOltIP()==null) || 
             (this.oltIP!=null &&
              this.oltIP.equals(other.getOltIP()))) &&
            ((this.oltManufacturer==null && other.getOltManufacturer()==null) || 
             (this.oltManufacturer!=null &&
              this.oltManufacturer.equals(other.getOltManufacturer()))) &&
            ((this.oltType==null && other.getOltType()==null) || 
             (this.oltType!=null &&
              this.oltType.equals(other.getOltType()))) &&
            ((this.onuId==null && other.getOnuId()==null) || 
             (this.onuId!=null &&
              this.onuId.equals(other.getOnuId()))) &&
            ((this.onu_Port==null && other.getOnu_Port()==null) || 
             (this.onu_Port!=null &&
              this.onu_Port.equals(other.getOnu_Port()))) &&
            ((this.orderDocument==null && other.getOrderDocument()==null) || 
             (this.orderDocument!=null &&
              this.orderDocument.equals(other.getOrderDocument()))) &&
            ((this.order_LSH==null && other.getOrder_LSH()==null) || 
             (this.order_LSH!=null &&
              this.order_LSH.equals(other.getOrder_LSH()))) &&
            ((this.order_No==null && other.getOrder_No()==null) || 
             (this.order_No!=null &&
              this.order_No.equals(other.getOrder_No()))) &&
            ((this.order_Remark==null && other.getOrder_Remark()==null) || 
             (this.order_Remark!=null &&
              this.order_Remark.equals(other.getOrder_Remark()))) &&
            ((this.order_Time==null && other.getOrder_Time()==null) || 
             (this.order_Time!=null &&
              this.order_Time.equals(other.getOrder_Time()))) &&
            ((this.order_Type==null && other.getOrder_Type()==null) || 
             (this.order_Type!=null &&
              this.order_Type.equals(other.getOrder_Type()))) &&
            ((this.order_kind==null && other.getOrder_kind()==null) || 
             (this.order_kind!=null &&
              this.order_kind.equals(other.getOrder_kind()))) &&
            ((this.order_status==null && other.getOrder_status()==null) || 
             (this.order_status!=null &&
              this.order_status.equals(other.getOrder_status()))) &&
            ((this.ponNo==null && other.getPonNo()==null) || 
             (this.ponNo!=null &&
              this.ponNo.equals(other.getPonNo()))) &&
            ((this.privatePara==null && other.getPrivatePara()==null) || 
             (this.privatePara!=null &&
              this.privatePara.equals(other.getPrivatePara()))) &&
            ((this.protocolType==null && other.getProtocolType()==null) || 
             (this.protocolType!=null &&
              this.protocolType.equals(other.getProtocolType()))) &&
            ((this.pvc==null && other.getPvc()==null) || 
             (this.pvc!=null &&
              this.pvc.equals(other.getPvc()))) &&
            ((this.replyFlag==null && other.getReplyFlag()==null) || 
             (this.replyFlag!=null &&
              this.replyFlag.equals(other.getReplyFlag()))) &&
            ((this.replyOrderFlag==null && other.getReplyOrderFlag()==null) || 
             (this.replyOrderFlag!=null &&
              this.replyOrderFlag.equals(other.getReplyOrderFlag()))) &&
            ((this.replyURL==null && other.getReplyURL()==null) || 
             (this.replyURL!=null &&
              this.replyURL.equals(other.getReplyURL()))) &&
            ((this.serviceType==null && other.getServiceType()==null) || 
             (this.serviceType!=null &&
              this.serviceType.equals(other.getServiceType()))) &&
            ((this.service_code==null && other.getService_code()==null) || 
             (this.service_code!=null &&
              this.service_code.equals(other.getService_code()))) &&
            ((this.slotNo==null && other.getSlotNo()==null) || 
             (this.slotNo!=null &&
              this.slotNo.equals(other.getSlotNo()))) &&
            ((this.strIptvAccount==null && other.getStrIptvAccount()==null) || 
             (this.strIptvAccount!=null &&
              this.strIptvAccount.equals(other.getStrIptvAccount()))) &&
            ((this.strReplyOrderFlag==null && other.getStrReplyOrderFlag()==null) || 
             (this.strReplyOrderFlag!=null &&
              this.strReplyOrderFlag.equals(other.getStrReplyOrderFlag()))) &&
            ((this.strReplyUrlFlag==null && other.getStrReplyUrlFlag()==null) || 
             (this.strReplyUrlFlag!=null &&
              this.strReplyUrlFlag.equals(other.getStrReplyUrlFlag()))) &&
            ((this.subAreaNum==null && other.getSubAreaNum()==null) || 
             (this.subAreaNum!=null &&
              this.subAreaNum.equals(other.getSubAreaNum()))) &&
            ((this.subArea_code==null && other.getSubArea_code()==null) || 
             (this.subArea_code!=null &&
              this.subArea_code.equals(other.getSubArea_code()))) &&
            ((this.time_limit==null && other.getTime_limit()==null) || 
             (this.time_limit!=null &&
              this.time_limit.equals(other.getTime_limit()))) &&
            ((this.uplink_type==null && other.getUplink_type()==null) || 
             (this.uplink_type!=null &&
              this.uplink_type.equals(other.getUplink_type()))) &&
            ((this.upstreamMaxRate==null && other.getUpstreamMaxRate()==null) || 
             (this.upstreamMaxRate!=null &&
              this.upstreamMaxRate.equals(other.getUpstreamMaxRate()))) &&
            ((this.userBrasIP==null && other.getUserBrasIP()==null) || 
             (this.userBrasIP!=null &&
              this.userBrasIP.equals(other.getUserBrasIP()))) &&
            ((this.userCard==null && other.getUserCard()==null) || 
             (this.userCard!=null &&
              this.userCard.equals(other.getUserCard()))) &&
            ((this.userCustom==null && other.getUserCustom()==null) || 
             (this.userCustom!=null &&
              this.userCustom.equals(other.getUserCustom()))) &&
            ((this.userEmail==null && other.getUserEmail()==null) || 
             (this.userEmail!=null &&
              this.userEmail.equals(other.getUserEmail()))) &&
            ((this.userPhone==null && other.getUserPhone()==null) || 
             (this.userPhone!=null &&
              this.userPhone.equals(other.getUserPhone()))) &&
            ((this.userPort==null && other.getUserPort()==null) || 
             (this.userPort!=null &&
              this.userPort.equals(other.getUserPort()))) &&
            ((this.user_Type==null && other.getUser_Type()==null) || 
             (this.user_Type!=null &&
              this.user_Type.equals(other.getUser_Type()))) &&
            ((this.user_address==null && other.getUser_address()==null) || 
             (this.user_address!=null &&
              this.user_address.equals(other.getUser_address()))) &&
            ((this.user_name==null && other.getUser_name()==null) || 
             (this.user_name!=null &&
              this.user_name.equals(other.getUser_name()))) &&
            ((this.vector_argues==null && other.getVector_argues()==null) || 
             (this.vector_argues!=null &&
              this.vector_argues.equals(other.getVector_argues()))) &&
            ((this.ver==null && other.getVer()==null) || 
             (this.ver!=null &&
              this.ver.equals(other.getVer()))) &&
            ((this.vlanID==null && other.getVlanID()==null) || 
             (this.vlanID!=null &&
              this.vlanID.equals(other.getVlanID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDSLMPort() != null) {
            _hashCode += getDSLMPort().hashCode();
        }
        if (getAccessNo() != null) {
            _hashCode += getAccessNo().hashCode();
        }
        if (getAd_account() != null) {
            _hashCode += getAd_account().hashCode();
        }
        if (getAd_password() != null) {
            _hashCode += getAd_password().hashCode();
        }
        if (getAd_userid() != null) {
            _hashCode += getAd_userid().hashCode();
        }
        if (getAd_userpass() != null) {
            _hashCode += getAd_userpass().hashCode();
        }
        if (getArea_code() != null) {
            _hashCode += getArea_code().hashCode();
        }
        if (getCardKey() != null) {
            _hashCode += getCardKey().hashCode();
        }
        if (getCardNo() != null) {
            _hashCode += getCardNo().hashCode();
        }
        if (getContact_person() != null) {
            _hashCode += getContact_person().hashCode();
        }
        if (getDeviceMac() != null) {
            _hashCode += getDeviceMac().hashCode();
        }
        if (getDeviceType() != null) {
            _hashCode += getDeviceType().hashCode();
        }
        if (getDevice_ID() != null) {
            _hashCode += getDevice_ID().hashCode();
        }
        if (getDevice_WAN() != null) {
            _hashCode += getDevice_WAN().hashCode();
        }
        if (getDevice_wan() != null) {
            _hashCode += getDevice_wan().hashCode();
        }
        if (getDownstreamMaxRate() != null) {
            _hashCode += getDownstreamMaxRate().hashCode();
        }
        if (getDslmport() != null) {
            _hashCode += getDslmport().hashCode();
        }
        if (getExecuteNo() != null) {
            _hashCode += getExecuteNo().hashCode();
        }
        if (getFinalorderDocument() != null) {
            _hashCode += getFinalorderDocument().hashCode();
        }
        if (getHome_assist() != null) {
            _hashCode += getHome_assist().hashCode();
        }
        if (getOltIP() != null) {
            _hashCode += getOltIP().hashCode();
        }
        if (getOltManufacturer() != null) {
            _hashCode += getOltManufacturer().hashCode();
        }
        if (getOltType() != null) {
            _hashCode += getOltType().hashCode();
        }
        if (getOnuId() != null) {
            _hashCode += getOnuId().hashCode();
        }
        if (getOnu_Port() != null) {
            _hashCode += getOnu_Port().hashCode();
        }
        if (getOrderDocument() != null) {
            _hashCode += getOrderDocument().hashCode();
        }
        if (getOrder_LSH() != null) {
            _hashCode += getOrder_LSH().hashCode();
        }
        if (getOrder_No() != null) {
            _hashCode += getOrder_No().hashCode();
        }
        if (getOrder_Remark() != null) {
            _hashCode += getOrder_Remark().hashCode();
        }
        if (getOrder_Time() != null) {
            _hashCode += getOrder_Time().hashCode();
        }
        if (getOrder_Type() != null) {
            _hashCode += getOrder_Type().hashCode();
        }
        if (getOrder_kind() != null) {
            _hashCode += getOrder_kind().hashCode();
        }
        if (getOrder_status() != null) {
            _hashCode += getOrder_status().hashCode();
        }
        if (getPonNo() != null) {
            _hashCode += getPonNo().hashCode();
        }
        if (getPrivatePara() != null) {
            _hashCode += getPrivatePara().hashCode();
        }
        if (getProtocolType() != null) {
            _hashCode += getProtocolType().hashCode();
        }
        if (getPvc() != null) {
            _hashCode += getPvc().hashCode();
        }
        if (getReplyFlag() != null) {
            _hashCode += getReplyFlag().hashCode();
        }
        if (getReplyOrderFlag() != null) {
            _hashCode += getReplyOrderFlag().hashCode();
        }
        if (getReplyURL() != null) {
            _hashCode += getReplyURL().hashCode();
        }
        if (getServiceType() != null) {
            _hashCode += getServiceType().hashCode();
        }
        if (getService_code() != null) {
            _hashCode += getService_code().hashCode();
        }
        if (getSlotNo() != null) {
            _hashCode += getSlotNo().hashCode();
        }
        if (getStrIptvAccount() != null) {
            _hashCode += getStrIptvAccount().hashCode();
        }
        if (getStrReplyOrderFlag() != null) {
            _hashCode += getStrReplyOrderFlag().hashCode();
        }
        if (getStrReplyUrlFlag() != null) {
            _hashCode += getStrReplyUrlFlag().hashCode();
        }
        if (getSubAreaNum() != null) {
            _hashCode += getSubAreaNum().hashCode();
        }
        if (getSubArea_code() != null) {
            _hashCode += getSubArea_code().hashCode();
        }
        if (getTime_limit() != null) {
            _hashCode += getTime_limit().hashCode();
        }
        if (getUplink_type() != null) {
            _hashCode += getUplink_type().hashCode();
        }
        if (getUpstreamMaxRate() != null) {
            _hashCode += getUpstreamMaxRate().hashCode();
        }
        if (getUserBrasIP() != null) {
            _hashCode += getUserBrasIP().hashCode();
        }
        if (getUserCard() != null) {
            _hashCode += getUserCard().hashCode();
        }
        if (getUserCustom() != null) {
            _hashCode += getUserCustom().hashCode();
        }
        if (getUserEmail() != null) {
            _hashCode += getUserEmail().hashCode();
        }
        if (getUserPhone() != null) {
            _hashCode += getUserPhone().hashCode();
        }
        if (getUserPort() != null) {
            _hashCode += getUserPort().hashCode();
        }
        if (getUser_Type() != null) {
            _hashCode += getUser_Type().hashCode();
        }
        if (getUser_address() != null) {
            _hashCode += getUser_address().hashCode();
        }
        if (getUser_name() != null) {
            _hashCode += getUser_name().hashCode();
        }
        if (getVector_argues() != null) {
            _hashCode += getVector_argues().hashCode();
        }
        if (getVer() != null) {
            _hashCode += getVer().hashCode();
        }
        if (getVlanID() != null) {
            _hashCode += getVlanID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Order.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("OperationDistributeService", "Order"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DSLMPort");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DSLMPort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accessNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "accessNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ad_account");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ad_account"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ad_password");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ad_password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ad_userid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ad_userid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ad_userpass");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ad_userpass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("area_code");
        elemField.setXmlName(new javax.xml.namespace.QName("", "area_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cardKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cardKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cardNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cardNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contact_person");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contact_person"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceMac");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deviceMac"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deviceType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deviceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_ID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_ID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_WAN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_WAN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_wan");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_wan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("downstreamMaxRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "downstreamMaxRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dslmport");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dslmport"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("executeNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "executeNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("finalorderDocument");
        elemField.setXmlName(new javax.xml.namespace.QName("", "finalorderDocument"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("home_assist");
        elemField.setXmlName(new javax.xml.namespace.QName("", "home_assist"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oltIP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "oltIP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oltManufacturer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "oltManufacturer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oltType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "oltType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("onuId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "onuId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("onu_Port");
        elemField.setXmlName(new javax.xml.namespace.QName("", "onu_Port"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderDocument");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderDocument"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_LSH");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_LSH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_No");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_No"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_Remark");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_Remark"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_Time");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_Time"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_Type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_kind");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_kind"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ponNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ponNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("privatePara");
        elemField.setXmlName(new javax.xml.namespace.QName("", "privatePara"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protocolType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "protocolType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pvc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pvc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("replyFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "replyFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("replyOrderFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "replyOrderFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("replyURL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "replyURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "serviceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("service_code");
        elemField.setXmlName(new javax.xml.namespace.QName("", "service_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("slotNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "slotNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("strIptvAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "strIptvAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("strReplyOrderFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "strReplyOrderFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("strReplyUrlFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "strReplyUrlFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subAreaNum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subAreaNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subArea_code");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subArea_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time_limit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "time_limit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uplink_type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "uplink_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("upstreamMaxRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "upstreamMaxRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userBrasIP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userBrasIP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userCard");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userCustom");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userCustom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userPhone");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userPhone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userPort");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userPort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("user_Type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "user_Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("user_address");
        elemField.setXmlName(new javax.xml.namespace.QName("", "user_address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("user_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "user_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vector_argues");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vector_argues"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ver");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ver"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vlanID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vlanID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
