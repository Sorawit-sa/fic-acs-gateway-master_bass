package th.co.ais.acs.rest.model;

public class UMPProvisioning {

	private boolean multiShot = true;
	private String domain = "/";
	private boolean enabled = true;
	private UMPProvisioningProperties properties = null;
	private UMPProvisioningProperties add = null;
	private String [] remove = null;
	private String error = null;
	
	public boolean isMultiShot() {
		return multiShot;
	}
	public void setMultiShot(boolean multiShot) {
		this.multiShot = multiShot;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public UMPProvisioningProperties getProperties() {
		return properties;
	}
	public void setProperties(UMPProvisioningProperties properties) {
		this.properties = properties;
	}
	public UMPProvisioningProperties getAdd() {
		return add;
	}
	public void setAdd(UMPProvisioningProperties add) {
		this.add = add;
	}
	public String[] getRemove() {
		return remove;
	}
	public void setRemove(String[] remove) {
		this.remove = remove;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	
}
