/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th.co.ais.acs.rest.impl;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UMPProvisioning;

/**
 *
 * @author mosza16
 */
public class ExecutionSession implements Runnable {
	static AvsOperation avsOperation = InitialParameter.getAvsOperation();
	private static final LogDebug LOGGER_DEBUG = new LogDebug();

    private RequestMessage requestMessage;
    private ResponseMessage responseMessage;
    
    static final String basicInfoOption = "basicinfo";
	private static final String methodGET = "GET";
	private static final String methodPUT = "PUT";
	private static final String methodPATCH = "PATCH";
	private static final String methodDELETE = "DELETE";
	private static final String methodPOST = "POST";
	
    @Override
	public void run() {
		try {		
			
			executeSession(this.requestMessage, this.responseMessage);

		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
    
    
    
    public ExecutionSession(RequestMessage requestMessage, ResponseMessage responseMessage) {
		super();
		this.requestMessage = requestMessage;
		this.responseMessage = responseMessage;

	}
    public void ex() {
    	executeSession(this.requestMessage, this.responseMessage);
    }
    
    public static void executeSession(RequestMessage requestMessage, ResponseMessage responseMessage_) {
    	long start = System.currentTimeMillis();
    	ResponseMessage responseMessage = new ResponseMessage("AVS");
		ResponseData responseData = new ResponseData();
		responseMessage.setResponseData(responseData);
		
		try {
				if(responseMessage != null && responseMessage_.getDeviceId() != null){
					String deviceId = responseMessage_.getDeviceId();
					String uri = "sessions/" + deviceId + "?exactId=false";
					responseMessage = avsOperation.send("executeSession", methodPOST, uri, true, new Gson().toJson(""), responseMessage);
				} else {
					requestMessage.setOption(basicInfoOption);	
					responseMessage = avsOperation.getBasicInfo(requestMessage, responseMessage);

					if(responseMessage.getResponseCode() != null && responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
						if(responseMessage.getResponseData() != null && responseMessage.getResponseData().getBasicInfo() != null ) {
							String deviceId = responseMessage.getResponseData().getBasicInfo().getDeviceId();
							String uri = "sessions/" + deviceId + "?exactId=false";
							responseMessage = avsOperation.send("executeSession", methodPOST, uri, true, new Gson().toJson(""), responseMessage);
							
						}
	
					}
				}
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("executeSession("+requestMessage.getFibreId()+"): exception", e);
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_DEBUG.log("method=executeSession| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
    }
    
    public static ResponseMessage send(String name, String method, String uri, boolean enable_ssl, String request, ResponseMessage responseMessage) {
		// Generate UUID for transaction tracking
		String ssid = UUID.randomUUID().toString();	
		HttpURLConnection conn = null;
		OutputStream os = null;	
		try {	
				
			if (InitialParameter.MODE == 1) {
		        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
		                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		                    return null;
		                }
		                public void checkClientTrusted(X509Certificate[] certs, String authType) {
		                }
		                public void checkServerTrusted(X509Certificate[] certs, String authType) {
		                }
		            }
		        };
		 
		        SSLContext sc = SSLContext.getInstance("TLSv1.2");
		        sc.init(null, trustAllCerts, new java.security.SecureRandom());
		        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		 
		        HostnameVerifier allHostsValid = new HostnameVerifier() {
		            public boolean verify(String hostname, SSLSession session) {
		                return true;
		            }
		        };
	 
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        
			}
			// Gen Smpp Connection From SMPP Connection Pool				
			URL url = new URL(InitialParameter.url_ump_avs + uri);
			conn = (HttpURLConnection) url.openConnection();
			
			if(method.equals(methodPATCH)) {
				allowMethods("PATCH");
				conn.setRequestMethod(method);	
			} else {
				conn.setRequestMethod(method);
			}
			
			conn.setRequestProperty("Accept-Charset", "UTF-8");
			conn.setRequestProperty("charset", "UTF-8");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setDoOutput(true);
			String userpass = InitialParameter.username_ump_avs + ":" + InitialParameter.password_ump_avs;
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
			conn.setRequestProperty ("Authorization", basicAuth);
			
				
			if( method.equals(methodGET)) {
				
			} else {	
				os = conn.getOutputStream();
				if(method.equals(methodDELETE) ) {
					byte[] data = "{}".getBytes("UTF-8");
					os.write(data);
					os.flush();
				} else {
					byte[] data = request.getBytes("UTF-8");
					os.write(data);
					os.flush();
				}
			}

			
			BufferedReader br;
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			} else {
				br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
            	sb.append(line+"\n");
            }
            br.close();

            if (sb.toString() != null) {
            	responseMessage.setDetail(name+ "=" + sb.toString().replace("\n", "").replace("\r", ""));
            }
            				
			if(os != null) os.close();
			conn.disconnect();
			
		} catch(Exception e) {		
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("send("+request+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(name+ "=" + e);
			return responseMessage;
			
		} finally {
			if(os != null)
				try {
					os.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(conn != null) conn.disconnect();
		}
		
		return responseMessage;
	}
    
    private static void allowMethods(String... methods) {
        try {
            Field methodsField = HttpURLConnection.class.getDeclaredField("methods");

            Field modifiersField = Field.class.getDeclaredField("modifiers");
            modifiersField.setAccessible(true);
            modifiersField.setInt(methodsField, methodsField.getModifiers() & ~Modifier.FINAL);

            methodsField.setAccessible(true);

            String[] oldMethods = (String[]) methodsField.get(null);
            Set<String> methodsSet = new LinkedHashSet<>(Arrays.asList(oldMethods));
            methodsSet.addAll(Arrays.asList(methods));
            String[] newMethods = methodsSet.toArray(new String[0]);

            methodsField.set(null/*static field*/, newMethods);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new IllegalStateException(e);
        }
    }
	
}
