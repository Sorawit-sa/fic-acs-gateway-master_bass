package th.co.ais.acs.rest.restapi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.dao.AcsService;
import th.co.ais.acs.rest.db.DBFibreOperation;
import th.co.ais.acs.rest.db.DBStreamOperation;

import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.Credentials;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseMessage;



@DeclareRoles({"admin", "user", "guest"})
@Path("/acs/v1/sys")
public class ACSRestServiceSys {
	
	DBFibreOperation dbFibreOperation = InitialParameter.getDbFibreOperation();
	AcsService avsServiceDao = InitialParameter.getAvsServiceDao();
	AcsService egServiceDao = InitialParameter.getEgServiceDao();
	AcsService hwServiceDao = InitialParameter.getHwServiceDao();
	AcsService kiddoServiceDao = InitialParameter.getKiddoServiceDao();
	
	private static final String OPTION_1 = "1";
	private static final String OPTION_0 = "0";
	
	private static final String EG = "EG";
	private static final String AVS = "AVS";
	private static final String HW = "HW";
	private static final String KIDDO = "KIDDO";
			
	
	// Maintenance //
	@POST
	@Path("/upgradefirmware")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response upgradefirmware( String requestMassage ) {
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		
		if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
			if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
				responseMessage = avsServiceDao.upgradeFirmware(requestMassage_);
				
			} else {
				responseMessage = egServiceDao.upgradeFirmware(requestMassage_);
				
			}
			
		} else {
			responseMessage = egServiceDao.upgradeFirmware(requestMassage_);
			
		}
		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
	@POST
	@Path("/reboot")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response reboot( String requestMassage ) {
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		if(requestMassage_.getFibreId() != null && requestMassage_.getFibreId().startsWith("888")) {
			requestMassage_.setInternetUsername(responseMessage.getResponseData().getUsername());
		}
		
		if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
			if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
				responseMessage = avsServiceDao.reboot(requestMassage_);
				
			} else if(responseMessage.getResponseData().getAcsSystem().equals(HW)) {
				responseMessage = hwServiceDao.reboot(requestMassage_);
				
			} else if(responseMessage.getResponseData().getAcsSystem().equals(KIDDO)) {
				responseMessage = kiddoServiceDao.reboot(requestMassage_);

			}else {
				responseMessage = egServiceDao.reboot(requestMassage_);
				
			}
			
		} else {
			responseMessage = egServiceDao.reboot(requestMassage_);
			
		}
		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
	@POST
	@Path("/factoryreset")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response factoryreset( String requestMassage ) {
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		
		if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
			if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
				responseMessage = avsServiceDao.factoryReset(requestMassage_);
				
			} else {
				responseMessage = egServiceDao.factoryReset(requestMassage_);
				
			}
			
		} else {
			responseMessage = egServiceDao.factoryReset(requestMassage_);
			
		}
		return ResponseBuilder.createResponseGson( responseMessage );
	}

	@POST
	@Path("/configfile")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response configfile( String requestMassage ) {
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		
		if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
			if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
				responseMessage = avsServiceDao.configFile(requestMassage_);
				// AVS 
				
			} else {
				responseMessage = egServiceDao.configFile(requestMassage_);
				// EG
				
			}
			
		} else {
			responseMessage = egServiceDao.configFile(requestMassage_);
			
		}
		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
}