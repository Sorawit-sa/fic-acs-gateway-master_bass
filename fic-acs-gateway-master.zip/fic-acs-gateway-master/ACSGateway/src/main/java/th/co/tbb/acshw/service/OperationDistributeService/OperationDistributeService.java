/**
 * OperationDistributeService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.service.OperationDistributeService;

import th.co.tbb.acshw.model.OperationDistributeService.DelCpeInfo;
import th.co.tbb.acshw.model.OperationDistributeService.NorthQueryParaResult;
import th.co.tbb.acshw.model.OperationDistributeService.Order;
import th.co.tbb.acshw.model.OperationDistributeService.UserDetail;
import th.co.tbb.acshw.model.OperationDistributeService.UserIndex;

public interface OperationDistributeService extends java.rmi.Remote {
    public int serviceInterface(int command, java.lang.String serviceCode, java.lang.String cpeMac, java.lang.String oltManufacturer, java.lang.String oltType, java.lang.String oltIP, int slotNo, int ponNo, java.lang.String onuId, java.lang.String areaCode, java.lang.String parameter) throws java.rmi.RemoteException;
    public int serviceChange(java.lang.String adAcount, java.lang.String LSHNo, java.lang.String orderType, java.lang.String newPassWord) throws java.rmi.RemoteException;
    public int dealOrder(Order order) throws java.rmi.RemoteException;
    public java.lang.String sendOrder(java.lang.String theRequest) throws java.rmi.RemoteException;
    public int bindInterface(int command, java.lang.String cpeId, java.lang.String adAccounts, java.lang.String nasPortId, java.lang.String nasIP, java.lang.String areaNum, java.lang.String vlanId) throws java.rmi.RemoteException;
    public int delCPE(DelCpeInfo delCpeInfo) throws java.rmi.RemoteException;
    public int delSingelCPE(java.lang.String strCPEID) throws java.rmi.RemoteException;
    public int dealOrderWithReply(Order order, java.lang.String replyURL) throws java.rmi.RemoteException;
    public UserDetail[] queryUserDetail(int iParaType, java.lang.String value) throws java.rmi.RemoteException;
    public int bindInterface_pon(int command, java.lang.String cpeMac, java.lang.String adAccounts, java.lang.String nasPortId, java.lang.String nasIP, java.lang.String areaNum, java.lang.String userPhone) throws java.rmi.RemoteException;
    public NorthQueryParaResult northQueryCPEPara(UserIndex user) throws java.rmi.RemoteException;
}
