package th.co.ais.acs.rest.model;

public class UMPProvisioningProperties {
	
	private String internetUsername = null;
	private String internetPassword = null;
	private String SIPUsername1 = null;
	private String SIPURI1 = null;
	private String SIPPassword1 = null;
	private String SIPUsername2 = null;
	private String SIPURI2 = null;
	private String SIPPassword2 = null;
	private String fibernetID = null;

	private String bridgeVLAN = null;
	private String bridgeWAN = null;
	
	private String actionID = null;
	
	private String SSID_1 = null;
	private String SSID_2 = null;
	private String SSID_3 = null;
	private String SSID_4 = null;
	private String SSID_5 = null;
	private String SSID_6 = null;
	private String SSID_7 = null;
	private String SSID_8 = null;
	private String KeyPassphrase_1 = null;
	private String KeyPassphrase_2 = null;
	private String KeyPassphrase_3 = null;
	private String KeyPassphrase_4 = null;
	private String KeyPassphrase_5 = null;
	private String KeyPassphrase_6 = null;
	private String KeyPassphrase_7 = null;
	private String KeyPassphrase_8 = null;
	
	private String ProductOwner = null;
	    	
	public String getInternetUsername() {
		return internetUsername;
	}
	public void setInternetUsername(String internetUsername) {
		this.internetUsername = internetUsername;
	}
	public String getInternetPassword() {
		return internetPassword;
	}
	public void setInternetPassword(String internetPassword) {
		this.internetPassword = internetPassword;
	}
	public String getSIPUsername1() {
		return SIPUsername1;
	}
	public void setSIPUsername1(String sIPUsername1) {
		SIPUsername1 = sIPUsername1;
	}
	public String getSIPURI1() {
		return SIPURI1;
	}
	public void setSIPURI1(String sIPURI1) {
		SIPURI1 = sIPURI1;
	}
	public String getSIPPassword1() {
		return SIPPassword1;
	}
	public void setSIPPassword1(String sIPPassword1) {
		SIPPassword1 = sIPPassword1;
	}
	public String getSIPUsername2() {
		return SIPUsername2;
	}
	public void setSIPUsername2(String sIPUsername2) {
		SIPUsername2 = sIPUsername2;
	}
	public String getSIPURI2() {
		return SIPURI2;
	}
	public void setSIPURI2(String sIPURI2) {
		SIPURI2 = sIPURI2;
	}
	public String getSIPPassword2() {
		return SIPPassword2;
	}
	public void setSIPPassword2(String sIPPassword2) {
		SIPPassword2 = sIPPassword2;
	}
	public String getFibernetID() {
		return fibernetID;
	}
	public void setFibernetID(String fibernetID) {
		this.fibernetID = fibernetID;
	}
	public String getBridgeVLAN() {
		return bridgeVLAN;
	}
	public void setBridgeVLAN(String bridgeVLAN) {
		this.bridgeVLAN = bridgeVLAN;
	}
	public String getBridgeWAN() {
		return bridgeWAN;
	}
	public void setBridgeWAN(String bridgeWAN) {
		this.bridgeWAN = bridgeWAN;
	}	
	public String getActionID() {
		return actionID;
	}
	public void setActionID(String actionID) {
		this.actionID = actionID;
	}
	public String getSSID_1() {
		return SSID_1;
	}
	public void setSSID_1(String sSID_1) {
		SSID_1 = sSID_1;
	}
	public String getSSID_2() {
		return SSID_2;
	}
	public void setSSID_2(String sSID_2) {
		SSID_2 = sSID_2;
	}
	public String getSSID_3() {
		return SSID_3;
	}
	public void setSSID_3(String sSID_3) {
		SSID_3 = sSID_3;
	}
	public String getSSID_4() {
		return SSID_4;
	}
	public void setSSID_4(String sSID_4) {
		SSID_4 = sSID_4;
	}
	public String getSSID_5() {
		return SSID_5;
	}
	public void setSSID_5(String sSID_5) {
		SSID_5 = sSID_5;
	}
	public String getSSID_6() {
		return SSID_6;
	}
	public void setSSID_6(String sSID_6) {
		SSID_6 = sSID_6;
	}
	public String getSSID_7() {
		return SSID_7;
	}
	public void setSSID_7(String sSID_7) {
		SSID_7 = sSID_7;
	}
	public String getSSID_8() {
		return SSID_8;
	}
	public void setSSID_8(String sSID_8) {
		SSID_8 = sSID_8;
	}
	public String getKeyPassphrase_1() {
		return KeyPassphrase_1;
	}
	public void setKeyPassphrase_1(String keyPassphrase_1) {
		KeyPassphrase_1 = keyPassphrase_1;
	}
	public String getKeyPassphrase_2() {
		return KeyPassphrase_2;
	}
	public void setKeyPassphrase_2(String keyPassphrase_2) {
		KeyPassphrase_2 = keyPassphrase_2;
	}
	public String getKeyPassphrase_3() {
		return KeyPassphrase_3;
	}
	public void setKeyPassphrase_3(String keyPassphrase_3) {
		KeyPassphrase_3 = keyPassphrase_3;
	}
	public String getKeyPassphrase_4() {
		return KeyPassphrase_4;
	}
	public void setKeyPassphrase_4(String keyPassphrase_4) {
		KeyPassphrase_4 = keyPassphrase_4;
	}
	public String getKeyPassphrase_5() {
		return KeyPassphrase_5;
	}
	public void setKeyPassphrase_5(String keyPassphrase_5) {
		KeyPassphrase_5 = keyPassphrase_5;
	}
	public String getKeyPassphrase_6() {
		return KeyPassphrase_6;
	}
	public void setKeyPassphrase_6(String keyPassphrase_6) {
		KeyPassphrase_6 = keyPassphrase_6;
	}
	public String getKeyPassphrase_7() {
		return KeyPassphrase_7;
	}
	public void setKeyPassphrase_7(String keyPassphrase_7) {
		KeyPassphrase_7 = keyPassphrase_7;
	}
	public String getKeyPassphrase_8() {
		return KeyPassphrase_8;
	}
	public void setKeyPassphrase_8(String keyPassphrase_8) {
		KeyPassphrase_8 = keyPassphrase_8;
	}
	public String getProductOwner() {
		return ProductOwner;
	}
	public void setProductOwner(String productOwner) {
		ProductOwner = productOwner;
	}
	
	@Override
	public String toString() {
		return "UMPProvisioningProperties [internetUsername=" + internetUsername + ", internetPassword="
				+ internetPassword + ", SIPUsername1=" + SIPUsername1 + ", SIPURI1=" + SIPURI1 + ", SIPPassword1="
				+ SIPPassword1 + ", SIPUsername2=" + SIPUsername2 + ", SIPURI2=" + SIPURI2 + ", SIPPassword2="
				+ SIPPassword2 + ", fibernetID=" + fibernetID + ", bridgeVLAN=" + bridgeVLAN + ", bridgeWAN="
				+ bridgeWAN + ", actionID=" + actionID + ", SSID_1="
				+ SSID_1 + ", SSID_2=" + SSID_2 + ", SSID_3=" + SSID_3 + ", SSID_4="
				+ SSID_4 + ", SSID_5=" + SSID_5 + ", SSID_6=" + SSID_6 + ", SSID_7="
				+ SSID_7 + ", SSID_8=" + SSID_8 + ", KeyPassphrase_1=" + KeyPassphrase_1 + ", KeyPassphrase_2="
				+ KeyPassphrase_2 + ", KeyPassphrase_3=" + KeyPassphrase_3 + ", KeyPassphrase_4=" + KeyPassphrase_4 + ", KeyPassphrase_5="
				+ KeyPassphrase_5 + ", KeyPassphrase_6=" + KeyPassphrase_6 + ", KeyPassphrase_7=" + KeyPassphrase_7 + ", KeyPassphrase_8="
				+ KeyPassphrase_8 + ", ProductOwner=" + ProductOwner + "]";
	}
	
}
