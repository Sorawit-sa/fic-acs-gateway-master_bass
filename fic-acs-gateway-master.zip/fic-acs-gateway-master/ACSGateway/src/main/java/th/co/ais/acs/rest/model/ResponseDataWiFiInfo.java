package th.co.ais.acs.rest.model;

public class ResponseDataWiFiInfo {
	
	String  index         = null;
	String  ssid          = null;
	String  channel       = null;
	String  enable        = null;
	String  autoChannelEnable        = null;
	
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getSsid() {
		return ssid;
	}
	public void setSsid(String ssid) {
		this.ssid = ssid;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getEnable() {
		return enable;
	}
	public void setEnable(String enable) {
		this.enable = enable;
	}
	public String getAutoChannelEnable() {
		return autoChannelEnable;
	}
	public void setAutoChannelEnable(String autoChannelEnable) {
		this.autoChannelEnable = autoChannelEnable;
	}
	@Override
	public String toString() {
		return "ResponseDataWiFiInfo [index=" + index + ", ssid=" + ssid + ", channel=" + channel + ", enable=" + enable
				+ "]";
	}
	
}
