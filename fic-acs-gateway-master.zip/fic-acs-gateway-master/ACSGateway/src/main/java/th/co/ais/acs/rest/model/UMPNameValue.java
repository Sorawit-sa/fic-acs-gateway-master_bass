package th.co.ais.acs.rest.model;

public class UMPNameValue {
	private String name = null;
	private String value = null;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "UMPNameValue [name=" + name + ", value=" + value + "]";
	}
	
	
}
