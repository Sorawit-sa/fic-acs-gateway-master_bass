/**
 * PingResult.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class PingResult  implements java.io.Serializable {
    private int IOpRst;

    private th.co.tbb.acshw.model.DiagnoseService.Result result;

    public PingResult() {
    }

    public PingResult(
           int IOpRst,
           th.co.tbb.acshw.model.DiagnoseService.Result result) {
           this.IOpRst = IOpRst;
           this.result = result;
    }


    /**
     * Gets the IOpRst value for this PingResult.
     * 
     * @return IOpRst
     */
    public int getIOpRst() {
        return IOpRst;
    }


    /**
     * Sets the IOpRst value for this PingResult.
     * 
     * @param IOpRst
     */
    public void setIOpRst(int IOpRst) {
        this.IOpRst = IOpRst;
    }


    /**
     * Gets the result value for this PingResult.
     * 
     * @return result
     */
    public th.co.tbb.acshw.model.DiagnoseService.Result getResult() {
        return result;
    }


    /**
     * Sets the result value for this PingResult.
     * 
     * @param result
     */
    public void setResult(th.co.tbb.acshw.model.DiagnoseService.Result result) {
        this.result = result;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PingResult)) return false;
        PingResult other = (PingResult) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.IOpRst == other.getIOpRst() &&
            ((this.result==null && other.getResult()==null) || 
             (this.result!=null &&
              this.result.equals(other.getResult())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIOpRst();
        if (getResult() != null) {
            _hashCode += getResult().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PingResult.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "pingResult"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IOpRst");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IOpRst"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("result");
        elemField.setXmlName(new javax.xml.namespace.QName("", "result"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "result"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
