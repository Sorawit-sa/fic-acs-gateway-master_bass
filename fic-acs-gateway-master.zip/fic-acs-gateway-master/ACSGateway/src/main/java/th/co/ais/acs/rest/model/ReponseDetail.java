package th.co.ais.acs.rest.model;

public enum ReponseDetail {

	
	param1("00000",""),
	param2("00001","Forbidden"),
	param3("00002","Forbidden"),
	param4("00003","No token provided"),
	param5("00004","Invalid token provided"),
	param6("00005","Token is missmatch"),
	param7("00006","The token is expired"),
	param8("00007","User does not have the rights to acces this resource"),
	param9("01002",""),
	param10("03001","{\"faultcode\":\"0\",\"faultstring\":\"The cpe successfully swapped with the old.\"}"),
	param11("03200","{\"faultcode\":\"0\",\"faultstring\":\"The cpe has already been bound with this activation id.\"}"),
	param12("03201",""),
	param13("03202",""),
	param14("03299","{\"faultcode\":\"4\",\"faultstring\":\"The cpe is binding. Don't bind it repeated please.\"}"),
	param15("99001","{bindAccount, refId}"),
	param16("99200","User does not exist or CPE does not exist or CPE has not been bind to the Logic ID."),
	param17("99201","Multiple devices found for given Customer ID"),
	param18("99001",""),
	param19("99999","");
	
    private String id;
	private String name;
	
    ReponseDetail(String id, String name) {
    	this.id = id;
		this.name = name;
    }
    
    public String getId() { return this.id; }
	public String getName() { return this.name; }

	public static String fromId(String id) {
		for (ReponseDetail e : ReponseDetail.values()) {
			if (id.equals(e.id)) {
				return e.name;
			}
		}
		return null;
	}
}