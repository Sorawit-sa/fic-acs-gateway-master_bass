/**
 * OperationDistributeServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.service.OperationDistributeService;

import java.rmi.Remote;

public class OperationDistributeServiceServiceLocator extends org.apache.axis.client.Service implements OperationDistributeServiceService {

    public OperationDistributeServiceServiceLocator() {
    }


    public OperationDistributeServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public OperationDistributeServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for OperationDistributeService
    private java.lang.String OperationDistributeService_address = null;

    public java.lang.String getOperationDistributeServiceAddress() {
        return OperationDistributeService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String OperationDistributeServiceWSDDServiceName = "OperationDistributeService";

    public java.lang.String getOperationDistributeServiceWSDDServiceName() {
        return OperationDistributeServiceWSDDServiceName;
    }

    public void setOperationDistributeServiceWSDDServiceName(java.lang.String name) {
        OperationDistributeServiceWSDDServiceName = name;
    }

    public OperationDistributeService getOperationDistributeService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(OperationDistributeService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getOperationDistributeService(endpoint);
    }

    public OperationDistributeService getOperationDistributeService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            OperationDistributeServiceSoapBindingStub _stub = new OperationDistributeServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getOperationDistributeServiceWSDDServiceName());
            return (OperationDistributeService) _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setOperationDistributeServiceEndpointAddress(java.lang.String address) {
        OperationDistributeService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (OperationDistributeService.class.isAssignableFrom(serviceEndpointInterface)) {
                OperationDistributeServiceSoapBindingStub _stub = new OperationDistributeServiceSoapBindingStub(new java.net.URL(OperationDistributeService_address), this);
                _stub.setPortName(getOperationDistributeServiceWSDDServiceName());
                return (Remote) _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("OperationDistributeService".equals(inputPortName)) {
            return getOperationDistributeService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/OperationDistributeService", "OperationDistributeServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/OperationDistributeService", "OperationDistributeService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("OperationDistributeService".equals(portName)) {
            setOperationDistributeServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
