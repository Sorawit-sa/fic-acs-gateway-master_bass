package th.co.ais.acs.rest.restapi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import th.co.ais.acs.rest.dao.AcsService;
import th.co.ais.acs.rest.db.DBFibreOperation;
import th.co.ais.acs.rest.db.DBStreamOperation;

import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.Credentials;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseMessage;



@DeclareRoles({"admin", "user", "guest"})
@Path("/acs/v1/info")
public class ACSRestServiceInfo {
	
	DBFibreOperation dbFibreOperation = InitialParameter.getDbFibreOperation();
	AcsService egServiceDao = InitialParameter.getEgServiceDao();
	AcsService avsServiceDao = InitialParameter.getAvsServiceDao();
	AcsService hwServiceDao = InitialParameter.getHwServiceDao();
	AcsService kiddoServiceDao = InitialParameter.getKiddoServiceDao();
	
	private static final String OPTION_1 = "1";
	private static final String OPTION_0 = "0";
	
	private static final String EG = "EG";
	private static final String AVS = "AVS";
	private static final String HW = "HW";
	private static final String KIDDO = "KIDDO";
			
	@POST
	@Path("/getcpeinfo")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response getcpeinfo( String requestMassage ) {
		
		//requestMassage = dbFibreOperation.queryFibreId(requestMassage);
		ResponseMessage responseMessage = null;
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		if( (requestMassage_.getMacAddress() != null || requestMassage_.getIpAddress() != null ) ){
			responseMessage = dbFibreOperation.queryFibreIdx(requestMassage);
		} else {
			responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
			if(requestMassage_.getFibreId() != null && requestMassage_.getFibreId().startsWith("888")) {
				requestMassage_.setInternetUsername(responseMessage.getResponseData().getUsername());
			}
		}
		
//		if( (requestMassage_.getMacAddress() != null || requestMassage_.getIpAddress() != null ) && !(requestMassage_.getFibreId() != null)) {
//			responseMessage.setResponseCode(Code.DATA_NOT_FOUND);
//			responseMessage.setResponseMessage(ReponseCode.fromId(Code.DATA_NOT_FOUND));
//			responseMessage.setDetail("Fibre ID not found");
//		} else {
			if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
				if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
					responseMessage = avsServiceDao.getCpeinfo(requestMassage_);
					
				} else if(responseMessage.getResponseData().getAcsSystem().equals(HW)) {
					responseMessage = hwServiceDao.getCpeinfo(requestMassage_);
					
				} else {
					responseMessage = egServiceDao.getCpeinfo(requestMassage_);
					
				}
				
			} else {
				responseMessage = egServiceDao.getCpeinfo(requestMassage_);
				
			}
			
//		}

		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
	@POST
	@Path("/getwifiinfo")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response getwifiinfo( String requestMassage ) {
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		if(requestMassage_.getFibreId() != null && requestMassage_.getFibreId().startsWith("888")) {
			requestMassage_.setInternetUsername(responseMessage.getResponseData().getUsername());
		}
		
		if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
			if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
				responseMessage = avsServiceDao.getWifiInfo(requestMassage_);
				
			} else if(responseMessage.getResponseData().getAcsSystem().equals(HW)) {
				responseMessage = hwServiceDao.getWifiInfo(requestMassage_);
				
			} else {
				responseMessage = egServiceDao.getWifiInfo(requestMassage_);
				
			}
			
		} else {
			responseMessage = egServiceDao.getWifiInfo(requestMassage_);
			
		}

		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
	@POST
	@Path("/getparametervalues")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response getparametervalues( String requestMassage ) {
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		
		if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
			if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
				responseMessage = avsServiceDao.getParameterValues(requestMassage_);
				
			} 
			else if(responseMessage.getResponseData().getAcsSystem().equals(KIDDO)) {
				responseMessage = kiddoServiceDao.getParameterValues(requestMassage_);

			}else {
				responseMessage = egServiceDao.getParameterValues(requestMassage_);
				
			}
			
		} else {
			responseMessage = egServiceDao.getParameterValues(requestMassage_);
			
		}

		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
	@POST
	@Path("/checkVoIPProfile")
	@RolesAllowed({"admin","user"})
	@Produces("application/json")
	@Consumes("application/json")
	public Response checkVoIPProfile( String requestMassage ) {
		
		ResponseMessage responseMessage = dbFibreOperation.queryACSendpoint(requestMassage, OPTION_0);
		RequestMessage requestMassage_ = new Gson().fromJson(requestMassage, RequestMessage.class);
		
//		if(requestMassage_.getFibreId() != null) {
//			ResponseData responseData = new ResponseData();
//			if(requestMassage_.getFibreId().equals("8850116726")) {
//				responseMessage.setAcsSystem("EG");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("Y");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//			if(requestMassage_.getFibreId().equals("8850116786")) {
//				responseMessage.setAcsSystem("EG");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("N");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//			if(requestMassage_.getFibreId().equals("8850116790")) {
//				responseMessage.setAcsSystem("AVS");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("N");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//			if(requestMassage_.getFibreId().equals("8850116792")) {
//				responseMessage.setAcsSystem("AVS");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("N");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//			if(requestMassage_.getFibreId().equals("8850116788")) {
//				responseMessage.setAcsSystem("AVS");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("N");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//			if(requestMassage_.getFibreId().equals("8850110381")) {
//				responseMessage.setAcsSystem("AVS");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("Y");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//			if(requestMassage_.getFibreId().equals("8850117054")) {
//				responseMessage.setAcsSystem("AVS");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("Y");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//			if(requestMassage_.getFibreId().equals("8850117019")) {
//				responseMessage.setAcsSystem("EG");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("N");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//			if(requestMassage_.getFibreId().equals("8850116789")) {
//				responseMessage.setAcsSystem("EG");
//				responseMessage.setResponseCode(Code.SUCCESS);
//				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
//				responseData.setVoipProfile("Y");
//				responseMessage.setResponseData(responseData);
//				return ResponseBuilder.createResponseGson( responseMessage );
//			}
//		}
		
		if(requestMassage_.getFibreId() != null) {
			ResponseData responseData = new ResponseData();
			// 07/11/2025 07:06 - Add MODE checking for only mockup on staging
			if(InitialParameter.MODE == 1) {
				if(requestMassage_.getFibreId().equals("8850129042")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130215")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130216")) {
					responseMessage.setAcsSystem("AVS");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130039")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130122")) {
					responseMessage.setAcsSystem("AVS");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130126")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130056")) {
					responseMessage.setAcsSystem("AVS");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130147")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130154")) {
					responseMessage.setAcsSystem("AVS");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130383")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130380")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130350")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130421")) {
					responseMessage.setAcsSystem("AVS");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130156")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130395")) {
					responseMessage.setAcsSystem("AVS");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130159")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130165")) {
					responseMessage.setAcsSystem("AVS");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130364")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130422")) {
					responseMessage.setAcsSystem("AVS");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850130405")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133703")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133706")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133704")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133708")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133710")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133713")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133711")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133714")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133716")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133720")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133717")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850133721")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8850143188")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("N");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882025530")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884515295")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884515793")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884513771")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884516189")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884513160")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884515381")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884516054")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884517930")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884517226")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884517264")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884517293")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884517994")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884515792")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884516482")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884516132")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884518049")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884521671")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884518903")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522766")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522772")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522767")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522770")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522774")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522915")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522730")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522576")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884522578")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884523674")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884523905")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884524306")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525167")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525156")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525287")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525247")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882524727")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882524601")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884524916")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884524884")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884524889")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525565")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882536443")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882524727")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525999")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884526284")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884526285")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882534957")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882530623")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882806725")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882531059")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882531313")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884527006")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525842")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884526989")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525427")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525272")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525705")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525701")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525400")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525315")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884525306")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884527627")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884527626")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882526876")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882520117")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882989110")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884527783")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882632334")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884527957")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882801133")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8884528012")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882801360")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882529139")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882529224")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882529694")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882531014")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(requestMassage_.getFibreId().equals("8882536443")) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				} else if(
						requestMassage_.getFibreId().equals("8884525241") ||
						requestMassage_.getFibreId().equals("8884525243") ||
						requestMassage_.getFibreId().equals("8884525238") ||
						requestMassage_.getFibreId().equals("8884527026") ||
						requestMassage_.getFibreId().equals("8884526066") ||
						requestMassage_.getFibreId().equals("8884526068") ||
						requestMassage_.getFibreId().equals("8884526069") ||
						requestMassage_.getFibreId().equals("8884526070") ||
						requestMassage_.getFibreId().equals("8884526071") ||
						requestMassage_.getFibreId().equals("8884526072") ||
						requestMassage_.getFibreId().equals("8884526074") ||
						requestMassage_.getFibreId().equals("8884526076") ||
						requestMassage_.getFibreId().equals("8884526077") ||
						requestMassage_.getFibreId().equals("8884525694") ||
						requestMassage_.getFibreId().equals("8884526282") ||
						requestMassage_.getFibreId().equals("8882519906") ||
						requestMassage_.getFibreId().equals("8882519925") ||
						requestMassage_.getFibreId().equals("8882519921") ||
						requestMassage_.getFibreId().equals("8882519945") ||
						requestMassage_.getFibreId().equals("8882520367") ||
						requestMassage_.getFibreId().equals("8884527634") ||
						requestMassage_.getFibreId().equals("8884527635") ||
						requestMassage_.getFibreId().equals("8884527689") ||
						requestMassage_.getFibreId().equals("8884527694") ||
						requestMassage_.getFibreId().equals("8884526203") ||
						requestMassage_.getFibreId().equals("8884526201") ||
						requestMassage_.getFibreId().equals("8882804241") ||
						requestMassage_.getFibreId().equals("8882531619") ||
						requestMassage_.getFibreId().equals("8882521381") ||
						requestMassage_.getFibreId().equals("8882521659") ||
						requestMassage_.getFibreId().equals("8882521661") ||
						requestMassage_.getFibreId().equals("8882807554") ||
						requestMassage_.getFibreId().equals("8882807599") ||
						requestMassage_.getFibreId().equals("8882807698") ||
						requestMassage_.getFibreId().equals("8884529167") ||
						requestMassage_.getFibreId().equals("8884529360") ||
						requestMassage_.getFibreId().equals("8884529374") ||
						requestMassage_.getFibreId().equals("8850191020") ||
						requestMassage_.getFibreId().equals("8850195647") ||
						requestMassage_.getFibreId().equals("8850195494") ||
						requestMassage_.getFibreId().equals("8850196063") ||
						requestMassage_.getFibreId().equals("8882531181") ||
						requestMassage_.getFibreId().equals("8850196735") ||
						requestMassage_.getFibreId().equals("8850196276") ||
						requestMassage_.getFibreId().equals("8850196660") ||
						requestMassage_.getFibreId().equals("8850196656") ||
						requestMassage_.getFibreId().equals("8884529728") ||
						requestMassage_.getFibreId().equals("8884529820") ||
						requestMassage_.getFibreId().equals("8884529761") ||
						requestMassage_.getFibreId().equals("8850195045") ||
						requestMassage_.getFibreId().equals("8850195053")
				) {
					responseMessage.setAcsSystem("EG");
					responseMessage.setResponseCode(Code.SUCCESS);
					responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					responseData.setVoipProfile("Y");
					responseMessage.setResponseData(responseData);
					return ResponseBuilder.createResponseGson( responseMessage );
				}
			}
		}
		
		if( responseMessage.getResponseCode().equals(Code.SUCCESS) ) {
			if(responseMessage.getResponseData().getAcsSystem().equals(AVS)) {
				responseMessage = avsServiceDao.checkVoIPProfile(requestMassage_);
				
			} else {
				responseMessage = egServiceDao.checkVoIPProfile(requestMassage_);
				
			}
			
		} else {
			responseMessage = egServiceDao.checkVoIPProfile(requestMassage_);
			
		}

		return ResponseBuilder.createResponseGson( responseMessage );
	}
	
}