package th.co.ais.acs.rest.model;

import java.util.ArrayList;
import java.util.Arrays;

public class ResponseDataCFGList {

	ArrayList<ResponseDataKeyValue> array = null;
	ArrayList<ArrayList<ResponseDataKeyValue>> configs = null;
	
	public ArrayList<ResponseDataKeyValue> getArray() {
		return array;
	}
	public void setArray(ArrayList<ResponseDataKeyValue> array) {
		this.array = array;
	}
	public ArrayList<ArrayList<ResponseDataKeyValue>> getConfigs() {
		return configs;
	}
	public void setConfigs(ArrayList<ArrayList<ResponseDataKeyValue>> configs) {
		this.configs = configs;
	}
	@Override
	public String toString() {
		return "ResponseDataCFGList [" + (array != null ? "array=" + Arrays.toString(array.toArray()) + ", " : "")
				+ (configs != null ? "configs=" + Arrays.toString(configs.toArray()) : "") + "]";
	}
	
	
}
