package th.co.ais.acs.rest.db;

public enum Sql {
	
	QUERY_USER_SECURITY(" SELECT * FROM USER_SECURITY WHERE user_id = :userId"),
	
	UPDATE_TOKEN_USER_SECURITY(" UPDATE USER_SECURITY SET TOKEN = :token, LAST_UPDATED_TIME = current_timestamp  WHERE user_id = :userId"),

	// QUERY_ACS_ENDPOINT_FIBREID(" SELECT ACS_SYSTEM FROM INTERNET_ACCOUNT WHERE customer_id = :customerId"),
	QUERY_ACS_ENDPOINT_FIBREID(" SELECT A.ACS_SYSTEM, B.USER_ID FROM INTERNET_ACCOUNT A LEFT JOIN CUSTOMER_3BB_USERNAME B ON A.CUSTOMER_ID = B.CUSTOMER_ID WHERE A.CUSTOMER_ID = :customerId"),
	
	QUERY_ACS_ENDPOINT_TOKEN(" SELECT ACS_SYSTEM FROM INTERNET_ACCOUNT WHERE token_id = :token_id and  rownum = 1"),
	
	QUERY_ACS_ENDPOINT_MAC(" SELECT ACS_SYSTEM FROM ACS_MASTER WHERE mac_address = :mac_address "),
	
	UPDATE_ACS_SYSTEM(" UPDATE INTERNET_ACCOUNT SET ACS_SYSTEM = :acsSystem WHERE CUSTOMER_ID = :customerId "),
	
	QUERY_FIBREID_BY_MAC(" select\r\n"
			+ " CASE\r\n"
			+ "     WHEN NAS_PORT_ID LIKE 'O%' THEN\r\n"
			+ "         b.customer_id\r\n"
			+ "     WHEN NAS_PORT_ID LIKE 'D%' THEN\r\n"
			+ "         c.customer_id\r\n"
			+ " END customer_id\r\n"
			+ " from (\r\n"
			+ "     select\r\n"
			+ "     NAS_PORT_ID,\r\n"
			+ "     SUBSTR(NAS_PORT_ID, 1, INSTR(NAS_PORT_ID, ' ', 1, 1) - 1) node,\r\n"
			+ "     regexp_replace(REGEXP_SUBSTR(SUBSTR(NAS_PORT_ID, 1, INSTR(NAS_PORT_ID, ':', 1, 1) - 1),'(\\d+)/(\\d+)$'),'/(\\d+)$','') card,\r\n"
			+ "     REGEXP_SUBSTR(SUBSTR(NAS_PORT_ID, 1, INSTR(NAS_PORT_ID, ':', 1, 1) - 1),'(\\d+)$') port,\r\n"
			+ "     SUBSTR(SUBSTR(NAS_PORT_ID, INSTR(NAS_PORT_ID, ' ', 1, 2)+1 , (LENGTH(NAS_PORT_ID)-INSTR(NAS_PORT_ID, ' ', 1, 2)) ), 1, INSTR(SUBSTR(NAS_PORT_ID, INSTR(NAS_PORT_ID, ' ', 1, 2)+1 , (LENGTH(NAS_PORT_ID)-INSTR(NAS_PORT_ID, ' ', 1, 2)) ), '/', 1, 1) - 1) onu_id\r\n"
			+ "     from (\r\n"
			+ "         select distinct nas_port_id from online_account where calling_station_id = :calling_station_id\r\n"
			+ "     )\r\n"
			+ " ) a\r\n"
			+ " left join olt_splitter_detail b on b.olt_name = a.node and b.olt_pon_port like '%-'||card||'-'||port and b.ont_id = a.onu_id\r\n"
			+ " left join dslam_port_detail c on c.dslam_name = a.node and c.card_id = a.card and c.port_id = a.port"),
	
	QUERY_FIBREID_BY_IP(" select\r\n"
			+ " CASE\r\n"
			+ "     WHEN NAS_PORT_ID LIKE 'O%' THEN\r\n"
			+ "         b.customer_id\r\n"
			+ "     WHEN NAS_PORT_ID LIKE 'D%' THEN\r\n"
			+ "         c.customer_id\r\n"
			+ " END customer_id\r\n"
			+ " from (\r\n"
			+ "     select\r\n"
			+ "     NAS_PORT_ID,\r\n"
			+ "     SUBSTR(NAS_PORT_ID, 1, INSTR(NAS_PORT_ID, ' ', 1, 1) - 1) node,\r\n"
			+ "     regexp_replace(REGEXP_SUBSTR(SUBSTR(NAS_PORT_ID, 1, INSTR(NAS_PORT_ID, ':', 1, 1) - 1),'(\\d+)/(\\d+)$'),'/(\\d+)$','') card,\r\n"
			+ "     REGEXP_SUBSTR(SUBSTR(NAS_PORT_ID, 1, INSTR(NAS_PORT_ID, ':', 1, 1) - 1),'(\\d+)$') port,\r\n"
			+ "     SUBSTR(SUBSTR(NAS_PORT_ID, INSTR(NAS_PORT_ID, ' ', 1, 2)+1 , (LENGTH(NAS_PORT_ID)-INSTR(NAS_PORT_ID, ' ', 1, 2)) ), 1, INSTR(SUBSTR(NAS_PORT_ID, INSTR(NAS_PORT_ID, ' ', 1, 2)+1 , (LENGTH(NAS_PORT_ID)-INSTR(NAS_PORT_ID, ' ', 1, 2)) ), '/', 1, 1) - 1) onu_id\r\n"
			+ "     from (\r\n"
			+ "         select distinct nas_port_id from online_account where framed_ip_address = :framed_ip_address\r\n"
			+ "     )\r\n"
			+ " ) a\r\n"
			+ " left join olt_splitter_detail b on b.olt_name = a.node and b.olt_pon_port like '%-'||card||'-'||port and b.ont_id = a.onu_id\r\n"
			+ " left join dslam_port_detail c on c.dslam_name = a.node and c.card_id = a.card and c.port_id = a.port"),
	
	QUERY_FIBREID_BY_MAC2("select CUSTOMER_ID, MAC_ADDRESS, ACS_SYSTEM FROM ACS_MASTER WHERE MAC_ADDRESS = :calling_station_id"),
	
	QUERY_FIBREID_BY_IP2(" select CUSTOMER_ID, MAC_ADDRESS, ACS_SYSTEM FROM ACS_MASTER \n"
			+ " WHERE MAC_ADDRESS = \n"
			+ " (SELECT calling_station_id\n"
			+ " FROM (SELECT calling_station_id from online_account where framed_ip_address = :framed_ip_address and service = 'INTERNET' order by online_account.acct_statrt_time)\n"
			+ " WHERE ROWNUM = 1\n"
			+ " )"),
	
	QUERY_FIBREID_BY_MAC_EG("SELECT ONLINE_CPE.DEVICEID,\n"
			+ " ONLINE_CPE.PUBLICIP,\n"
			+ " ONLINE_CPE.MAC,\n"
			+ " TYPE.OUI,\n"
			+ " TYPE.PRODUCTCLASS,\n"
			+ " ONLINE_CPE.SOFTVER,\n"
			+ " ONLINE_CPE.HARDVER,\n"
			+ " TYPE.MANUFACTURER,\n"
			+ " TO_CHAR(ONLINE_CPE.LASTMODIFYTIME,'DD-MM-YYYY HH24:MI:SS') AS LASTMODIFYTIME\n"
			+ " FROM\n"
			+ " (SELECT DEVICEID,\n"
			+ " TYPEID,\n"
			+ " PUBLICIP,\n"
			+ " MAC,\n"
			+ " LASTMODIFYTIME,\n"
			+ " HARDVER,\n"
			+ " SOFTVER,\n"
			+ " RANK() OVER (ORDER BY LASTMODIFYTIME DESC,MAC) AS RNK\n"
			+ " FROM CPEHG.CPEHG_BASE\n"
			+ " WHERE DEVICEID IN (\n"
			+ " SELECT DISTINCT DEVICEID\n"
			+ " FROM (\n"
			+ " (SELECT DEVICEID\n"
			+ " FROM CPEHG.CPEHG_BASE\n"
			+ " WHERE MAC = :macAddress)\n"
			+ " UNION\n"
			+ " (SELECT DEVICEID\n"
			+ " FROM CPEHG.CPEHG_ATTR\n"
			+ " WHERE PARAMVALUE = :macAddress)\n"
			+ " )\n"
			+ " )\n"
			+ " AND LASTMODIFYTIME > TRUNC(SYSDATE)\n"
			+ " ) ONLINE_CPE\n"
			+ " LEFT JOIN CPEHG.CPEHG_TYPEINFO TYPE\n"
			+ " ON ONLINE_CPE.TYPEID = TYPE.TYPEID\n"
			+ " WHERE ONLINE_CPE.RNK = 1"),
	
	QUERY_FIBREID_BY_IP_EG("SELECT ONLINE_CPE.DEVICEID,\n"
			+ " ONLINE_CPE.PUBLICIP,\n"
			+ " ONLINE_CPE.MAC,\n"
			+ " TYPE.OUI,\n"
			+ " TYPE.PRODUCTCLASS,\n"
			+ " ONLINE_CPE.SOFTVER,\n"
			+ " ONLINE_CPE.HARDVER,\n"
			+ " TYPE.MANUFACTURER,\n"
			+ " TO_CHAR(ONLINE_CPE.LASTMODIFYTIME,'DD-MM-YYYY HH24:MI:SS') AS LASTMODIFYTIME\n"
			+ " FROM\n"
			+ " (SELECT DEVICEID,\n"
			+ " TYPEID,\n"
			+ " PUBLICIP,\n"
			+ " MAC,\n"
			+ " LASTMODIFYTIME,\n"
			+ " HARDVER,\n"
			+ " SOFTVER,\n"
			+ " rank() OVER (ORDER BY LASTMODIFYTIME DESC,PUBLICIP) AS rnk\n"
			+ " FROM CPEHG.CPEHG_BASE\n"
			+ " WHERE PUBLICIP = :ipAddress\n"
			+ " AND LASTMODIFYTIME > TRUNC(SYSDATE)\n"
			+ " ) ONLINE_CPE\n"
			+ " LEFT JOIN CPEHG.CPEHG_TYPEINFO TYPE\n"
			+ " ON ONLINE_CPE.TYPEID = TYPE.TYPEID\n"
			+ " WHERE ONLINE_CPE.RNK = 1"),
	
	//ERROR
	OPERATIONS_FAIL("999");	
		
	private String message;
	private Sql(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
}