/**
 * Result.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class Result  implements java.io.Serializable {
    private java.lang.String averageResponseTime;

    private java.lang.String failureCount;

    private java.lang.String maxResponseTime;

    private java.lang.String minResponseTime;

    private java.lang.String successCount;

    public Result() {
    }

    public Result(
           java.lang.String averageResponseTime,
           java.lang.String failureCount,
           java.lang.String maxResponseTime,
           java.lang.String minResponseTime,
           java.lang.String successCount) {
           this.averageResponseTime = averageResponseTime;
           this.failureCount = failureCount;
           this.maxResponseTime = maxResponseTime;
           this.minResponseTime = minResponseTime;
           this.successCount = successCount;
    }


    /**
     * Gets the averageResponseTime value for this Result.
     * 
     * @return averageResponseTime
     */
    public java.lang.String getAverageResponseTime() {
        return averageResponseTime;
    }


    /**
     * Sets the averageResponseTime value for this Result.
     * 
     * @param averageResponseTime
     */
    public void setAverageResponseTime(java.lang.String averageResponseTime) {
        this.averageResponseTime = averageResponseTime;
    }


    /**
     * Gets the failureCount value for this Result.
     * 
     * @return failureCount
     */
    public java.lang.String getFailureCount() {
        return failureCount;
    }


    /**
     * Sets the failureCount value for this Result.
     * 
     * @param failureCount
     */
    public void setFailureCount(java.lang.String failureCount) {
        this.failureCount = failureCount;
    }


    /**
     * Gets the maxResponseTime value for this Result.
     * 
     * @return maxResponseTime
     */
    public java.lang.String getMaxResponseTime() {
        return maxResponseTime;
    }


    /**
     * Sets the maxResponseTime value for this Result.
     * 
     * @param maxResponseTime
     */
    public void setMaxResponseTime(java.lang.String maxResponseTime) {
        this.maxResponseTime = maxResponseTime;
    }


    /**
     * Gets the minResponseTime value for this Result.
     * 
     * @return minResponseTime
     */
    public java.lang.String getMinResponseTime() {
        return minResponseTime;
    }


    /**
     * Sets the minResponseTime value for this Result.
     * 
     * @param minResponseTime
     */
    public void setMinResponseTime(java.lang.String minResponseTime) {
        this.minResponseTime = minResponseTime;
    }


    /**
     * Gets the successCount value for this Result.
     * 
     * @return successCount
     */
    public java.lang.String getSuccessCount() {
        return successCount;
    }


    /**
     * Sets the successCount value for this Result.
     * 
     * @param successCount
     */
    public void setSuccessCount(java.lang.String successCount) {
        this.successCount = successCount;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Result)) return false;
        Result other = (Result) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.averageResponseTime==null && other.getAverageResponseTime()==null) || 
             (this.averageResponseTime!=null &&
              this.averageResponseTime.equals(other.getAverageResponseTime()))) &&
            ((this.failureCount==null && other.getFailureCount()==null) || 
             (this.failureCount!=null &&
              this.failureCount.equals(other.getFailureCount()))) &&
            ((this.maxResponseTime==null && other.getMaxResponseTime()==null) || 
             (this.maxResponseTime!=null &&
              this.maxResponseTime.equals(other.getMaxResponseTime()))) &&
            ((this.minResponseTime==null && other.getMinResponseTime()==null) || 
             (this.minResponseTime!=null &&
              this.minResponseTime.equals(other.getMinResponseTime()))) &&
            ((this.successCount==null && other.getSuccessCount()==null) || 
             (this.successCount!=null &&
              this.successCount.equals(other.getSuccessCount())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAverageResponseTime() != null) {
            _hashCode += getAverageResponseTime().hashCode();
        }
        if (getFailureCount() != null) {
            _hashCode += getFailureCount().hashCode();
        }
        if (getMaxResponseTime() != null) {
            _hashCode += getMaxResponseTime().hashCode();
        }
        if (getMinResponseTime() != null) {
            _hashCode += getMinResponseTime().hashCode();
        }
        if (getSuccessCount() != null) {
            _hashCode += getSuccessCount().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Result.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "result"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("averageResponseTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "averageResponseTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("failureCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "failureCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxResponseTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxResponseTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minResponseTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "minResponseTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("successCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "successCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
