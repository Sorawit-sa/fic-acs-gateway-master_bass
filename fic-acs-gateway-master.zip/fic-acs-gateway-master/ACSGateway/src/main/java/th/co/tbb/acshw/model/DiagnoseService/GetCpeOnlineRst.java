/**
 * GetCpeOnlineRst.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class GetCpeOnlineRst  implements java.io.Serializable {
    private int IOpRst;

    private th.co.tbb.acshw.model.DiagnoseService.CpeInfo cpeInfo;

    public GetCpeOnlineRst() {
    }

    public GetCpeOnlineRst(
           int IOpRst,
           th.co.tbb.acshw.model.DiagnoseService.CpeInfo cpeInfo) {
           this.IOpRst = IOpRst;
           this.cpeInfo = cpeInfo;
    }


    /**
     * Gets the IOpRst value for this GetCpeOnlineRst.
     * 
     * @return IOpRst
     */
    public int getIOpRst() {
        return IOpRst;
    }


    /**
     * Sets the IOpRst value for this GetCpeOnlineRst.
     * 
     * @param IOpRst
     */
    public void setIOpRst(int IOpRst) {
        this.IOpRst = IOpRst;
    }


    /**
     * Gets the cpeInfo value for this GetCpeOnlineRst.
     * 
     * @return cpeInfo
     */
    public th.co.tbb.acshw.model.DiagnoseService.CpeInfo getCpeInfo() {
        return cpeInfo;
    }


    /**
     * Sets the cpeInfo value for this GetCpeOnlineRst.
     * 
     * @param cpeInfo
     */
    public void setCpeInfo(th.co.tbb.acshw.model.DiagnoseService.CpeInfo cpeInfo) {
        this.cpeInfo = cpeInfo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetCpeOnlineRst)) return false;
        GetCpeOnlineRst other = (GetCpeOnlineRst) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.IOpRst == other.getIOpRst() &&
            ((this.cpeInfo==null && other.getCpeInfo()==null) || 
             (this.cpeInfo!=null &&
              this.cpeInfo.equals(other.getCpeInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getIOpRst();
        if (getCpeInfo() != null) {
            _hashCode += getCpeInfo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetCpeOnlineRst.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "getCpeOnlineRst"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IOpRst");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IOpRst"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpeInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpeInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "CpeInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
