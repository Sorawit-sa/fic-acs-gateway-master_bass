/**
 * DiagnoseServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.service.DiagnoseService;

public class DiagnoseServiceServiceLocator extends org.apache.axis.client.Service implements th.co.tbb.acshw.service.DiagnoseService.DiagnoseServiceService {

    public DiagnoseServiceServiceLocator() {
    }


    public DiagnoseServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public DiagnoseServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for DiagnoseService
    private java.lang.String DiagnoseService_address = null;

    public java.lang.String getDiagnoseServiceAddress() {
        return DiagnoseService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String DiagnoseServiceWSDDServiceName = "DiagnoseService";

    public java.lang.String getDiagnoseServiceWSDDServiceName() {
        return DiagnoseServiceWSDDServiceName;
    }

    public void setDiagnoseServiceWSDDServiceName(java.lang.String name) {
        DiagnoseServiceWSDDServiceName = name;
    }

    public th.co.tbb.acshw.service.DiagnoseService.DiagnoseService getDiagnoseService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(DiagnoseService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getDiagnoseService(endpoint);
    }

    public th.co.tbb.acshw.service.DiagnoseService.DiagnoseService getDiagnoseService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            th.co.tbb.acshw.service.DiagnoseService.DiagnoseServiceSoapBindingStub _stub = new th.co.tbb.acshw.service.DiagnoseService.DiagnoseServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getDiagnoseServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setDiagnoseServiceEndpointAddress(java.lang.String address) {
        DiagnoseService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (th.co.tbb.acshw.service.DiagnoseService.DiagnoseService.class.isAssignableFrom(serviceEndpointInterface)) {
                th.co.tbb.acshw.service.DiagnoseService.DiagnoseServiceSoapBindingStub _stub = new th.co.tbb.acshw.service.DiagnoseService.DiagnoseServiceSoapBindingStub(new java.net.URL(DiagnoseService_address), this);
                _stub.setPortName(getDiagnoseServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("DiagnoseService".equals(inputPortName)) {
            return getDiagnoseService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "DiagnoseServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://10.10.19.134:8688/NorthInterface/services/DiagnoseService", "DiagnoseService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("DiagnoseService".equals(portName)) {
            setDiagnoseServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
