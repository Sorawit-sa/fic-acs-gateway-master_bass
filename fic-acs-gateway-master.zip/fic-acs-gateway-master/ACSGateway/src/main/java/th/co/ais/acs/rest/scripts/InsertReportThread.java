/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th.co.ais.acs.rest.scripts;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import th.co.ais.acs.rest.db.NamedParameterStatement;
import th.co.ais.acs.rest.db.Sql;

/**
 *
 * @author mosza16
 */
public class InsertReportThread implements Runnable {

    private static String  report_id;
    private static int  count;
    private static int  elapsed;
    private static String  status;
    
    @Override
	public void run() {
		try {		
			
			this.insert();

		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
    
    
    

    
    public InsertReportThread(String report_id, int count, int elapsed, String status) {
		super();
		this.report_id = report_id;
		this.count = count;
		this.elapsed = elapsed;
		this.status = status;
	}





	private static void insert() throws ClassNotFoundException {

		Connection conn = null;
		NamedParameterStatement pStmt0 = null;
		CallableStatement callableStatement = null;
		
		try {
				long start = System.currentTimeMillis();	
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url = "jdbc:oracle:thin:@" + "10.154.10.31" + ":" + "1540" + ":"+ "FIC";
				conn = DriverManager.getConnection(url, "ficreport", "f1cr3p0rt");

		
				String sqlStr0 = "INSERT INTO report_log (\r\n"
						+ "    report_id,\r\n"
						+ "    count,\r\n"
						+ "    elapsed,\r\n"
						+ "    status\r\n"
						+ ") VALUES (\r\n"
						+ "    :report_id,\r\n"
						+ "    :count,\r\n"
						+ "    :elapsed,\r\n"
						+ "    :status\r\n"
						+ ")";
        	  	
    			pStmt0 = new NamedParameterStatement(conn, sqlStr0);
    	
    			pStmt0.setString("report_id", report_id);
    			pStmt0.setInt("count", count);
    			pStmt0.setInt("elapsed", elapsed);
    			pStmt0.setString("status", status);
    			
	  			int result = pStmt0.executeUpdate();
	  			
	  			long elapsedTimeMillis = System.currentTimeMillis()-start;
	  			System.out.println("InsertReportThread: " + " report_id="+report_id + ", count="+count + ", elapsed="+elapsed + ", status="+status);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (conn != null) conn.close();
				if (pStmt0 != null) pStmt0.close();
				if (callableStatement != null) {
				try {
					callableStatement.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

    }
	
}
