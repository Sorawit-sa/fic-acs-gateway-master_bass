/**
 * @project Fixed Broadband Radius Provisioning
 * 
 * @author FBCO
 * @copyright Copyright (C) 2014 FBCO
 * @email fc-fbco@ais.co.th
 * @version $Revision: 1.0.0 $Date: Sep 08, 2014
 */
package th.co.ais.acs.rest.log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogHW {
	private static final Logger logger = LogManager.getLogger(LogHW.class);
	
	public void log(String messsage) {
		logger.info(messsage.replace("\n", "").replace("\r", ""));
	}
	
	
	
}
