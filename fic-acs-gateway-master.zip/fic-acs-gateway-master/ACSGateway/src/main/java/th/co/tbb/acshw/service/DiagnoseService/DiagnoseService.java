/**
 * DiagnoseService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.service.DiagnoseService;

public interface DiagnoseService extends java.rmi.Remote {
    public th.co.tbb.acshw.model.DiagnoseService.GetCpeOnlineRst getCpeOnlineInfoForDsl(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.CpeInfoRst getCpeInfo(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String interfaceType) throws java.rmi.RemoteException;
    public int startPing(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, th.co.tbb.acshw.model.DiagnoseService.PingInfo ping) throws java.rmi.RemoteException;
    public int diagnoseTest(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String procName, th.co.tbb.acshw.model.DiagnoseService.Para[] paraList) throws java.rmi.RemoteException;
    public int cpeReboot(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.PingResult getPingResult(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException;
    public int resetService(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.GetParameterResult getCpeParameterByNodePath(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String nodePath) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.GetParameterResult getCpeParameterByNodeName(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String[] parameterNames) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.CpeOnlineInfo getCpeOnlineInfo(th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException;
    public int cpeFactoryReset(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, int type) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.VoipPwdInfo getVoipPwdInfo(java.lang.String strInput, java.lang.String strEncryptInput) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.SetParameterResult setCpeParameterValues(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, th.co.tbb.acshw.model.DiagnoseService.ParaWithType[] parameterValues) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.DiagnoseResult getDiagnoseResult(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String procName) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.CPEMission startCPEMission(th.co.tbb.acshw.model.DiagnoseService.UserIndex user, java.lang.String fileName, int iOperType) throws java.rmi.RemoteException;
    public th.co.tbb.acshw.model.DiagnoseService.CPEMissionResult getCPEMissionResult(int iMissionID, th.co.tbb.acshw.model.DiagnoseService.UserIndex user) throws java.rmi.RemoteException;
}
