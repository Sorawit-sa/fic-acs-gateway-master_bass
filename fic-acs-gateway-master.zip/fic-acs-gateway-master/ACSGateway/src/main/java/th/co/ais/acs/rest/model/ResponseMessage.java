package th.co.ais.acs.rest.model;

import java.util.ArrayList;

public class ResponseMessage {
	
	private String responseCode = null;
	private String responseMessage = null;
	private String detail = null;
	private String acsSystem = null;
	private UMPProvisioning umpProvisioning = null;
	private UMPResponse umpResponse = null;
	private String deviceId = null;
	private ArrayList<String> listConfig = null;
	private UMPResponseConfigs umpResponseConfigs = null;
	
	private ResponseData responseData = null;
	
	
	
	public ResponseMessage(String acsSystem) {
		super();
		this.acsSystem = acsSystem;
	}
	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public ResponseData getResponseData() {
		return responseData;
	}
	public void setResponseData(ResponseData responseData) {
		this.responseData = responseData;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	public String getAcsSystem() {
		return acsSystem;
	}
	public void setAcsSystem(String acsSystem) {
		this.acsSystem = acsSystem;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseMessage [");
		if (responseCode != null) {
			builder.append("responseCode=");
			builder.append(responseCode);
			builder.append(", ");
		}
		if (responseMessage != null) {
			builder.append("responseMessage=");
			builder.append(responseMessage);
			builder.append(", ");
		}
		if (detail != null) {
			builder.append("detail=");
			builder.append(detail);
			builder.append(", ");
		}
		if (acsSystem != null) {
			builder.append("acsSystem=");
			builder.append(acsSystem);
			builder.append(", ");
		}
		if (responseData != null) {
			builder.append("responseData=");
			builder.append(responseData);
		}
		builder.append("]");
		return builder.toString();
	}
	public UMPProvisioning getUmpProvisioning() {
		return umpProvisioning;
	}
	public void setUmpProvisioning(UMPProvisioning umpProvisioning) {
		this.umpProvisioning = umpProvisioning;
	}
	public UMPResponse getUmpResponse() {
		return umpResponse;
	}
	public void setUmpResponse(UMPResponse umpResponse) {
		this.umpResponse = umpResponse;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public ArrayList<String> getListConfig() {
		return listConfig;
	}
	public void setListConfig(ArrayList<String> listConfig) {
		this.listConfig = listConfig;
	}
	public UMPResponseConfigs getUmpResponseConfigs() {
		return umpResponseConfigs;
	}
	public void setUmpResponseConfigs(UMPResponseConfigs umpResponseConfigs) {
		this.umpResponseConfigs = umpResponseConfigs;
	}
	
	
	
	
}
