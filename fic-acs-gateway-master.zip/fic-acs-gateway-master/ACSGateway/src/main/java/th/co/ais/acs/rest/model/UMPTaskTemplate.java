package th.co.ais.acs.rest.model;

public class UMPTaskTemplate {
	private String templateName = null;
	private UMPConfig config = null;
	
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public UMPConfig getConfig() {
		return config;
	}
	public void setConfig(UMPConfig config) {
		this.config = config;
	}
	@Override
	public String toString() {
		return "UMPTaskTemplate [templateName=" + templateName + ", config=" + config + "]";
	}
	
	
}
