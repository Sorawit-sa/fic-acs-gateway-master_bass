/**
 * CpeInfoRst.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class CpeInfoRst  implements java.io.Serializable {
    private th.co.tbb.acshw.model.DiagnoseService.CpeInfo cpeInfo;

    private int iOpRst;

    public CpeInfoRst() {
    }

    public CpeInfoRst(
           th.co.tbb.acshw.model.DiagnoseService.CpeInfo cpeInfo,
           int iOpRst) {
           this.cpeInfo = cpeInfo;
           this.iOpRst = iOpRst;
    }


    /**
     * Gets the cpeInfo value for this CpeInfoRst.
     * 
     * @return cpeInfo
     */
    public th.co.tbb.acshw.model.DiagnoseService.CpeInfo getCpeInfo() {
        return cpeInfo;
    }


    /**
     * Sets the cpeInfo value for this CpeInfoRst.
     * 
     * @param cpeInfo
     */
    public void setCpeInfo(th.co.tbb.acshw.model.DiagnoseService.CpeInfo cpeInfo) {
        this.cpeInfo = cpeInfo;
    }


    /**
     * Gets the iOpRst value for this CpeInfoRst.
     * 
     * @return iOpRst
     */
    public int getIOpRst() {
        return iOpRst;
    }


    /**
     * Sets the iOpRst value for this CpeInfoRst.
     * 
     * @param iOpRst
     */
    public void setIOpRst(int iOpRst) {
        this.iOpRst = iOpRst;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CpeInfoRst)) return false;
        CpeInfoRst other = (CpeInfoRst) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cpeInfo==null && other.getCpeInfo()==null) || 
             (this.cpeInfo!=null &&
              this.cpeInfo.equals(other.getCpeInfo()))) &&
            this.iOpRst == other.getIOpRst();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCpeInfo() != null) {
            _hashCode += getCpeInfo().hashCode();
        }
        _hashCode += getIOpRst();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CpeInfoRst.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "CpeInfoRst"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpeInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpeInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "CpeInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IOpRst");
        elemField.setXmlName(new javax.xml.namespace.QName("", "iOpRst"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
