/**
 * @project Fixed Broadband Radius Provisioning
 * 
 * @author FBCO
 * @copyright Copyright (C) 2014 FBCO
 * @email fc-fbco@ais.co.th
 * @version $Revision: 1.0.0 $Date: Sep 08, 2014
 */
package th.co.ais.acs.rest.log;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogDebug {
	private static final Logger logger = LogManager.getLogger(LogDebug.class);

	public void log(String messsage) {
		logger.debug(messsage);
		//System.out.println(messsage);
	}

	public void log(Object printStackTrace) {
		logger.debug(printStackTrace.toString());
		//System.out.println(printStackTrace.toString());
	}
	
	public void log(String message, Object printStackTrace) {
		logger.error("From: "+ message + ", Exception: {}",  printStackTrace);
		//System.out.println(printStackTrace.toString());
	}

}
