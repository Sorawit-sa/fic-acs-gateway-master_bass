
package th.co.ais.acs.rest.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogDB;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.model.UserSecurity;


public class DBStreamOperation {

	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	private static final LogDB LOGGER_INFO = new LogDB();
	
	DataSourceFactoryStream dbPoolStream = InitialParameter.getDataSourceFactoryStream();
	
	private static final String ACS_API = InitialParameter.ACS_API;
	
	public UserSecurity queryUserSecurityByUserName(String userId) {
			UserSecurity userSecurity = new UserSecurity(userId);
			Connection conn = null;
			NamedParameterStatement pStmt0 = null;
			ResultSet rs = null;
			int result = 0;
			try {
					long start = System.currentTimeMillis();	
					conn = dbPoolStream.getConnection();

					String sqlStr0 = Sql.QUERY_USER_SECURITY.getMessage();					
					pStmt0 = new NamedParameterStatement(conn, sqlStr0);
					pStmt0.setString("userId", userId);	
					
					rs = pStmt0.executeQuery();
					
//					userId = null;
//					email = null;
//					firstname = null;
//					lastname = null;
//					password = null;
//					token = null;
//					role = null;
					
					if (rs.next()) {
						userSecurity.setPassword(rs.getString("PASSWORD"));
						userSecurity.setEmail(rs.getString("EMAIL"));
						userSecurity.setFirstname(rs.getString("FIRST_NAME"));
						userSecurity.setLastname(rs.getString("LAST_NAME"));
						userSecurity.setToken(rs.getString("TOKEN"));
						userSecurity.setRole(rs.getString("ROLE"));
					}
					
					long elapsedTimeMillis = System.currentTimeMillis()-start;
		  			//LOGGER_INFO.log("method=queryUserSecurityByUserName, " + userSecurity.toString() + ", elapsed=" + elapsedTimeMillis);
		  			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {

				try {
					if (conn != null) conn.close();
					if (pStmt0 != null) pStmt0.close();
					if (rs != null) rs.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return userSecurity;
	}
	
	public int updateTokenJWT(UserSecurity userSecurity) {		
		Connection conn = null;
		NamedParameterStatement pStmt0 = null;
		int result = 0;
		try {
				long start = System.currentTimeMillis();	
				conn = dbPoolStream.getConnection();

        	  	String sqlStr0 = Sql.UPDATE_TOKEN_USER_SECURITY.getMessage();
        	  	
    			pStmt0 = new NamedParameterStatement(conn, sqlStr0);
    	
    			pStmt0.setString("token", userSecurity.getToken());
    			pStmt0.setString("userId", userSecurity.getUserId());
    			
	  			result = pStmt0.executeUpdate();
	  			
	  			long elapsedTimeMillis = System.currentTimeMillis()-start;
	  			//LOGGER_INFO.log("method=updateTokenJWT, " +userSecurity.toString() + ", result=" + result + ", elapsed=" + elapsedTimeMillis);
	  			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (conn != null) conn.close();
				if (pStmt0 != null) pStmt0.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}	
	
	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}
}
