package th.co.ais.acs.rest.dao;

import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.ResponseMessage;

public interface AcsService {

	public ResponseMessage provisioning( RequestMessage requestMessage );
	
	public ResponseMessage wifiProvisioning( RequestMessage requestMessage );
	
	public ResponseMessage binding( RequestMessage requestMessage );
	
	public ResponseMessage unbinding( RequestMessage requestMessage );
	
	public ResponseMessage getCpeinfo( RequestMessage requestMessage );
	
	public ResponseMessage wanSetup( RequestMessage requestMessage );
	
	public ResponseMessage getWifiInfo( RequestMessage requestMessage );
	
	public ResponseMessage wifiSetup( RequestMessage requestMessage );
	
	public ResponseMessage getParameterValues( RequestMessage requestMessage );
	
	public ResponseMessage setParameterValues( RequestMessage requestMessage );
	
	public ResponseMessage upgradeFirmware( RequestMessage requestMessage );
	
	public ResponseMessage reboot( RequestMessage requestMessage );
	
	public ResponseMessage factoryReset( RequestMessage requestMessage );
	
	public ResponseMessage configFile( RequestMessage requestMessage );
	
	public ResponseMessage checkVoIPProfile( RequestMessage requestMessage );
	
}
