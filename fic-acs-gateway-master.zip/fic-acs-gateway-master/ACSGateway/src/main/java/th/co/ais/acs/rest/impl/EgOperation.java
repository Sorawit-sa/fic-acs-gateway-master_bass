
package th.co.ais.acs.rest.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.rpc.Stub;

import org.apache.axis.AxisFault;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ArrayOfResponseMapEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.BaseRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ConfigFilesListResponseEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.CpeHgBaseInfo;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisFactoryResetRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DiagnosisRebootRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadConifgFileForAisRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.DownloadRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.GetParameterValuesRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.OperateResponce;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ResponseMapEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeRequestEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.ServiceChangeResponceEntry;
import com.zte.ums.cpehg.neal.northbound.common.model.xsd.SetParameterValuesRequestEntry;

import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServices;
import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesLocator;
import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortType;
import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceLocator;
import northbound.axis2.interfaces.diagnosis.ws.Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub;
import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServices;
import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesLocator;
import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortType;
import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortTypeImplServiceLocator;
import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub;
import northbound.axis2.interfaces.diagnosis.ws.CpeDiagnosisWebServicesSoap12BindingStub;
import northbound.axis2.interfaces.worklist.ws.AISBindServicesLocator;
import northbound.axis2.interfaces.worklist.ws.AISBindServicesSoap12BindingStub;
import northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesLocator;
import northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesPortType;
import northbound.axis2.interfaces.worklist.ws.CpeWorkListWebServicesSoap12BindingStub;
import th.co.ais.acs.rest.db.DBEgOperation;
import th.co.ais.acs.rest.init.InitialParameter;
import th.co.ais.acs.rest.log.LogDB;
import th.co.ais.acs.rest.log.LogDebug;
import th.co.ais.acs.rest.log.LogEG;
import th.co.ais.acs.rest.model.Code;
import th.co.ais.acs.rest.model.ReponseCode;
import th.co.ais.acs.rest.model.ReponseDetail;
import th.co.ais.acs.rest.model.RequestDataKeyValue;
import th.co.ais.acs.rest.model.RequestItem;
import th.co.ais.acs.rest.model.RequestMessage;
import th.co.ais.acs.rest.model.RequestWiFiInfo;
import th.co.ais.acs.rest.model.ResponseData;
import th.co.ais.acs.rest.model.ResponseDataAdvanceInfo;
import th.co.ais.acs.rest.model.ResponseDataBasicInfo;
import th.co.ais.acs.rest.model.ResponseDataCFGList;
import th.co.ais.acs.rest.model.ResponseDataConfigs;
import th.co.ais.acs.rest.model.ResponseDataHostInfo;
import th.co.ais.acs.rest.model.ResponseDataKeyValue;
import th.co.ais.acs.rest.model.ResponseDataWiFiInfo;
import th.co.ais.acs.rest.model.ResponseMessage;
import th.co.ais.acs.rest.model.UMPResponse;
import th.co.ais.acs.rest.model.UserSecurity;

public class EgOperation {
	private static final Logger logger = LoggerFactory.getLogger(EgOperation.class);
	private static final LogDebug LOGGER_DEBUG = new LogDebug();
	private static final LogEG LOGGER_INFO = new LogEG();
	
	private static final String PPPoEUser = "PPPoEUser=";
	private static final String Online = "online";
	private static final String Offline = "offline";
	
	private static final String GetHostInformation = "GetHostInformation";
	private static final String GetWifiInformation = "GetWifiInformation";
	
	DBEgOperation dbEgOperation = InitialParameter.getDbEgOperation();

	public ResponseMessage provisioning( RequestMessage requestMessage, ResponseMessage responseMessage) {
		long start = System.currentTimeMillis();
		
		try {
			
			CpeWorkListWebServicesSoap12BindingStub cpeWorkListWebServicesPortType 
			= new CpeWorkListWebServicesSoap12BindingStub(new java.net.URL(InitialParameter.url_worklist_eg), new CpeWorkListWebServicesLocator());
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeWorkListWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);

			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
//			if(requestMessage.getFibreId() != null) {
//				bindAccount = PPPoEUser+requestMessage.getFibreId();
//			}	
			ServiceChangeRequestEntry serviceChangeRequestEntry = new ServiceChangeRequestEntry();
			serviceChangeRequestEntry.setBindaccount(bindAccount);
			serviceChangeRequestEntry.setOrdertype("Z");
			serviceChangeRequestEntry.setParameters("VLANID="+requestMessage.getBridgeVlan());
			serviceChangeRequestEntry.setSerialuserid("TID" + requestMessage.getRefId());
			serviceChangeRequestEntry.setServicecode("Bridge-WanConnection");
			serviceChangeRequestEntry.setUserid(bindAccount);

			ServiceChangeResponceEntry serviceChangeResponceEntry = cpeWorkListWebServicesPortType.promptlyServiceChange(serviceChangeRequestEntry);
			if(serviceChangeResponceEntry.getFaultcode() != null && serviceChangeResponceEntry.getFaultcode().equals("3501005") ) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
				responseMessage.setDetail("Execute service worklist successfully.");
			} else if (serviceChangeResponceEntry.getFaultstring().contains("swapped")) {
				responseMessage.setResponseCode(Code.SUCCESS_SWAPPED);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS_SWAPPED));
				responseMessage.setDetail(ReponseCode.fromId(Code.SUCCESS_SWAPPED));
			} else if (serviceChangeResponceEntry.getFaultstring().contains("has already been")) {
				responseMessage.setResponseCode(Code.SUCCESS_CPE_ALREADY_BOUND);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS_CPE_ALREADY_BOUND));
				responseMessage.setDetail(ReponseCode.fromId(Code.SUCCESS_CPE_ALREADY_BOUND));
			} else if (serviceChangeResponceEntry.getFaultstring().contains("device has not register")) {
				responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
			} else if (serviceChangeResponceEntry.getFaultstring().contains("does not exist")) {
				responseMessage.setResponseCode(Code.ACTIVATION_ID_DOES_NOT_EXIST);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.ACTIVATION_ID_DOES_NOT_EXIST));
				responseMessage.setDetail(ReponseCode.fromId(Code.ACTIVATION_ID_DOES_NOT_EXIST));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(serviceChangeResponceEntry.getFaultstring()!=null?serviceChangeResponceEntry.getFaultstring():"");
			}
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("provisioning("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("wanSetup response=" + e.getMessage() + ", ");
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=provisioning| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}
	
	public ResponseMessage wifiProvisioning( RequestMessage requestMessage, ResponseMessage responseMessage) {
		long start = System.currentTimeMillis();
		
		responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
		responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
		responseMessage.setDetail("wifiprovisioning response=");
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=wifiprovisioning| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}
	
	public ResponseMessage binding( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		OperateResponce operateResponce = new OperateResponce();
		try {
			
			AISBindServicesSoap12BindingStub aisBindServicesSoap12BindingStub 
			= new AISBindServicesSoap12BindingStub(new java.net.URL(InitialParameter.url_binding_eg), new AISBindServicesLocator());
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) aisBindServicesSoap12BindingStub;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			operateResponce = aisBindServicesSoap12BindingStub.binding(requestMessage.getActivationId(), requestMessage.getMacAddress().replace(":", "").toUpperCase(), requestMessage.getFibreId());
			
			if(operateResponce.getFaultcode() != null && operateResponce.getFaultcode().equals("0") && operateResponce.getFaultstring().contains("The cpe successfully bound") ) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
				responseMessage.setDetail("The cpe successfully bound.");
			} else if (operateResponce.getFaultstring().contains("swapped")) {
				responseMessage.setResponseCode(Code.SUCCESS_SWAPPED);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS_SWAPPED));
				responseMessage.setDetail(ReponseDetail.fromId(Code.SUCCESS_SWAPPED));
			} else if (operateResponce.getFaultstring().contains("has already been")) {
				responseMessage.setResponseCode(Code.SUCCESS_CPE_ALREADY_BOUND);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS_CPE_ALREADY_BOUND));
				responseMessage.setDetail(ReponseDetail.fromId(Code.SUCCESS_CPE_ALREADY_BOUND));
			} else if (operateResponce.getFaultstring().contains("device has not register")) {
				responseMessage.setResponseCode(Code.THE_DEVICE_HAS_NOT_REGISTER);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
				responseMessage.setDetail(ReponseCode.fromId(Code.THE_DEVICE_HAS_NOT_REGISTER));
			} else if (operateResponce.getFaultstring().contains("does not exist")) {
				responseMessage.setResponseCode(Code.ACTIVATION_ID_DOES_NOT_EXIST);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.ACTIVATION_ID_DOES_NOT_EXIST));
				responseMessage.setDetail(ReponseCode.fromId(Code.ACTIVATION_ID_DOES_NOT_EXIST));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(operateResponce.getFaultstring()!=null?operateResponce.getFaultstring():"");
			}

//  			output:{"rescode":"000","resmsg":"SUCCESS","detail":""}
//  			output:{"rescode":"001","resmsg":"The cpe successfully swapped with the old.","detail":{"faultcode":"0","faultstring":"The cpe successfully swapped with the old."}}
//  			output:{"rescode":"100","resmsg":"activationID cannot be input empty","detail":""}
//  			output:{"rescode":"200","resmsg":"The cpe has already been bound with this activation id.","detail":{"faultcode":"0","faultstring":"The cpe has already been bound with this activation id."}}
//  			output:{"rescode":"201","resmsg":"The device has not registered to the ACS server.","detail":""}
//  			output:{"rescode":"202","resmsg":"ActivationID does not exist.","detail":""}
//  			output:{"rescode":"299","resmsg":"UNKNOW return from ACS","detail":{"faultcode":"-1","faultstring":"UnBind occurs exception."}}
//  			output:{"rescode":"299","resmsg":"UNKNOW return from ACS","detail":{"faultcode":"4","faultstring":"The cpe is binding. Don't bind it repeated please."}}
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("provisioning("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("provisioning response=" +operateResponce.getFaultstring()!=null?operateResponce.getFaultstring():"");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=binding| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;

	}
	
	public ResponseMessage getBasicInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
			ResponseDataBasicInfo responseDataBasicInfo = new ResponseDataBasicInfo();
			long start = System.currentTimeMillis();
			
			try {
				
				Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
				= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());
				org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
				s.setTimeout(InitialParameter.connection_timeout);
				
				// Check ActivationId and FibreId
				String bindAccount = null;
				if(requestMessage.getActivationId() != null) {
					bindAccount = requestMessage.getActivationId();
				}
				if(requestMessage.getFibreId() != null) {
					bindAccount = PPPoEUser+requestMessage.getFibreId();
				}
				CpeHgBaseInfo cpeHgBaseInfo = cpe112DiagnosisWebServicesPortType.getCpeBasicInfo(null, bindAccount);
				
				responseDataBasicInfo.setDeviceId(cpeHgBaseInfo.getDeviceID());
				responseDataBasicInfo.setDeviceType(cpeHgBaseInfo.getDeviceType());
				responseDataBasicInfo.setHardwareVersion(cpeHgBaseInfo.getHardVer());
				responseDataBasicInfo.setMacAddress(cpeHgBaseInfo.getMac());
				responseDataBasicInfo.setManufacturer(cpeHgBaseInfo.getManufacturer());
				responseDataBasicInfo.setOui(cpeHgBaseInfo.getOui());
				responseDataBasicInfo.setProductClass(cpeHgBaseInfo.getProductClass());
				responseDataBasicInfo.setIpAddress(cpeHgBaseInfo.getPublicIP());
				responseDataBasicInfo.setRegisterStatus(String.valueOf(cpeHgBaseInfo.getRegistStatus()));
				responseDataBasicInfo.setSoftwareVersion(cpeHgBaseInfo.getSoftVer());
				responseDataBasicInfo.setOnlineStatus((String.valueOf(cpeHgBaseInfo.getStatus()).toLowerCase().equals("0")?Online:Offline));

				responseMessage.getResponseData().setBasicInfo(responseDataBasicInfo);
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
				
			} catch( AxisFault axisFault) {
				responseMessage = axisFault(requestMessage, responseMessage, axisFault);
				responseMessage.setDetail(EgServiceImpl.basicInfoOption + " response=" + axisFault.getFaultString() + ", ");
				
			} catch(Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER_DEBUG.log("getBasicInfo("+requestMessage.getFibreId()+"): exc_fail", e);
				
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(EgServiceImpl.basicInfoOption + " response=" + e.getMessage() + ", ");
			} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getBasicInfo| " + requestMessage.toString() + "| " + responseDataBasicInfo.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage; 			
	}
	
	public ResponseMessage getAdvanceInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ResponseDataAdvanceInfo responseDataAdvanceInfo = new ResponseDataAdvanceInfo();
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, null);	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getCpeCommonInfo(baseRequestEntry);
			
			for (ResponseMapEntry i: responseMapEntry) {
				if(i.getKey().toLowerCase().equals("OUI".toLowerCase())) {
					responseDataAdvanceInfo.setOui(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuProductclass".toLowerCase())) {
					responseDataAdvanceInfo.setProductClass(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("DeviceID".toLowerCase())) {
					responseDataAdvanceInfo.setDeviceId(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SsidStatus".toLowerCase())) {
					responseDataAdvanceInfo.setSsidStatus(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SsidName".toLowerCase())) {
					responseDataAdvanceInfo.setSsidName(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuManufacturer".toLowerCase())) {
					responseDataAdvanceInfo.setManufacturer(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("HardVersion".toLowerCase())) {
					responseDataAdvanceInfo.setHardwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuInternetAddr".toLowerCase())) {
					responseDataAdvanceInfo.setIpAddress(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("SoftwareVersion".toLowerCase())) {
					responseDataAdvanceInfo.setSoftwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuConnectionType".toLowerCase())) {
					responseDataAdvanceInfo.setOnuConnectionType(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuSoftwareVersion".toLowerCase())) {
					responseDataAdvanceInfo.setOnuSoftwareVersion(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass".toLowerCase())) {
					responseDataAdvanceInfo.setOnuVoipIp(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthName".toLowerCase())) {
					responseDataAdvanceInfo.setSipUsername1(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass".toLowerCase())) {
					responseDataAdvanceInfo.setSipPassword1(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthName2".toLowerCase())) {
					responseDataAdvanceInfo.setSipUsername2(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("VoipAuthPass2".toLowerCase())) {
					responseDataAdvanceInfo.setSipPassword2(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("OnuVoipIp".toLowerCase())) {
					responseDataAdvanceInfo.setOnuVoipIp(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("Online".toLowerCase())) {
					responseDataAdvanceInfo.setOnlineStatus(i.getValue().toLowerCase().equals("true")?Online:Offline);
				}
				if(i.getKey().toLowerCase().equals("LANStatus".toLowerCase())) {
					responseDataAdvanceInfo.setLanStatus(i.getValue());
				}
				if(i.getKey().toLowerCase().equals("CpeStatus".toLowerCase())) {
					responseDataAdvanceInfo.setOui(i.getValue());
				}
				
			}

			responseMessage.getResponseData().setAdvanceInfo(responseDataAdvanceInfo);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + EgServiceImpl.advanceInfoOption + " response=" + axisFault.getFaultString() + ", ");
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getAdvanceInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + EgServiceImpl.advanceInfoOption + " response=" + e.getMessage() + ", ");	
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getAdvanceInfo| " + requestMessage.toString() + "| " + responseDataAdvanceInfo.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}
	
	public ResponseMessage getHostInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ArrayList<ResponseDataHostInfo> responseDataHostInfoList = new ArrayList<ResponseDataHostInfo>();
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, null);	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getMultiParameterValuesByItemName(baseRequestEntry, GetHostInformation);
			
			for (ResponseMapEntry i: responseMapEntry) {
				ResponseDataHostInfo responseDataHostInfo = new ResponseDataHostInfo();
				if(i.getKey().toLowerCase().endsWith("_active")) {
					responseDataHostInfo.setPortNumber(i.getKey().split("_")[0]);
					responseDataHostInfoList.add(responseDataHostInfo);
				}				
			}
			
			for (ResponseDataHostInfo i: responseDataHostInfoList) {
				String index = i.getPortNumber();
				for (ResponseMapEntry res: responseMapEntry) {
					if(res.getKey().toLowerCase().equals((index+"_Active").toLowerCase())) {
						i.setActive(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_HostName").toLowerCase())) {
						i.setHostName(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_InterfaceType").toLowerCase())) {
						i.setInterfaceType(res.getValue());
					}
					if(res.getKey().toLowerCase().equals((index+"_Layer2Interface").toLowerCase())) {
						i.setLayer2Interface(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_IPAddress").toLowerCase())) {
						i.setIpAddress(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_MACAddress").toLowerCase())) {
						i.setMacAddress(res.getValue());
					}	
				}				
			}
			

			responseMessage.getResponseData().setHostInfo(responseDataHostInfoList);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + EgServiceImpl.hostInfoOption + " response=" + axisFault.getFaultString() + ", ");
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getHostInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + EgServiceImpl.hostInfoOption + " response=" + e.getMessage() + ", ");	
		} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getHostInfo| " + requestMessage.toString() + "| " + Arrays.toString(responseDataHostInfoList.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}
	
	public ResponseMessage getOnlineStatus( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		String onlineStatus = Offline;
		long start = System.currentTimeMillis();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			int response = cpe112DiagnosisWebServicesPortType.getCpeOnlineStatus(null, bindAccount);
			
			if (response == 0) {
				onlineStatus = Online;			
			} else {
				onlineStatus = Offline;	
			}
			responseMessage.getResponseData().setOnlineStatus(onlineStatus);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			responseMessage.setDetail(detail + EgServiceImpl.onlineStatusOption + " response=" + axisFault.getFaultString() + ", ");
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getonlineStatus("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + EgServiceImpl.onlineStatusOption + " response=" + e.getMessage() + ", ");
		} 

		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getonlineStatus| " + requestMessage.toString() + "| " + onlineStatus + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;	
	}
	
	public ResponseMessage getLastSessionTime( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ResponseDataBasicInfo responseDataBasicInfo = new ResponseDataBasicInfo();
		long start = System.currentTimeMillis();
		UMPResponse umpResponse = new UMPResponse();
		String detail = responseMessage.getDetail()!=null?responseMessage.getDetail():"";
		
		String uri = "";
		try {
			
			if(requestMessage.getMacAddress() != null) {
				responseMessage = dbEgOperation.queryLastSessionTimeByMac(requestMessage, responseMessage);
			}
			if(requestMessage.getIpAddress() != null) {
				responseMessage = dbEgOperation.queryLastSessionTimeByIP(requestMessage, responseMessage);
			}
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getLastSessionTime("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(detail + AvsServiceImpl.lastSessiontimeOption + " response=" + e.getMessage() + ", ");	
		} finally {
			responseMessage.setUmpResponse(null);
			responseMessage.setDeviceId(null);
		}

	long elapsedTimeMillis = System.currentTimeMillis()-start;
	if(responseMessage.getResponseData() != null && responseMessage.getResponseData().getBasicInfo() != null ) {
		LOGGER_INFO.log("method=getLastSessionTime| " + requestMessage.toString() + "| " + responseMessage.getResponseData().getBasicInfo() + ", elapsed=" + elapsedTimeMillis);
	} else {
		LOGGER_INFO.log("method=getLastSessionTime| " + requestMessage.toString() + "| " + responseDataBasicInfo.toString() + ", elapsed=" + elapsedTimeMillis);
	}
	return responseMessage; 			
	}
	
	public ResponseMessage wanSetup( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, null);	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.testWanSetup(baseRequestEntry,
					requestMessage.getInternetUsername(), 
					requestMessage.getInternetPassword(), 
					requestMessage.getPrimaryDns()!=null?requestMessage.getPrimaryDns():null, 
					requestMessage.getSecondDns()!=null?requestMessage.getSecondDns():null);			
			for (ResponseMapEntry res: responseMapEntry) {
				if(res.getKey().toLowerCase().equals("result")) {
					if(res.getValue().toLowerCase().equals("success")) {
						responseMessage.setResponseCode(Code.SUCCESS);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
					} else {
						responseMessage.setResponseCode(Code.FAILURE);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.FAILURE));
					}
				}
				if(res.getKey().toLowerCase().equals("error message")) {
					responseMessage.setDetail(res.getValue());
				}
			}


		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wanSetup("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("wanSetup response=" + e.getMessage() + ", ");
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=wanSetup| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;		
	}

	public ResponseMessage getWifiInfo( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ArrayList<ResponseDataWiFiInfo> responseDataWiFiInfoList = new ArrayList<ResponseDataWiFiInfo>();
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, null);	
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getParameterValuesByItemName(baseRequestEntry, GetWifiInformation);
			
			for (ResponseMapEntry i: responseMapEntry) {
				ResponseDataWiFiInfo responseDataWiFiInfo = new ResponseDataWiFiInfo();
				if(i.getKey().toLowerCase().endsWith("_channel")) {
					responseDataWiFiInfo.setIndex(i.getKey().split("_")[0]);
					responseDataWiFiInfoList.add(responseDataWiFiInfo);
				}				
			}
			
			for (ResponseDataWiFiInfo i: responseDataWiFiInfoList) {
				String index = i.getIndex();
				for (ResponseMapEntry res: responseMapEntry) {
					if(res.getKey().toLowerCase().equals((index+"_CHANNEL").toLowerCase())) {
						i.setChannel(res.getValue());
					}	
					if(res.getKey().toLowerCase().equals((index+"_ENABLE").toLowerCase())) {
						if(res.getValue().equals("true")) {
							i.setEnable("1");
						} else if (res.getValue().equals("false")) {
							i.setEnable("0");
						} else {
							i.setEnable(res.getValue());
						}
					}	
					if(res.getKey().toLowerCase().equals((index+"_SSID").toLowerCase())) {
						i.setSsid(res.getValue());
					}					
				}				
			}
			

			responseMessage.getResponseData().setWiFiInfo(responseDataWiFiInfoList);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));			
  			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		}  catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getWifiInfo("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("getWifiInfo response=" + e.getMessage() + ", ");	
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getWifiInfo| " + requestMessage.toString() + "| " + Arrays.toString(responseDataWiFiInfoList.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}

	public ResponseMessage wifiSetup( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}	
		
			List<String> paramNames_ = new ArrayList<>();
			List<String> paramValue_ = new ArrayList<>();
			for (RequestWiFiInfo i: requestMessage.getWifiInfo()) {
				if(i.getSsid() != null) {
					paramNames_.add(i.getIndex() + "_SSID");
					paramValue_.add(i.getSsid());
				}
				if(i.getEnable() != null) {
					paramNames_.add(i.getIndex() + "_ENABLE");
					paramValue_.add(i.getEnable());
				}
				if(i.getAutoChannelEnable() != null) {
					paramNames_.add(i.getIndex() + "_AutoChannelEnable");
					paramValue_.add(i.getAutoChannelEnable());
				}
				if(i.getChannel() != null) {
					if (i.getAutoChannelEnable() == null || (i.getAutoChannelEnable() != null && i.getAutoChannelEnable().equals("0"))) {
						paramNames_.add(i.getIndex() + "_CHANNEL");
						paramValue_.add(i.getChannel());
					}
				}
				if(i.getKey() != null) {
					paramNames_.add(i.getIndex() + "_KEY");
					paramValue_.add(i.getKey());
				}
			
			}
			
			String[] paramNames = paramNames_.stream().toArray(String[]::new);
			String[] paramValue = paramValue_.stream().toArray(String[]::new);
			
			SetParameterValuesRequestEntry setParameterValuesRequestEntry = new SetParameterValuesRequestEntry();
			setParameterValuesRequestEntry.setParamNames(paramNames);
			setParameterValuesRequestEntry.setParamValues(paramValue);
			setParameterValuesRequestEntry.setBindAccount(bindAccount);
			int response = cpe112DiagnosisWebServicesPortType.setSpecifiedParameterValuesByItemName(setParameterValuesRequestEntry, "DiagnosisWifiSetUp");
			
			if(response == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}
			responseMessage.setDetail("wifiSetup response=" + response);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("wifiSetup("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("wifiSetup response=" + e.getMessage() + ", ");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=wifiSetup| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
			
		return responseMessage;
	}
	
	public ResponseMessage getParameterValues( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		ArrayList<ResponseDataKeyValue> getParameterValuesResponse = new ArrayList<ResponseDataKeyValue>();
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			
			List<String> item_ = new ArrayList<>();
			for (RequestItem i: requestMessage.getParamNameVec()) {
				item_.add(i.getItem());
			
			}
			
			String[] item = item_.stream().toArray(String[]::new);
			
			GetParameterValuesRequestEntry baseRequestEntry = new GetParameterValuesRequestEntry(bindAccount, null, item);
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.getParameterValues(baseRequestEntry);
			
			for (ResponseMapEntry res: responseMapEntry) {
				ResponseDataKeyValue responseDataKeyValue = new ResponseDataKeyValue();
				responseDataKeyValue.setKey(res.getKey());
				if(res.getKey().endsWith("AutoChannelEnable")) {
					if(res.getValue().equals("true")) {
						responseDataKeyValue.setValue("1"); 
					} else if (res.getValue().equals("false")) {
						responseDataKeyValue.setValue("0"); 
					} else {
						responseDataKeyValue.setValue(res.getValue()); 
					}
				} else {
					responseDataKeyValue.setValue(res.getValue()); 
				}
				getParameterValuesResponse.add(responseDataKeyValue);
			}	
			
			responseMessage.getResponseData().setGetParameterValuesResponse(getParameterValuesResponse);
			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
  			
		}  catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getParameterValues("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("getParameterValues response=" + e.getMessage() + ", ");		
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getParameterValues| " + requestMessage.toString() + "| " + Arrays.toString(getParameterValuesResponse.toArray()) + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}

	public ResponseMessage setParameterValues( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}	
		
			List<String> paramNames_ = new ArrayList<>();
			List<String> paramValue_ = new ArrayList<>();
			for (RequestDataKeyValue i: requestMessage.getParameterValues()) {
				paramNames_.add(i.getKey());
				paramValue_.add(i.getValue());
			
			}
			
			String[] paramNames = paramNames_.stream().toArray(String[]::new);
			String[] paramValue = paramValue_.stream().toArray(String[]::new);
			
			SetParameterValuesRequestEntry setParameterValuesRequestEntry = new SetParameterValuesRequestEntry();
			setParameterValuesRequestEntry.setParamNames(paramNames);
			setParameterValuesRequestEntry.setParamValues(paramValue);
			setParameterValuesRequestEntry.setBindAccount(bindAccount);
			int response = cpe112DiagnosisWebServicesPortType.setParameterValues(setParameterValuesRequestEntry);
			
			if(response == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.FAILURE);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			}
			responseMessage.setDetail("setParameterValues response=" + response);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("setParameterValues("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("setParameterValues response=" + e.getMessage() + ", ");
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=setParameterValues| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
			
		return responseMessage;
	}
	
	public ResponseMessage upgradeFirmware(RequestMessage requestMessage, ResponseMessage responseMessage) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		
		try {

			CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_eg), new CpeDiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			DownloadRequestEntry downloadRequestEntry = new DownloadRequestEntry(bindAccount, null, requestMessage.getFirmwareVersion() != null?requestMessage.getFirmwareVersion():null);					
			int cpeUpgrade = cpeDiagnosisWebServicesPortType.downloadVersion(downloadRequestEntry);
		
			// CPE Upgrade Success
			responseMessage.setDetail(String.valueOf(cpeUpgrade));
			if(cpeUpgrade == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			responseMessage.setDetail("upgradeFirmware response=" + cpeUpgrade);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("upgradeFirmware("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=upgradeFirmware| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);

		return responseMessage;		
	}
	
	public ResponseMessage reboot( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {

			CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_eg), new CpeDiagnosisWebServicesPortTypeImplServiceLocator());
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);			

			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			DiagnosisRebootRequestEntry diagnosisRebootRequestEntry = new DiagnosisRebootRequestEntry(bindAccount, null);
			int cpeReboot = cpeDiagnosisWebServicesPortType.reboot(diagnosisRebootRequestEntry);
			
			// Reboot Success
			responseMessage.setDetail(String.valueOf(cpeReboot));
			if(cpeReboot == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			responseMessage.setDetail("reboot response=" + cpeReboot);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("reboot("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=reboot| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);

		return responseMessage;	
	}
	
	public ResponseMessage factoryReset(RequestMessage requestMessage, ResponseMessage responseMessage) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		
		try {

			CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_eg), new CpeDiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);			
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			DiagnosisFactoryResetRequestEntry diagnosisFactoryResetRequestEntry = new DiagnosisFactoryResetRequestEntry(bindAccount, null);					
			int factoryReset = cpeDiagnosisWebServicesPortType.factoryReset(diagnosisFactoryResetRequestEntry);
		
			// Factory Reset Success
			responseMessage.setDetail(String.valueOf(factoryReset));
			if(factoryReset == 0) {
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			responseMessage.setDetail("factoryReset response=" + factoryReset);
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("factoryReset("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=factoryReset| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
	
		return responseMessage;			
	}

	public ResponseMessage uploadCFG(RequestMessage requestMessage, ResponseMessage responseMessage) {
		// TODO Auto-generated method stub
		ArrayList<ResponseDataKeyValue> responseDataUploadCFGList = new ArrayList<ResponseDataKeyValue>();
		long start = System.currentTimeMillis();
		
		try {
			
			CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_eg), new CpeDiagnosisWebServicesPortTypeImplServiceLocator());
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);			
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, null);					
			ResponseMapEntry[] uploadCFGList = cpeDiagnosisWebServicesPortType.uploadCFG(baseRequestEntry);
		
			// upload CFG Success
			responseMessage.setDetail(String.valueOf(uploadCFGList));
			if(uploadCFGList[0].getValue().toLowerCase().equals("success")) {
				for(ResponseMapEntry uploadCFG : uploadCFGList ) {
					ResponseDataKeyValue responseDataUploadCFG = new ResponseDataKeyValue();
					responseDataUploadCFG.setKey(uploadCFG.getKey());
					responseDataUploadCFG.setValue(uploadCFG.getValue());
					responseDataUploadCFGList.add(responseDataUploadCFG);
				}
				//responseMessage.getResponseData().setUploadCFGInfo(responseDataUploadCFGList);
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			
			if(uploadCFGList[0] != null && uploadCFGList[0].getValue() != null) {
				responseMessage.setDetail("uploadCFG response=" + uploadCFGList[0].getValue());
			}
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("uploadCFG("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=uploadCFG| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;			
	}

	public ResponseMessage getCFGList(RequestMessage requestMessage, ResponseMessage responseMessage) {
		// TODO Auto-generated method stub
		ResponseData responseData = new ResponseData();
		ArrayList<ResponseDataConfigs> configs = new ArrayList<ResponseDataConfigs>();
		
		ResponseDataCFGList responseDataGetCFGList = new ResponseDataCFGList();
		long start = System.currentTimeMillis();
		
		try {
			
			CpeDiagnosisWebServicesSoap12BindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesSoap12BindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_eg), new CpeDiagnosisWebServicesLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);			

			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			BaseRequestEntry baseRequestEntry = new BaseRequestEntry(bindAccount, null);					
			ConfigFilesListResponseEntry getCFGList = cpeDiagnosisWebServicesPortType.getCFGList(baseRequestEntry);

			// upload CFG Success
			
			for(ResponseMapEntry array : getCFGList.getArray() ) {

				if(array.getKey().equals("result")) {
					if(array.getValue().equals("Success") || array.getValue().equals("success")) {
						responseMessage.setResponseCode(Code.SUCCESS);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
						responseMessage.setDetail(ReponseCode.fromId(Code.SUCCESS));
					}
				}
				if(array.getKey().equals("Error message") && !array.getValue().equals("")) {
					if(array.getValue() != null ) {	
						responseMessage.setResponseCode(Code.FAILURE);
						responseMessage.setResponseMessage(ReponseCode.fromId(Code.FAILURE));
						responseMessage.setDetail(array.getValue());
					}
				}
				if(array.getKey().equals("DeviceID")) {
					responseData.setDeviceId(array.getValue());
				}
			}
				
			if(responseMessage.getResponseCode() != null && responseMessage.getResponseCode().equals(Code.SUCCESS) && getCFGList.getConfigs() != null) {
				for(ArrayOfResponseMapEntry res : getCFGList.getConfigs() ) {
					ResponseDataConfigs responseDataConfigs = new ResponseDataConfigs();
					for(ResponseMapEntry  responseMapEntry : res.getArray() ) {
						
						
						if("Filename".equals(responseMapEntry.getKey())) {
							responseDataConfigs.setFileName(responseMapEntry.getValue());
						}
						if("File Size".equals(responseMapEntry.getKey())) {
							responseDataConfigs.setFileSize(responseMapEntry.getValue());
						}
						if("Time".equals(responseMapEntry.getKey())) {
							try {
								responseDataConfigs.setTime(responseMapEntry.getValue().split("\\.")[0]);
							} catch(Exception e) {e.printStackTrace();}
						}
						if("Backup Type".equals(responseMapEntry.getKey())) {
							responseDataConfigs.setBackupType(responseMapEntry.getValue());
						}
						
					}
					configs.add(responseDataConfigs);
					
				}
				responseData.setConfigs(configs);
				responseMessage.setResponseData(responseData);
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			
			if(getCFGList.getArray().length > 0 &&  getCFGList.getArray()[0] != null) {
				responseMessage.setDetail("getCFGList response=" + getCFGList.getArray()[0].getValue());
			}
			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("getCFGList("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());	
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=getCFGList| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;			
	}
	
	public ResponseMessage checkVoIPProfile( RequestMessage requestMessage, ResponseMessage responseMessage ) {
		long start = System.currentTimeMillis();
		
		try {
			
			Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpe112DiagnosisWebServicesPortType 
			= new Cpe112DiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis112_eg), new Cpe112DiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpe112DiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			
			GetParameterValuesRequestEntry baseRequestEntry = new GetParameterValuesRequestEntry(bindAccount, null, null);
			ResponseMapEntry [] responseMapEntry = cpe112DiagnosisWebServicesPortType.testCpeHasPots(baseRequestEntry);
			
			cpe112DiagnosisWebServicesPortType.testCpeHasPots(baseRequestEntry);
			
			for (ResponseMapEntry res: responseMapEntry) {
				if(res.getKey().endsWith("Result")) {
					responseMessage.getResponseData().setVoipProfile(res.getValue());
					
				} 
			}	

			responseMessage.setResponseCode(Code.SUCCESS);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
  			
		}  catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("checkVoIPProfile("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail("checkVoIPProfile response=" + e.getMessage() + ", ");		
		} 
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=checkVoIPProfile| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);
		
		return responseMessage;
	}

	public ResponseMessage downloadCFGToDevice(RequestMessage requestMessage, ResponseMessage responseMessage) {
		// TODO Auto-generated method stub
		ArrayList<ResponseDataKeyValue> responseDataDownloadCFGList = new ArrayList<ResponseDataKeyValue>();
		long start = System.currentTimeMillis();
		
		try {

			CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub cpeDiagnosisWebServicesPortType 
			= new CpeDiagnosisWebServicesPortTypeImplServiceSoapBindingStub(new java.net.URL(InitialParameter.url_cpediagnosis_eg), new CpeDiagnosisWebServicesPortTypeImplServiceLocator());	
			org.apache.axis.client.Stub s = (org.apache.axis.client.Stub) cpeDiagnosisWebServicesPortType;
			s.setTimeout(InitialParameter.connection_timeout);			
			
			// Check ActivationId and FibreId
			String bindAccount = null;
			if(requestMessage.getActivationId() != null) {
				bindAccount = requestMessage.getActivationId();
			}
			if(requestMessage.getFibreId() != null) {
				bindAccount = PPPoEUser+requestMessage.getFibreId();
			}
			DownloadConifgFileForAisRequestEntry downloadConfigFileForAisRequestEntry = new DownloadConifgFileForAisRequestEntry(bindAccount, null, requestMessage.getConfigFileName());					
			ResponseMapEntry[] downloadCFGList = cpeDiagnosisWebServicesPortType.downloadCFGToDevice(downloadConfigFileForAisRequestEntry);
			
			// download CFG Success
			responseMessage.setDetail(String.valueOf(downloadCFGList));
			if(downloadCFGList[0].getValue().toLowerCase().equals("success")) {
				for(ResponseMapEntry downloadCFG : downloadCFGList ) {
					ResponseDataKeyValue responseDataDownloadCFG = new ResponseDataKeyValue();
					responseDataDownloadCFG.setKey(downloadCFG.getKey());
					responseDataDownloadCFG.setValue(downloadCFG.getValue());
					responseDataDownloadCFGList.add(responseDataDownloadCFG);
				}
				//responseMessage.getResponseData().setUploadCFGInfo(responseDataDownloadCFGList);
				responseMessage.setResponseCode(Code.SUCCESS);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.SUCCESS));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			}
			
			if(downloadCFGList.length > 0 && downloadCFGList[0].getValue() != null) {
				responseMessage.setDetail("downloadCFGToDevice response=" + downloadCFGList[0].getValue());
			}
  			
		} catch( AxisFault axisFault) {
			responseMessage = axisFault(requestMessage, responseMessage, axisFault);
			
		} catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER_DEBUG.log("downloadCFGToDevice("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
		}
		
		long elapsedTimeMillis = System.currentTimeMillis()-start;
		LOGGER_INFO.log("method=downloadCFGToDevice| " + requestMessage.toString() + "| " + responseMessage.toString() + ", elapsed=" + elapsedTimeMillis);

		return responseMessage;
	}
	
	private boolean checkMandatory(String input) {
		boolean isValid = false;

		if (input != null && input.length() > 0) {
			isValid = true;
		}

		return isValid;
	}
	
	private ResponseMessage axisFault(RequestMessage requestMessage, ResponseMessage responseMessage, AxisFault axisFault) {
		try {
			String message = "";
			if( axisFault.getFaultSubCodes() != null && axisFault.getFaultSubCodes()[0] != null) {
				message = message + axisFault.getFaultSubCodes()[0].toString();
			}
			message = message + axisFault.getFaultCode().toString();
			
			if(message.contains("3501700")) {
				responseMessage.setResponseCode(Code._3501700);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3501700));
				responseMessage.setDetail(ReponseCode.fromId(Code._3501700));
			} else if(message.contains("3501703")) {
				responseMessage.setResponseCode(Code._3501703);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3501703));
				responseMessage.setDetail(ReponseCode.fromId(Code._3501703));
			} else if(message.contains("3500008")) {
				responseMessage.setResponseCode(Code._3500008);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3500008));
				responseMessage.setDetail(ReponseCode.fromId(Code._3500008));
			} else if(message.contains("3519000")) {
				responseMessage.setResponseCode(Code._3519000);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519000));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519000));
			} else if(message.contains("3519002")) {
				responseMessage.setResponseCode(Code._3519002);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519002));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519002));
			} else if(message.contains("3519003")) {
				responseMessage.setResponseCode(Code._3519003);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519003));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519003));
			} else if(message.contains("3519005")) {
				responseMessage.setResponseCode(Code._3519005);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519005));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519005));
			} else if(message.contains("3519008")) {
				responseMessage.setResponseCode(Code._3519008);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code._3519008));
				responseMessage.setDetail(ReponseCode.fromId(Code._3519008));
			} else {
				responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
				responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
				responseMessage.setDetail(axisFault.getFaultString());
			} 
			
		} catch(Exception e) {
			e.printStackTrace();
			LOGGER_DEBUG.log("axisFault("+requestMessage.getFibreId()+"): exc_fail", e);
			
			responseMessage.setResponseCode(Code.OPERATIONS_FAIL);
			responseMessage.setResponseMessage(ReponseCode.fromId(Code.OPERATIONS_FAIL));
			responseMessage.setDetail(e.getMessage());
			return responseMessage;
		}
		
		return responseMessage;
	}

}
