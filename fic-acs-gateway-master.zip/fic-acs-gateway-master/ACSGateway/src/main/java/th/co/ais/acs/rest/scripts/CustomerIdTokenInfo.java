package th.co.ais.acs.rest.scripts;

public class CustomerIdTokenInfo {
	String customerId = null;
	String tokenId    = null;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	
}
