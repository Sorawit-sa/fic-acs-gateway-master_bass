/**
 * ServiceInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package th.co.tbb.acshw.model.DiagnoseService;

public class ServiceInfo  implements java.io.Serializable {
    private int networkStatus;

    private th.co.tbb.acshw.model.DiagnoseService.Para[] paraList;

    private int serviceStatus;

    private int type;

    public ServiceInfo() {
    }

    public ServiceInfo(
           int networkStatus,
           th.co.tbb.acshw.model.DiagnoseService.Para[] paraList,
           int serviceStatus,
           int type) {
           this.networkStatus = networkStatus;
           this.paraList = paraList;
           this.serviceStatus = serviceStatus;
           this.type = type;
    }


    /**
     * Gets the networkStatus value for this ServiceInfo.
     * 
     * @return networkStatus
     */
    public int getNetworkStatus() {
        return networkStatus;
    }


    /**
     * Sets the networkStatus value for this ServiceInfo.
     * 
     * @param networkStatus
     */
    public void setNetworkStatus(int networkStatus) {
        this.networkStatus = networkStatus;
    }


    /**
     * Gets the paraList value for this ServiceInfo.
     * 
     * @return paraList
     */
    public th.co.tbb.acshw.model.DiagnoseService.Para[] getParaList() {
        return paraList;
    }


    /**
     * Sets the paraList value for this ServiceInfo.
     * 
     * @param paraList
     */
    public void setParaList(th.co.tbb.acshw.model.DiagnoseService.Para[] paraList) {
        this.paraList = paraList;
    }


    /**
     * Gets the serviceStatus value for this ServiceInfo.
     * 
     * @return serviceStatus
     */
    public int getServiceStatus() {
        return serviceStatus;
    }


    /**
     * Sets the serviceStatus value for this ServiceInfo.
     * 
     * @param serviceStatus
     */
    public void setServiceStatus(int serviceStatus) {
        this.serviceStatus = serviceStatus;
    }


    /**
     * Gets the type value for this ServiceInfo.
     * 
     * @return type
     */
    public int getType() {
        return type;
    }


    /**
     * Sets the type value for this ServiceInfo.
     * 
     * @param type
     */
    public void setType(int type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ServiceInfo)) return false;
        ServiceInfo other = (ServiceInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.networkStatus == other.getNetworkStatus() &&
            ((this.paraList==null && other.getParaList()==null) || 
             (this.paraList!=null &&
              java.util.Arrays.equals(this.paraList, other.getParaList()))) &&
            this.serviceStatus == other.getServiceStatus() &&
            this.type == other.getType();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getNetworkStatus();
        if (getParaList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParaList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParaList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getServiceStatus();
        _hashCode += getType();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ServiceInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "ServiceInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("networkStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "networkStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paraList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paraList"));
        elemField.setXmlType(new javax.xml.namespace.QName("DiagnoseService", "Para"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "serviceStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
